﻿define("InAppBrowserPlugin.controller$CheckInAppBrowserPlugin", ["exports", "OutSystems/ClientRuntime/Main", "InAppBrowserPlugin.model", "InAppBrowserPlugin.controller", "CommonPlugin.controller", "CommonPlugin.model", "InAppBrowserPlugin.controller$CheckInAppBrowserPlugin.CheckPluginJS", "CommonPlugin.controller$IsCordovaDefined", "InAppBrowserPlugin.referencesHealth", "InAppBrowserPlugin.referencesHealth$CommonPlugin", "CommonPlugin.model$ErrorRec"], function (exports, OutSystems, InAppBrowserPluginModel, InAppBrowserPluginController, CommonPluginController, CommonPluginModel, InAppBrowserPlugin_controller_CheckInAppBrowserPlugin_CheckPluginJS) {
var OS = OutSystems.Internal;
InAppBrowserPluginController.default.checkInAppBrowserPlugin$Action = function (callContext) {
callContext = controller.callContext(callContext);
var allExceptionsVar = new OS.DataTypes.VariableHolder(new OS.DataTypes.ErrorHandlerOutputType());
var isCordovaDefinedVar = new OS.DataTypes.VariableHolder();
var checkPluginJSResult = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("InAppBrowserPlugin.CheckInAppBrowserPlugin$outVars"))());
try {// Execute Action: IsCordovaDefined
isCordovaDefinedVar.value = CommonPluginController.default.isCordovaDefined$Action(callContext);

if((isCordovaDefinedVar.value.isLoadedOut)) {
// PluginLoaded?
checkPluginJSResult.value = controller.safeExecuteJSNode(InAppBrowserPlugin_controller_CheckInAppBrowserPlugin_CheckPluginJS, "CheckPlugin", "CheckInAppBrowserPlugin", {
PluginExists: OS.DataConversion.JSNodeParamConverter.to(false, OS.Types.Boolean)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("InAppBrowserPlugin.CheckInAppBrowserPlugin$checkPluginJSResult"))();
jsNodeResult.pluginExistsOut = OS.DataConversion.JSNodeParamConverter.from($parameters.PluginExists, OS.Types.Boolean);
return jsNodeResult;
}, {}, {});
if((checkPluginJSResult.value.pluginExistsOut)) {
// IsAvailable = True
outVars.value.isAvailableOut = true;
// Error.ErrorCode = 0
outVars.value.errorOut.errorCodeAttr = "0";
// Error.ErrorMessage = ""
outVars.value.errorOut.errorMessageAttr = "";
} else {
// IsAvailable = False
outVars.value.isAvailableOut = false;
// Error.ErrorCode = 2
outVars.value.errorOut.errorCodeAttr = "2";
// Error.ErrorMessage = "InAppBrowser is not defined"
outVars.value.errorOut.errorMessageAttr = "InAppBrowser is not defined";
}

} else {
// IsAvailable = False
outVars.value.isAvailableOut = false;
// Error.ErrorCode = 1
outVars.value.errorOut.errorCodeAttr = "1";
// Error.ErrorMessage = "cordova is not defined"
outVars.value.errorOut.errorMessageAttr = "cordova is not defined";
}

} catch (ex) {
(function () {
OS.Logger.trace("CheckInAppBrowserPlugin.CheckInAppBrowserPlugin", OS.Exceptions.getMessage(ex), ex.name);
// Handle Error: AllExceptions
if(!(OS.Exceptions.isSystem(ex))) {
OS.Logger.error(null, ex);
allExceptionsVar.value.exceptionMessageAttr = OS.Exceptions.getMessage(ex);
// IsAvailable = False
outVars.value.isAvailableOut = false;
// Error.ErrorCode = -1
outVars.value.errorOut.errorCodeAttr = (-1).toString();
// Error.ErrorMessage = AllExceptions.ExceptionMessage
outVars.value.errorOut.errorMessageAttr = allExceptionsVar.value.exceptionMessageAttr;
return outVars.value;

}

throw ex;
})();
}

return outVars.value;
};
var controller = InAppBrowserPluginController.default;
InAppBrowserPluginController.default.constructor.registerVariableGroupType("InAppBrowserPlugin.CheckInAppBrowserPlugin$checkPluginJSResult", [{
name: "PluginExists",
attrName: "pluginExistsOut",
mandatory: true,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
InAppBrowserPluginController.default.constructor.registerVariableGroupType("InAppBrowserPlugin.CheckInAppBrowserPlugin$outVars", [{
name: "IsAvailable",
attrName: "isAvailableOut",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}, {
name: "Error",
attrName: "errorOut",
mandatory: false,
dataType: OS.Types.Record,
defaultValue: function () {
return new CommonPluginModel.ErrorRec();
},
complexType: CommonPluginModel.ErrorRec
}]);
InAppBrowserPluginController.default.clientActionProxies.checkInAppBrowserPlugin$Action = function () {
return controller.executeActionInsideJSNode(InAppBrowserPluginController.default.checkInAppBrowserPlugin$Action.bind(controller), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
IsAvailable: OS.DataConversion.JSNodeParamConverter.to(actionResults.isAvailableOut, OS.Types.Boolean),
Error: actionResults.errorOut
};
});
};
});
define("InAppBrowserPlugin.controller$CheckInAppBrowserPlugin.CheckPluginJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
$parameters.PluginExists = typeof(cordova.InAppBrowser) !== "undefined";
};
});

define("InAppBrowserPlugin.controller$Open", ["exports", "OutSystems/ClientRuntime/Main", "InAppBrowserPlugin.model", "InAppBrowserPlugin.controller", "CommonPlugin.model", "InAppBrowserPlugin.controller$Open.OpenInAppBrowserJS", "CommonPlugin.model$ErrorRec", "InAppBrowserPlugin.referencesHealth", "InAppBrowserPlugin.referencesHealth$CommonPlugin", "InAppBrowserPlugin.controller$CheckInAppBrowserPlugin", "InAppBrowserPlugin.model$OptionsRec", "InAppBrowserPlugin.controller$ParseOptions"], function (exports, OutSystems, InAppBrowserPluginModel, InAppBrowserPluginController, CommonPluginModel, InAppBrowserPlugin_controller_Open_OpenInAppBrowserJS) {
var OS = OutSystems.Internal;
InAppBrowserPluginController.default.open$Action = function (urlIn, targetIn, optionsIn, callContext) {
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("InAppBrowserPlugin.Open$vars"))());
vars.value.urlInLocal = urlIn;
vars.value.targetInLocal = targetIn;
vars.value.optionsInLocal = optionsIn.clone();
var allExceptionsVar = new OS.DataTypes.VariableHolder(new OS.DataTypes.ErrorHandlerOutputType());
var checkInAppBrowserPluginVar = new OS.DataTypes.VariableHolder();
var parseOptionsVar = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("InAppBrowserPlugin.Open$outVars"))());
try {// Execute Action: CheckInAppBrowserPlugin
checkInAppBrowserPluginVar.value = InAppBrowserPluginController.default.checkInAppBrowserPlugin$Action(callContext);

if((checkInAppBrowserPluginVar.value.isAvailableOut)) {
// HasScheme?
if((!(((OS.BuiltinFunctions.index(vars.value.urlInLocal, "http://", 0, false, true) === -1) && (OS.BuiltinFunctions.index(vars.value.urlInLocal, "https://", 0, false, true) === -1))))) {
// Execute Action: ParseOptions
parseOptionsVar.value = InAppBrowserPluginController.default.parseOptions$Action(vars.value.optionsInLocal, callContext);

controller.safeExecuteJSNode(InAppBrowserPlugin_controller_Open_OpenInAppBrowserJS, "OpenInAppBrowser", "Open", {
OptionsString: OS.DataConversion.JSNodeParamConverter.to(parseOptionsVar.value.optionsStringOut, OS.Types.Text),
Target: OS.DataConversion.JSNodeParamConverter.to(vars.value.targetInLocal, OS.Types.Text),
Url: OS.DataConversion.JSNodeParamConverter.to(vars.value.urlInLocal, OS.Types.Text)
}, function ($parameters) {
}, {}, {});
// Success = True
outVars.value.successOut = true;
// Error.ErrorCode = 0
outVars.value.errorOut.errorCodeAttr = "0";
// Error.ErrorMessage = ""
outVars.value.errorOut.errorMessageAttr = "";
} else {
// Success = False
outVars.value.successOut = false;
// Error.ErrorCode = 3
outVars.value.errorOut.errorCodeAttr = "3";
// Error.ErrorMessage = "The provided URL must start with http:// or https://"
outVars.value.errorOut.errorMessageAttr = "The provided URL must start with http:// or https://";
}

} else {
// Success = False
outVars.value.successOut = false;
// Error = CheckInAppBrowserPlugin.Error
outVars.value.errorOut = checkInAppBrowserPluginVar.value.errorOut;
}

} catch (ex) {
(function () {
OS.Logger.trace("Open.Open", OS.Exceptions.getMessage(ex), ex.name);
// Handle Error: AllExceptions
if(!(OS.Exceptions.isSystem(ex))) {
OS.Logger.error(null, ex);
allExceptionsVar.value.exceptionMessageAttr = OS.Exceptions.getMessage(ex);
// Success = False
outVars.value.successOut = false;
// Error.ErrorCode = -1
outVars.value.errorOut.errorCodeAttr = (-1).toString();
// Error.ErrorMessage = AllExceptions.ExceptionMessage
outVars.value.errorOut.errorMessageAttr = allExceptionsVar.value.exceptionMessageAttr;
return outVars.value;

}

throw ex;
})();
}

return outVars.value;
};
var controller = InAppBrowserPluginController.default;
InAppBrowserPluginController.default.constructor.registerVariableGroupType("InAppBrowserPlugin.Open$vars", [{
name: "Url",
attrName: "urlInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}, {
name: "Target",
attrName: "targetInLocal",
mandatory: false,
dataType: OS.Types.Text,
defaultValue: function () {
return InAppBrowserPluginModel.staticEntities.target.iN_APP_BROWSER;
}
}, {
name: "Options",
attrName: "optionsInLocal",
mandatory: false,
dataType: OS.Types.Record,
defaultValue: function () {
return new InAppBrowserPluginModel.OptionsRec();
},
complexType: InAppBrowserPluginModel.OptionsRec
}]);
InAppBrowserPluginController.default.constructor.registerVariableGroupType("InAppBrowserPlugin.Open$outVars", [{
name: "Success",
attrName: "successOut",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}, {
name: "Error",
attrName: "errorOut",
mandatory: false,
dataType: OS.Types.Record,
defaultValue: function () {
return new CommonPluginModel.ErrorRec();
},
complexType: CommonPluginModel.ErrorRec
}]);
InAppBrowserPluginController.default.clientActionProxies.open$Action = function (urlIn, targetIn, optionsIn) {
urlIn = (urlIn === undefined) ? "" : urlIn;
targetIn = (targetIn === undefined) ? InAppBrowserPluginModel.staticEntities.target.iN_APP_BROWSER : targetIn;
optionsIn = (optionsIn === undefined) ? new InAppBrowserPluginModel.OptionsRec() : optionsIn;
return controller.executeActionInsideJSNode(InAppBrowserPluginController.default.open$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(urlIn, OS.Types.Text), targetIn, optionsIn), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
Success: OS.DataConversion.JSNodeParamConverter.to(actionResults.successOut, OS.Types.Boolean),
Error: actionResults.errorOut
};
});
};
});
define("InAppBrowserPlugin.controller$Open.OpenInAppBrowserJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
cordova.InAppBrowser.open($parameters.Url, $parameters.Target, $parameters.OptionsString);
};
});

define("InAppBrowserPlugin.controller$ParseOptions", ["exports", "OutSystems/ClientRuntime/Main", "InAppBrowserPlugin.model", "InAppBrowserPlugin.controller", "InAppBrowserPlugin.controller$ParseOptions.ConvertOptionsToStringJS", "InAppBrowserPlugin.model$OptionsRec"], function (exports, OutSystems, InAppBrowserPluginModel, InAppBrowserPluginController, InAppBrowserPlugin_controller_ParseOptions_ConvertOptionsToStringJS) {
var OS = OutSystems.Internal;
InAppBrowserPluginController.default.parseOptions$Action = function (optionsIn, callContext) {
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("InAppBrowserPlugin.ParseOptions$vars"))());
vars.value.optionsInLocal = optionsIn.clone();
var convertOptionsToStringJSResult = new OS.DataTypes.VariableHolder();
var serializeOptionsVar = new OS.DataTypes.VariableHolder(new OS.DataTypes.JSONSerializeOutputType());
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("InAppBrowserPlugin.ParseOptions$outVars"))());
// JSON Serialize: SerializeOptions
serializeOptionsVar.value.jSONOut = OS.JSONUtils.serializeToJSON(vars.value.optionsInLocal, false, false);
// Recursively iterate through the entire Options object to convert booleans into "yes"/"no" and create a comma separated string representation of the Options object
convertOptionsToStringJSResult.value = controller.safeExecuteJSNode(InAppBrowserPlugin_controller_ParseOptions_ConvertOptionsToStringJS, "ConvertOptionsToString", "ParseOptions", {
OptionsJsonStr: OS.DataConversion.JSNodeParamConverter.to(serializeOptionsVar.value.jSONOut, OS.Types.Text),
Result: OS.DataConversion.JSNodeParamConverter.to("", OS.Types.Text)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("InAppBrowserPlugin.ParseOptions$convertOptionsToStringJSResult"))();
jsNodeResult.resultOut = OS.DataConversion.JSNodeParamConverter.from($parameters.Result, OS.Types.Text);
return jsNodeResult;
}, {}, {});
// OptionsString = ConvertOptionsToString.Result
outVars.value.optionsStringOut = convertOptionsToStringJSResult.value.resultOut;
return outVars.value;
};
var controller = InAppBrowserPluginController.default;
InAppBrowserPluginController.default.constructor.registerVariableGroupType("InAppBrowserPlugin.ParseOptions$vars", [{
name: "Options",
attrName: "optionsInLocal",
mandatory: true,
dataType: OS.Types.Record,
defaultValue: function () {
return new InAppBrowserPluginModel.OptionsRec();
},
complexType: InAppBrowserPluginModel.OptionsRec
}]);
InAppBrowserPluginController.default.constructor.registerVariableGroupType("InAppBrowserPlugin.ParseOptions$convertOptionsToStringJSResult", [{
name: "Result",
attrName: "resultOut",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
InAppBrowserPluginController.default.constructor.registerVariableGroupType("InAppBrowserPlugin.ParseOptions$outVars", [{
name: "OptionsString",
attrName: "optionsStringOut",
mandatory: false,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
InAppBrowserPluginController.default.clientActionProxies.parseOptions$Action = function (optionsIn) {
optionsIn = (optionsIn === undefined) ? new InAppBrowserPluginModel.OptionsRec() : optionsIn;
return controller.executeActionInsideJSNode(InAppBrowserPluginController.default.parseOptions$Action.bind(controller, optionsIn), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
OptionsString: OS.DataConversion.JSNodeParamConverter.to(actionResults.optionsStringOut, OS.Types.Text)
};
});
};
});
define("InAppBrowserPlugin.controller$ParseOptions.ConvertOptionsToStringJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
// Recursively iterate through the entire Options object to convert booleans into "yes"/"no"
// and create a comma separated string representation of the Options object

function yesNoToBoolean(value) {
    return value === true ? "yes" : "no";
}

function convertOptionsToString(obj, path, result) {

    if (obj.constructor === Object && Object.getOwnPropertyNames(obj).length > 0) {
        for (var prop in obj) {
            result = convertOptionsToString(obj[prop], prop, result);
        }
    } else {
        if (obj !== undefined) {
            if (obj.constructor === Boolean) {
                obj = yesNoToBoolean(obj);
            }
            return result + path + "=" + obj + ",";
        } else {
            return "";
        }
    }
    return result;
}
var optionsObj = JSON.parse($parameters.OptionsJsonStr);
var result = convertOptionsToString(optionsObj, "", "");
$parameters.Result =  result.substr(0, result.lastIndexOf(","));

};
});

define("InAppBrowserPlugin.controller", ["exports", "OutSystems/ClientRuntime/Main", "InAppBrowserPlugin.model"], function (exports, OutSystems, InAppBrowserPluginModel) {
var OS = OutSystems.Internal;
var InAppBrowserPluginController = exports;
var Controller = (function (_super) {
__extends(Controller, _super);
function Controller() {
_super.apply(this, arguments);
}
Controller.prototype.clientActionProxies = {};
Controller.prototype.roles = {};
Controller.prototype.defaultTimeout = 10;
Controller.prototype.getDefaultTimeout = function () {
return InAppBrowserPluginController.default.defaultTimeout;
};
return Controller;
})(OS.Controller.BaseModuleController);
InAppBrowserPluginController.default = new Controller();
});
