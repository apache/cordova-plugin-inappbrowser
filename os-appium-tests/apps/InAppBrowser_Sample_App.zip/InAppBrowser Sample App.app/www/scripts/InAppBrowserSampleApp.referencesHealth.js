﻿define("InAppBrowserSampleApp.referencesHealth$CommonPlugin", [], function () {
// Reference to producer 'CommonPlugin' is OK.
});
define("InAppBrowserSampleApp.referencesHealth$InAppBrowserPlugin", [], function () {
// Reference to producer 'InAppBrowserPlugin' is OK.
});
define("InAppBrowserSampleApp.referencesHealth$OutSystemsUI", [], function () {
// Reference to producer 'OutSystemsUI' is OK.
});
define("InAppBrowserSampleApp.referencesHealth$Users", [], function () {
// Reference to producer 'Users' is OK.
});
define("InAppBrowserSampleApp.referencesHealth", [], function () {
});
