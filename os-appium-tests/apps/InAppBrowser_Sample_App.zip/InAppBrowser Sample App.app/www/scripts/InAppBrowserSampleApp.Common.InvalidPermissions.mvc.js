﻿define("InAppBrowserSampleApp.Common.InvalidPermissions.mvc$model", ["OutSystems/ClientRuntime/Main", "InAppBrowserSampleApp.model", "InAppBrowserSampleApp.Common.Layout.mvc$model", "InAppBrowserSampleApp.Common.MenuIcon.mvc$model", "OutSystemsUI.Content.BlankSlate.mvc$model", "InAppBrowserSampleApp.Common.BottomBar.mvc$model"], function (OutSystems, InAppBrowserSampleAppModel, InAppBrowserSampleApp_Common_Layout_mvcModel, InAppBrowserSampleApp_Common_MenuIcon_mvcModel, OutSystemsUI_Content_BlankSlate_mvcModel, InAppBrowserSampleApp_Common_BottomBar_mvcModel) {
var OS = OutSystems.Internal;


var VariablesRecord = (function (_super) {
__extends(VariablesRecord, _super);
function VariablesRecord(defaults) {
_super.apply(this, arguments);
}
VariablesRecord.attributesToDeclare = function () {
return [].concat(_super.attributesToDeclare.call(this));
};
VariablesRecord.init();
return VariablesRecord;
})(OS.DataTypes.GenericRecord);
var WidgetsRecord = (function (_super) {
__extends(WidgetsRecord, _super);
function WidgetsRecord() {
_super.apply(this, arguments);
}
WidgetsRecord.getWidgetsType = function () {
return {};
};

return WidgetsRecord;
})(OS.Model.BaseWidgetRecordMap);
var Model = (function (_super) {
__extends(Model, _super);
function Model() {
_super.apply(this, arguments);
}
Model.getVariablesRecordConstructor = function () {
return VariablesRecord;
};
Model.getWidgetsRecordConstructor = function () {
return WidgetsRecord;
};
Model._hasValidationWidgetsValue = undefined;
Object.defineProperty(Model, "hasValidationWidgets", {
enumerable: true,
configurable: true,
get: function () {
if((Model._hasValidationWidgetsValue === undefined)) {
Model._hasValidationWidgetsValue = (((InAppBrowserSampleApp_Common_Layout_mvcModel.hasValidationWidgets || InAppBrowserSampleApp_Common_MenuIcon_mvcModel.hasValidationWidgets) || OutSystemsUI_Content_BlankSlate_mvcModel.hasValidationWidgets) || InAppBrowserSampleApp_Common_BottomBar_mvcModel.hasValidationWidgets);
}

return Model._hasValidationWidgetsValue;
}
});

Model.prototype.setInputs = function (inputs) {
};
return Model;
})(OS.Model.VariablelessViewModel);
return new OS.Model.ModelFactory(Model);
});
define("InAppBrowserSampleApp.Common.InvalidPermissions.mvc$view", ["OutSystems/ClientRuntime/Main", "InAppBrowserSampleApp.model", "InAppBrowserSampleApp.controller", "react", "OutSystems/ReactView/Main", "InAppBrowserSampleApp.Common.InvalidPermissions.mvc$model", "InAppBrowserSampleApp.Common.InvalidPermissions.mvc$controller", "InAppBrowserSampleApp.Common.Layout.mvc$view", "OutSystems/ReactWidgets/Main", "InAppBrowserSampleApp.Common.MenuIcon.mvc$view", "OutSystemsUI.Content.BlankSlate.mvc$view", "InAppBrowserSampleApp.Common.BottomBar.mvc$view"], function (OutSystems, InAppBrowserSampleAppModel, InAppBrowserSampleAppController, React, OSView, InAppBrowserSampleApp_Common_InvalidPermissions_mvc_model, InAppBrowserSampleApp_Common_InvalidPermissions_mvc_controller, InAppBrowserSampleApp_Common_Layout_mvc_view, OSWidgets, InAppBrowserSampleApp_Common_MenuIcon_mvc_view, OutSystemsUI_Content_BlankSlate_mvc_view, InAppBrowserSampleApp_Common_BottomBar_mvc_view) {
    var OS = OutSystems.Internal;
var PlaceholderContent = OSView.Widget.PlaceholderContent;
var IteratorPlaceholderContent = OSView.Widget.IteratorPlaceholderContent;


    var View = (function (_super) {
        __extends(View,_super);
        function View() {
            try {
                this.initialize.apply(this, arguments);
            } catch (error) {
                View.handleError(error);
                throw error;
            }
        }
        View.prototype.initialize = function() {
            _super.apply(this, arguments);
        };
        View.displayName = "Common.InvalidPermissions";
        View.getCssDependencies = function() {
            return ["css/OutSystemsReactWidgets.css", "css/OutSystemsUI.OSUIMobileBase.css", "css/OutSystemsUI.OSUIMobilePhone.css", "css/InAppBrowserSampleApp.InAppBrowserSampleApp.css", "css/OutSystemsUI.OSUIMobilePhone.extra.css"];
        };
        View.getJsDependencies = function() {
            return [];
        };
        View.getBlocks = function() {
            return [InAppBrowserSampleApp_Common_Layout_mvc_view, InAppBrowserSampleApp_Common_MenuIcon_mvc_view, OutSystemsUI_Content_BlankSlate_mvc_view, InAppBrowserSampleApp_Common_BottomBar_mvc_view];
        };
        Object.defineProperty(View.prototype, "modelFactory", {
            get: function () {
                return InAppBrowserSampleApp_Common_InvalidPermissions_mvc_model;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "controllerFactory", {
            get: function () {
                return InAppBrowserSampleApp_Common_InvalidPermissions_mvc_controller;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "title", {
            get: function () {
                return "";
            },
            enumerable: true,
            configurable: true
        });
        View.prototype.internalRender = function() {
            var model = this.model;
            var controller = this.controller;
            var idService = this.idService;
            var validationService = controller.validationService;
            var widgetsRecordProvider = this.widgetsRecordProvider;
            var callContext = controller.callContext();
            var $if = View.ifWidget;
            var asPrimitiveValue = View.asPrimitiveValue;
            var _this = this;

            return React.DOM.div(this.getRootNodeProperties(), React.createElement(InAppBrowserSampleApp_Common_Layout_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "0",
alias: "1"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
headerLeft: new PlaceholderContent(function () {
return [React.createElement(InAppBrowserSampleApp_Common_MenuIcon_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "1",
alias: "2"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
})];
}),
title: PlaceholderContent.Empty,
headerRight: PlaceholderContent.Empty,
headerContent: PlaceholderContent.Empty,
content: new PlaceholderContent(function () {
return [React.createElement(OutSystemsUI_Content_BlankSlate_mvc_view, {
inputs: {
FullHeight: true
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "2",
alias: "3"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
icon: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Icon, {
icon: "warning",
iconSize: /*FontSize*/ 0,
style: "icon",
visible: true,
_idProps: {
service: idService,
name: "Icon1"
},
_widgetRecordProvider: widgetsRecordProvider
})];
}),
content: new PlaceholderContent(function () {
return ["You don\'t have permissions to view the required screen."];
}),
actions: PlaceholderContent.Empty
},
_dependencies: []
})];
}),
bottom: new PlaceholderContent(function () {
return [React.createElement(InAppBrowserSampleApp_Common_BottomBar_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "4",
alias: "4"
},
_widgetRecordProvider: widgetsRecordProvider,
_dependencies: []
})];
})
},
_dependencies: []
}));
        };
        return View;
    })(OSView.BaseView.BaseWebScreen);
	
    return View;
});
define("InAppBrowserSampleApp.Common.InvalidPermissions.mvc$controller", ["OutSystems/ClientRuntime/Main", "InAppBrowserSampleApp.model", "InAppBrowserSampleApp.controller", "InAppBrowserSampleApp.languageResources", "InAppBrowserSampleApp.Common.controller"], function (OutSystems, InAppBrowserSampleAppModel, InAppBrowserSampleAppController, InAppBrowserSampleAppLanguageResources, InAppBrowserSampleApp_CommonController) {
var OS = OutSystems.Internal;
var Controller = (function (_super) {
__extends(Controller, _super);
function Controller() {
_super.apply(this, arguments);
var controller = this.controller;
this.clientActionProxies = {};
this.dataFetchDependenciesOriginal = {};
this.dataFetchDependentsGraph = {};
this.useImprovedDataFetch = false;
this.hasDependenciesBetweenSources = false;
this.shouldSendClientVarsToDataSources = false;
}
// Server Actions

// Aggregates and Data Actions

Controller.prototype.dataFetchActionNames = [];
// Client Actions


// Event Handler Actions
Controller.prototype.onInitializeEventHandler = null;
Controller.prototype.onReadyEventHandler = null;
Controller.prototype.onRenderEventHandler = null;
Controller.prototype.onDestroyEventHandler = null;
Controller.prototype.onParametersChangedEventHandler = null;
Controller.prototype.handleError = function (ex) {
return InAppBrowserSampleApp_CommonController.default.handleError(ex, this.callContext());
};
Controller.checkPermissions = function () {
};
Controller.prototype.getDefaultTimeout = function () {
return InAppBrowserSampleAppController.default.defaultTimeout;
};
return Controller;
})(OS.Controller.BaseViewController);
return new OS.Controller.ControllerFactory(Controller, InAppBrowserSampleAppLanguageResources);
});

