﻿define("OutSystemsUI.model$SpaceRec", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model"], function (exports, OutSystems, OutSystemsUIModel) {
var OS = OutSystems.Internal;
var SpaceRec = (function (_super) {
__extends(SpaceRec, _super);
function SpaceRec(defaults) {
_super.apply(this, arguments);
}
SpaceRec.attributesToDeclare = function () {
return [
this.attr("Space", "spaceAttr", "Space", true, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Order", "orderAttr", "Order", true, false, OS.Types.Integer, function () {
return 0;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
SpaceRec.init();
return SpaceRec;
})(OS.DataTypes.GenericRecord);
OutSystemsUIModel.SpaceRec = SpaceRec;

});
define("OutSystemsUI.model$SpaceRecord", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.model$SpaceRec"], function (exports, OutSystems, OutSystemsUIModel) {
var OS = OutSystems.Internal;
var SpaceRecord = (function (_super) {
__extends(SpaceRecord, _super);
function SpaceRecord(defaults) {
_super.apply(this, arguments);
}
SpaceRecord.attributesToDeclare = function () {
return [
this.attr("Space", "spaceAttr", "Space", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsUIModel.SpaceRec());
}, true, OutSystemsUIModel.SpaceRec)
].concat(_super.attributesToDeclare.call(this));
};
SpaceRecord.fromStructure = function (str) {
return new SpaceRecord(new SpaceRecord.RecordClass({
spaceAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
SpaceRecord._isAnonymousRecord = true;
SpaceRecord.UniqueId = "9589ecc0-6297-88c2-aca6-b47bcbae782c";
SpaceRecord.init();
return SpaceRecord;
})(OS.DataTypes.GenericRecord);
OutSystemsUIModel.SpaceRecord = SpaceRecord;

});
define("OutSystemsUI.model$SpaceRecordList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.model$SpaceRecord"], function (exports, OutSystems, OutSystemsUIModel) {
var OS = OutSystems.Internal;
var SpaceRecordList = (function (_super) {
__extends(SpaceRecordList, _super);
function SpaceRecordList(defaults) {
_super.apply(this, arguments);
}
SpaceRecordList.itemType = OutSystemsUIModel.SpaceRecord;
return SpaceRecordList;
})(OS.DataTypes.GenericRecordList);
OutSystemsUIModel.SpaceRecordList = SpaceRecordList;

});
define("OutSystemsUI.model$DeviceConfigurationRec", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model"], function (exports, OutSystems, OutSystemsUIModel) {
var OS = OutSystems.Internal;
var DeviceConfigurationRec = (function (_super) {
__extends(DeviceConfigurationRec, _super);
function DeviceConfigurationRec(defaults) {
_super.apply(this, arguments);
}
DeviceConfigurationRec.attributesToDeclare = function () {
return [
this.attr("PhoneWidth", "phoneWidthAttr", "PhoneWidth", false, false, OS.Types.Integer, function () {
return 700;
}, true), 
this.attr("TabletWidth", "tabletWidthAttr", "TabletWidth", false, false, OS.Types.Integer, function () {
return 1024;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
DeviceConfigurationRec.init();
return DeviceConfigurationRec;
})(OS.DataTypes.GenericRecord);
OutSystemsUIModel.DeviceConfigurationRec = DeviceConfigurationRec;

});
define("OutSystemsUI.model$ShapeRec", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model"], function (exports, OutSystems, OutSystemsUIModel) {
var OS = OutSystems.Internal;
var ShapeRec = (function (_super) {
__extends(ShapeRec, _super);
function ShapeRec(defaults) {
_super.apply(this, arguments);
}
ShapeRec.attributesToDeclare = function () {
return [
this.attr("Shape", "shapeAttr", "Shape", true, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Order", "orderAttr", "Order", false, false, OS.Types.Integer, function () {
return 0;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
ShapeRec.init();
return ShapeRec;
})(OS.DataTypes.GenericRecord);
OutSystemsUIModel.ShapeRec = ShapeRec;

});
define("OutSystemsUI.model$ShapeRecord", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.model$ShapeRec"], function (exports, OutSystems, OutSystemsUIModel) {
var OS = OutSystems.Internal;
var ShapeRecord = (function (_super) {
__extends(ShapeRecord, _super);
function ShapeRecord(defaults) {
_super.apply(this, arguments);
}
ShapeRecord.attributesToDeclare = function () {
return [
this.attr("Shape", "shapeAttr", "Shape", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsUIModel.ShapeRec());
}, true, OutSystemsUIModel.ShapeRec)
].concat(_super.attributesToDeclare.call(this));
};
ShapeRecord.fromStructure = function (str) {
return new ShapeRecord(new ShapeRecord.RecordClass({
shapeAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
ShapeRecord._isAnonymousRecord = true;
ShapeRecord.UniqueId = "0a89eeb6-0fa1-f44b-6316-ca69b462007b";
ShapeRecord.init();
return ShapeRecord;
})(OS.DataTypes.GenericRecord);
OutSystemsUIModel.ShapeRecord = ShapeRecord;

});
define("OutSystemsUI.model$BulkActionsRec", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model"], function (exports, OutSystems, OutSystemsUIModel) {
var OS = OutSystems.Internal;
var BulkActionsRec = (function (_super) {
__extends(BulkActionsRec, _super);
function BulkActionsRec(defaults) {
_super.apply(this, arguments);
}
BulkActionsRec.attributesToDeclare = function () {
return [
this.attr("Value", "valueAttr", "Value", false, false, OS.Types.Boolean, function () {
return false;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
BulkActionsRec.fromStructure = function (str) {
return new BulkActionsRec(new BulkActionsRec.RecordClass({
valueAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
BulkActionsRec.init();
return BulkActionsRec;
})(OS.DataTypes.GenericRecord);
OutSystemsUIModel.BulkActionsRec = BulkActionsRec;

});
define("OutSystemsUI.model$BulkActionsList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.model$BulkActionsRec"], function (exports, OutSystems, OutSystemsUIModel) {
var OS = OutSystems.Internal;
var BulkActionsList = (function (_super) {
__extends(BulkActionsList, _super);
function BulkActionsList(defaults) {
_super.apply(this, arguments);
}
BulkActionsList.itemType = OutSystemsUIModel.BulkActionsRec;
return BulkActionsList;
})(OS.DataTypes.GenericRecordList);
OutSystemsUIModel.BulkActionsList = BulkActionsList;

});
define("OutSystemsUI.model$StepsRec", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model"], function (exports, OutSystems, OutSystemsUIModel) {
var OS = OutSystems.Internal;
var StepsRec = (function (_super) {
__extends(StepsRec, _super);
function StepsRec(defaults) {
_super.apply(this, arguments);
}
StepsRec.attributesToDeclare = function () {
return [
this.attr("Steps", "stepsAttr", "Steps", true, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
StepsRec.fromStructure = function (str) {
return new StepsRec(new StepsRec.RecordClass({
stepsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
StepsRec.init();
return StepsRec;
})(OS.DataTypes.GenericRecord);
OutSystemsUIModel.StepsRec = StepsRec;

});
define("OutSystemsUI.model$StepsRecord", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.model$StepsRec"], function (exports, OutSystems, OutSystemsUIModel) {
var OS = OutSystems.Internal;
var StepsRecord = (function (_super) {
__extends(StepsRecord, _super);
function StepsRecord(defaults) {
_super.apply(this, arguments);
}
StepsRecord.attributesToDeclare = function () {
return [
this.attr("Steps", "stepsAttr", "Steps", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsUIModel.StepsRec());
}, true, OutSystemsUIModel.StepsRec)
].concat(_super.attributesToDeclare.call(this));
};
StepsRecord.fromStructure = function (str) {
return new StepsRecord(new StepsRecord.RecordClass({
stepsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
StepsRecord._isAnonymousRecord = true;
StepsRecord.UniqueId = "0d776a4e-191f-af32-1030-d5ce57aa4167";
StepsRecord.init();
return StepsRecord;
})(OS.DataTypes.GenericRecord);
OutSystemsUIModel.StepsRecord = StepsRecord;

});
define("OutSystemsUI.model$AnimationTypeRec", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model"], function (exports, OutSystems, OutSystemsUIModel) {
var OS = OutSystems.Internal;
var AnimationTypeRec = (function (_super) {
__extends(AnimationTypeRec, _super);
function AnimationTypeRec(defaults) {
_super.apply(this, arguments);
}
AnimationTypeRec.attributesToDeclare = function () {
return [
this.attr("AnimationType", "animationTypeAttr", "AnimationType", true, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
AnimationTypeRec.fromStructure = function (str) {
return new AnimationTypeRec(new AnimationTypeRec.RecordClass({
animationTypeAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
AnimationTypeRec.init();
return AnimationTypeRec;
})(OS.DataTypes.GenericRecord);
OutSystemsUIModel.AnimationTypeRec = AnimationTypeRec;

});
define("OutSystemsUI.model$AnimationTypeRecord", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.model$AnimationTypeRec"], function (exports, OutSystems, OutSystemsUIModel) {
var OS = OutSystems.Internal;
var AnimationTypeRecord = (function (_super) {
__extends(AnimationTypeRecord, _super);
function AnimationTypeRecord(defaults) {
_super.apply(this, arguments);
}
AnimationTypeRecord.attributesToDeclare = function () {
return [
this.attr("AnimationType", "animationTypeAttr", "AnimationType", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsUIModel.AnimationTypeRec());
}, true, OutSystemsUIModel.AnimationTypeRec)
].concat(_super.attributesToDeclare.call(this));
};
AnimationTypeRecord.fromStructure = function (str) {
return new AnimationTypeRecord(new AnimationTypeRecord.RecordClass({
animationTypeAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
AnimationTypeRecord._isAnonymousRecord = true;
AnimationTypeRecord.UniqueId = "78b6d6ed-7d52-800a-8a68-e7d796ec6850";
AnimationTypeRecord.init();
return AnimationTypeRecord;
})(OS.DataTypes.GenericRecord);
OutSystemsUIModel.AnimationTypeRecord = AnimationTypeRecord;

});
define("OutSystemsUI.model$AnimationTypeRecordList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.model$AnimationTypeRecord"], function (exports, OutSystems, OutSystemsUIModel) {
var OS = OutSystems.Internal;
var AnimationTypeRecordList = (function (_super) {
__extends(AnimationTypeRecordList, _super);
function AnimationTypeRecordList(defaults) {
_super.apply(this, arguments);
}
AnimationTypeRecordList.itemType = OutSystemsUIModel.AnimationTypeRecord;
return AnimationTypeRecordList;
})(OS.DataTypes.GenericRecordList);
OutSystemsUIModel.AnimationTypeRecordList = AnimationTypeRecordList;

});
define("OutSystemsUI.model$SpaceList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.model$SpaceRec"], function (exports, OutSystems, OutSystemsUIModel) {
var OS = OutSystems.Internal;
var SpaceList = (function (_super) {
__extends(SpaceList, _super);
function SpaceList(defaults) {
_super.apply(this, arguments);
}
SpaceList.itemType = OutSystemsUIModel.SpaceRec;
return SpaceList;
})(OS.DataTypes.GenericRecordList);
OutSystemsUIModel.SpaceList = SpaceList;

});
define("OutSystemsUI.model$DeviceResponsiveRec", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model"], function (exports, OutSystems, OutSystemsUIModel) {
var OS = OutSystems.Internal;
var DeviceResponsiveRec = (function (_super) {
__extends(DeviceResponsiveRec, _super);
function DeviceResponsiveRec(defaults) {
_super.apply(this, arguments);
}
DeviceResponsiveRec.attributesToDeclare = function () {
return [
this.attr("Type", "typeAttr", "Type", true, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Order", "orderAttr", "Order", true, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("Is_Active", "is_ActiveAttr", "Is_Active", true, false, OS.Types.Boolean, function () {
return false;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
DeviceResponsiveRec.init();
return DeviceResponsiveRec;
})(OS.DataTypes.GenericRecord);
OutSystemsUIModel.DeviceResponsiveRec = DeviceResponsiveRec;

});
define("OutSystemsUI.model$DeviceResponsiveRecord", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.model$DeviceResponsiveRec"], function (exports, OutSystems, OutSystemsUIModel) {
var OS = OutSystems.Internal;
var DeviceResponsiveRecord = (function (_super) {
__extends(DeviceResponsiveRecord, _super);
function DeviceResponsiveRecord(defaults) {
_super.apply(this, arguments);
}
DeviceResponsiveRecord.attributesToDeclare = function () {
return [
this.attr("DeviceResponsive", "deviceResponsiveAttr", "DeviceResponsive", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsUIModel.DeviceResponsiveRec());
}, true, OutSystemsUIModel.DeviceResponsiveRec)
].concat(_super.attributesToDeclare.call(this));
};
DeviceResponsiveRecord.fromStructure = function (str) {
return new DeviceResponsiveRecord(new DeviceResponsiveRecord.RecordClass({
deviceResponsiveAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
DeviceResponsiveRecord._isAnonymousRecord = true;
DeviceResponsiveRecord.UniqueId = "1583be5d-90a9-4b6a-7317-0ffa868eecc5";
DeviceResponsiveRecord.init();
return DeviceResponsiveRecord;
})(OS.DataTypes.GenericRecord);
OutSystemsUIModel.DeviceResponsiveRecord = DeviceResponsiveRecord;

});
define("OutSystemsUI.model$BreakColumnsRec", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model"], function (exports, OutSystems, OutSystemsUIModel) {
var OS = OutSystems.Internal;
var BreakColumnsRec = (function (_super) {
__extends(BreakColumnsRec, _super);
function BreakColumnsRec(defaults) {
_super.apply(this, arguments);
}
BreakColumnsRec.attributesToDeclare = function () {
return [
this.attr("BreakColumns", "breakColumnsAttr", "BreakColumns", true, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
BreakColumnsRec.fromStructure = function (str) {
return new BreakColumnsRec(new BreakColumnsRec.RecordClass({
breakColumnsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
BreakColumnsRec.init();
return BreakColumnsRec;
})(OS.DataTypes.GenericRecord);
OutSystemsUIModel.BreakColumnsRec = BreakColumnsRec;

});
define("OutSystemsUI.model$MessageStatusRec", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model"], function (exports, OutSystems, OutSystemsUIModel) {
var OS = OutSystems.Internal;
var MessageStatusRec = (function (_super) {
__extends(MessageStatusRec, _super);
function MessageStatusRec(defaults) {
_super.apply(this, arguments);
}
MessageStatusRec.attributesToDeclare = function () {
return [
this.attr("Type", "typeAttr", "Type", true, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Order", "orderAttr", "Order", true, false, OS.Types.Integer, function () {
return 0;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
MessageStatusRec.init();
return MessageStatusRec;
})(OS.DataTypes.GenericRecord);
OutSystemsUIModel.MessageStatusRec = MessageStatusRec;

});
define("OutSystemsUI.model$AutoplayRec", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model"], function (exports, OutSystems, OutSystemsUIModel) {
var OS = OutSystems.Internal;
var AutoplayRec = (function (_super) {
__extends(AutoplayRec, _super);
function AutoplayRec(defaults) {
_super.apply(this, arguments);
}
AutoplayRec.attributesToDeclare = function () {
return [
this.attr("Autoplay", "autoplayAttr", "Autoplay", true, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
AutoplayRec.fromStructure = function (str) {
return new AutoplayRec(new AutoplayRec.RecordClass({
autoplayAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
AutoplayRec.init();
return AutoplayRec;
})(OS.DataTypes.GenericRecord);
OutSystemsUIModel.AutoplayRec = AutoplayRec;

});
define("OutSystemsUI.model$AutoplayRecord", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.model$AutoplayRec"], function (exports, OutSystems, OutSystemsUIModel) {
var OS = OutSystems.Internal;
var AutoplayRecord = (function (_super) {
__extends(AutoplayRecord, _super);
function AutoplayRecord(defaults) {
_super.apply(this, arguments);
}
AutoplayRecord.attributesToDeclare = function () {
return [
this.attr("Autoplay", "autoplayAttr", "Autoplay", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsUIModel.AutoplayRec());
}, true, OutSystemsUIModel.AutoplayRec)
].concat(_super.attributesToDeclare.call(this));
};
AutoplayRecord.fromStructure = function (str) {
return new AutoplayRecord(new AutoplayRecord.RecordClass({
autoplayAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
AutoplayRecord._isAnonymousRecord = true;
AutoplayRecord.UniqueId = "c6831d06-e579-de4e-dbcf-59e128b60b13";
AutoplayRecord.init();
return AutoplayRecord;
})(OS.DataTypes.GenericRecord);
OutSystemsUIModel.AutoplayRecord = AutoplayRecord;

});
define("OutSystemsUI.model$AutoplayRecordList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.model$AutoplayRecord"], function (exports, OutSystems, OutSystemsUIModel) {
var OS = OutSystems.Internal;
var AutoplayRecordList = (function (_super) {
__extends(AutoplayRecordList, _super);
function AutoplayRecordList(defaults) {
_super.apply(this, arguments);
}
AutoplayRecordList.itemType = OutSystemsUIModel.AutoplayRecord;
return AutoplayRecordList;
})(OS.DataTypes.GenericRecordList);
OutSystemsUIModel.AutoplayRecordList = AutoplayRecordList;

});
define("OutSystemsUI.model$ListNavigationRec", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model"], function (exports, OutSystems, OutSystemsUIModel) {
var OS = OutSystems.Internal;
var ListNavigationRec = (function (_super) {
__extends(ListNavigationRec, _super);
function ListNavigationRec(defaults) {
_super.apply(this, arguments);
}
ListNavigationRec.attributesToDeclare = function () {
return [
this.attr("Page", "pageAttr", "Page", true, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("StartIndex", "startIndexAttr", "StartIndex", false, false, OS.Types.Integer, function () {
return 0;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
ListNavigationRec.init();
return ListNavigationRec;
})(OS.DataTypes.GenericRecord);
OutSystemsUIModel.ListNavigationRec = ListNavigationRec;

});
define("OutSystemsUI.model$ListNavigationRecord", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.model$ListNavigationRec"], function (exports, OutSystems, OutSystemsUIModel) {
var OS = OutSystems.Internal;
var ListNavigationRecord = (function (_super) {
__extends(ListNavigationRecord, _super);
function ListNavigationRecord(defaults) {
_super.apply(this, arguments);
}
ListNavigationRecord.attributesToDeclare = function () {
return [
this.attr("ListNavigation", "listNavigationAttr", "ListNavigation", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsUIModel.ListNavigationRec());
}, true, OutSystemsUIModel.ListNavigationRec)
].concat(_super.attributesToDeclare.call(this));
};
ListNavigationRecord.fromStructure = function (str) {
return new ListNavigationRecord(new ListNavigationRecord.RecordClass({
listNavigationAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
ListNavigationRecord._isAnonymousRecord = true;
ListNavigationRecord.UniqueId = "5b37cd2b-c5a2-79c3-cc9b-8640efcc6427";
ListNavigationRecord.init();
return ListNavigationRecord;
})(OS.DataTypes.GenericRecord);
OutSystemsUIModel.ListNavigationRecord = ListNavigationRecord;

});
define("OutSystemsUI.model$ListNavigationRecordList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.model$ListNavigationRecord"], function (exports, OutSystems, OutSystemsUIModel) {
var OS = OutSystems.Internal;
var ListNavigationRecordList = (function (_super) {
__extends(ListNavigationRecordList, _super);
function ListNavigationRecordList(defaults) {
_super.apply(this, arguments);
}
ListNavigationRecordList.itemType = OutSystemsUIModel.ListNavigationRecord;
return ListNavigationRecordList;
})(OS.DataTypes.GenericRecordList);
OutSystemsUIModel.ListNavigationRecordList = ListNavigationRecordList;

});
define("OutSystemsUI.model$BulkActionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.model$BulkActionsRec"], function (exports, OutSystems, OutSystemsUIModel) {
var OS = OutSystems.Internal;
var BulkActionsRecord = (function (_super) {
__extends(BulkActionsRecord, _super);
function BulkActionsRecord(defaults) {
_super.apply(this, arguments);
}
BulkActionsRecord.attributesToDeclare = function () {
return [
this.attr("BulkActions", "bulkActionsAttr", "BulkActions", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsUIModel.BulkActionsRec());
}, true, OutSystemsUIModel.BulkActionsRec)
].concat(_super.attributesToDeclare.call(this));
};
BulkActionsRecord.fromStructure = function (str) {
return new BulkActionsRecord(new BulkActionsRecord.RecordClass({
bulkActionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
BulkActionsRecord._isAnonymousRecord = true;
BulkActionsRecord.UniqueId = "dedbf5dd-d64a-7345-04bf-3fd84b1363ec";
BulkActionsRecord.init();
return BulkActionsRecord;
})(OS.DataTypes.GenericRecord);
OutSystemsUIModel.BulkActionsRecord = BulkActionsRecord;

});
define("OutSystemsUI.model$BulkActionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.model$BulkActionsRecord"], function (exports, OutSystems, OutSystemsUIModel) {
var OS = OutSystems.Internal;
var BulkActionsRecordList = (function (_super) {
__extends(BulkActionsRecordList, _super);
function BulkActionsRecordList(defaults) {
_super.apply(this, arguments);
}
BulkActionsRecordList.itemType = OutSystemsUIModel.BulkActionsRecord;
return BulkActionsRecordList;
})(OS.DataTypes.GenericRecordList);
OutSystemsUIModel.BulkActionsRecordList = BulkActionsRecordList;

});
define("OutSystemsUI.model$BreakColumnsRecord", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.model$BreakColumnsRec"], function (exports, OutSystems, OutSystemsUIModel) {
var OS = OutSystems.Internal;
var BreakColumnsRecord = (function (_super) {
__extends(BreakColumnsRecord, _super);
function BreakColumnsRecord(defaults) {
_super.apply(this, arguments);
}
BreakColumnsRecord.attributesToDeclare = function () {
return [
this.attr("BreakColumns", "breakColumnsAttr", "BreakColumns", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsUIModel.BreakColumnsRec());
}, true, OutSystemsUIModel.BreakColumnsRec)
].concat(_super.attributesToDeclare.call(this));
};
BreakColumnsRecord.fromStructure = function (str) {
return new BreakColumnsRecord(new BreakColumnsRecord.RecordClass({
breakColumnsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
BreakColumnsRecord._isAnonymousRecord = true;
BreakColumnsRecord.UniqueId = "261685da-2c79-9bcc-3b48-73485e008694";
BreakColumnsRecord.init();
return BreakColumnsRecord;
})(OS.DataTypes.GenericRecord);
OutSystemsUIModel.BreakColumnsRecord = BreakColumnsRecord;

});
define("OutSystemsUI.model$SizeRec", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model"], function (exports, OutSystems, OutSystemsUIModel) {
var OS = OutSystems.Internal;
var SizeRec = (function (_super) {
__extends(SizeRec, _super);
function SizeRec(defaults) {
_super.apply(this, arguments);
}
SizeRec.attributesToDeclare = function () {
return [
this.attr("Size", "sizeAttr", "Size", true, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
SizeRec.fromStructure = function (str) {
return new SizeRec(new SizeRec.RecordClass({
sizeAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
SizeRec.init();
return SizeRec;
})(OS.DataTypes.GenericRecord);
OutSystemsUIModel.SizeRec = SizeRec;

});
define("OutSystemsUI.model$SizeRecord", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.model$SizeRec"], function (exports, OutSystems, OutSystemsUIModel) {
var OS = OutSystems.Internal;
var SizeRecord = (function (_super) {
__extends(SizeRecord, _super);
function SizeRecord(defaults) {
_super.apply(this, arguments);
}
SizeRecord.attributesToDeclare = function () {
return [
this.attr("Size", "sizeAttr", "Size", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsUIModel.SizeRec());
}, true, OutSystemsUIModel.SizeRec)
].concat(_super.attributesToDeclare.call(this));
};
SizeRecord.fromStructure = function (str) {
return new SizeRecord(new SizeRecord.RecordClass({
sizeAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
SizeRecord._isAnonymousRecord = true;
SizeRecord.UniqueId = "ca426fec-0751-e5b6-dcf0-15e9fdc2120e";
SizeRecord.init();
return SizeRecord;
})(OS.DataTypes.GenericRecord);
OutSystemsUIModel.SizeRecord = SizeRecord;

});
define("OutSystemsUI.model$SizeRecordList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.model$SizeRecord"], function (exports, OutSystems, OutSystemsUIModel) {
var OS = OutSystems.Internal;
var SizeRecordList = (function (_super) {
__extends(SizeRecordList, _super);
function SizeRecordList(defaults) {
_super.apply(this, arguments);
}
SizeRecordList.itemType = OutSystemsUIModel.SizeRecord;
return SizeRecordList;
})(OS.DataTypes.GenericRecordList);
OutSystemsUIModel.SizeRecordList = SizeRecordList;

});
define("OutSystemsUI.model$SpeedRec", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model"], function (exports, OutSystems, OutSystemsUIModel) {
var OS = OutSystems.Internal;
var SpeedRec = (function (_super) {
__extends(SpeedRec, _super);
function SpeedRec(defaults) {
_super.apply(this, arguments);
}
SpeedRec.attributesToDeclare = function () {
return [
this.attr("Speed", "speedAttr", "Speed", true, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
SpeedRec.fromStructure = function (str) {
return new SpeedRec(new SpeedRec.RecordClass({
speedAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
SpeedRec.init();
return SpeedRec;
})(OS.DataTypes.GenericRecord);
OutSystemsUIModel.SpeedRec = SpeedRec;

});
define("OutSystemsUI.model$MessageStatusRecord", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.model$MessageStatusRec"], function (exports, OutSystems, OutSystemsUIModel) {
var OS = OutSystems.Internal;
var MessageStatusRecord = (function (_super) {
__extends(MessageStatusRecord, _super);
function MessageStatusRecord(defaults) {
_super.apply(this, arguments);
}
MessageStatusRecord.attributesToDeclare = function () {
return [
this.attr("MessageStatus", "messageStatusAttr", "MessageStatus", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsUIModel.MessageStatusRec());
}, true, OutSystemsUIModel.MessageStatusRec)
].concat(_super.attributesToDeclare.call(this));
};
MessageStatusRecord.fromStructure = function (str) {
return new MessageStatusRecord(new MessageStatusRecord.RecordClass({
messageStatusAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
MessageStatusRecord._isAnonymousRecord = true;
MessageStatusRecord.UniqueId = "63c659b6-dc55-4b0b-4f81-d60382bf5fd6";
MessageStatusRecord.init();
return MessageStatusRecord;
})(OS.DataTypes.GenericRecord);
OutSystemsUIModel.MessageStatusRecord = MessageStatusRecord;

});
define("OutSystemsUI.model$MessageStatusRecordList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.model$MessageStatusRecord"], function (exports, OutSystems, OutSystemsUIModel) {
var OS = OutSystems.Internal;
var MessageStatusRecordList = (function (_super) {
__extends(MessageStatusRecordList, _super);
function MessageStatusRecordList(defaults) {
_super.apply(this, arguments);
}
MessageStatusRecordList.itemType = OutSystemsUIModel.MessageStatusRecord;
return MessageStatusRecordList;
})(OS.DataTypes.GenericRecordList);
OutSystemsUIModel.MessageStatusRecordList = MessageStatusRecordList;

});
define("OutSystemsUI.model$MenuActionRec", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model"], function (exports, OutSystems, OutSystemsUIModel) {
var OS = OutSystems.Internal;
var MenuActionRec = (function (_super) {
__extends(MenuActionRec, _super);
function MenuActionRec(defaults) {
_super.apply(this, arguments);
}
MenuActionRec.attributesToDeclare = function () {
return [
this.attr("MenuAction", "menuActionAttr", "MenuAction", true, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
MenuActionRec.fromStructure = function (str) {
return new MenuActionRec(new MenuActionRec.RecordClass({
menuActionAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
MenuActionRec.init();
return MenuActionRec;
})(OS.DataTypes.GenericRecord);
OutSystemsUIModel.MenuActionRec = MenuActionRec;

});
define("OutSystemsUI.model$MenuActionRecord", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.model$MenuActionRec"], function (exports, OutSystems, OutSystemsUIModel) {
var OS = OutSystems.Internal;
var MenuActionRecord = (function (_super) {
__extends(MenuActionRecord, _super);
function MenuActionRecord(defaults) {
_super.apply(this, arguments);
}
MenuActionRecord.attributesToDeclare = function () {
return [
this.attr("MenuAction", "menuActionAttr", "MenuAction", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsUIModel.MenuActionRec());
}, true, OutSystemsUIModel.MenuActionRec)
].concat(_super.attributesToDeclare.call(this));
};
MenuActionRecord.fromStructure = function (str) {
return new MenuActionRecord(new MenuActionRecord.RecordClass({
menuActionAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
MenuActionRecord._isAnonymousRecord = true;
MenuActionRecord.UniqueId = "954cd123-1210-e70f-33f1-84017bf580ac";
MenuActionRecord.init();
return MenuActionRecord;
})(OS.DataTypes.GenericRecord);
OutSystemsUIModel.MenuActionRecord = MenuActionRecord;

});
define("OutSystemsUI.model$MenuActionRecordList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.model$MenuActionRecord"], function (exports, OutSystems, OutSystemsUIModel) {
var OS = OutSystems.Internal;
var MenuActionRecordList = (function (_super) {
__extends(MenuActionRecordList, _super);
function MenuActionRecordList(defaults) {
_super.apply(this, arguments);
}
MenuActionRecordList.itemType = OutSystemsUIModel.MenuActionRecord;
return MenuActionRecordList;
})(OS.DataTypes.GenericRecordList);
OutSystemsUIModel.MenuActionRecordList = MenuActionRecordList;

});
define("OutSystemsUI.model$StackedCardsPositionRec", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model"], function (exports, OutSystems, OutSystemsUIModel) {
var OS = OutSystems.Internal;
var StackedCardsPositionRec = (function (_super) {
__extends(StackedCardsPositionRec, _super);
function StackedCardsPositionRec(defaults) {
_super.apply(this, arguments);
}
StackedCardsPositionRec.attributesToDeclare = function () {
return [
this.attr("Label", "labelAttr", "Label", true, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
StackedCardsPositionRec.fromStructure = function (str) {
return new StackedCardsPositionRec(new StackedCardsPositionRec.RecordClass({
labelAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
StackedCardsPositionRec.init();
return StackedCardsPositionRec;
})(OS.DataTypes.GenericRecord);
OutSystemsUIModel.StackedCardsPositionRec = StackedCardsPositionRec;

});
define("OutSystemsUI.model$StackedCardsPositionList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.model$StackedCardsPositionRec"], function (exports, OutSystems, OutSystemsUIModel) {
var OS = OutSystems.Internal;
var StackedCardsPositionList = (function (_super) {
__extends(StackedCardsPositionList, _super);
function StackedCardsPositionList(defaults) {
_super.apply(this, arguments);
}
StackedCardsPositionList.itemType = OutSystemsUIModel.StackedCardsPositionRec;
return StackedCardsPositionList;
})(OS.DataTypes.GenericRecordList);
OutSystemsUIModel.StackedCardsPositionList = StackedCardsPositionList;

});
define("OutSystemsUI.model$ColumnBreakRec", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model"], function (exports, OutSystems, OutSystemsUIModel) {
var OS = OutSystems.Internal;
var ColumnBreakRec = (function (_super) {
__extends(ColumnBreakRec, _super);
function ColumnBreakRec(defaults) {
_super.apply(this, arguments);
}
ColumnBreakRec.attributesToDeclare = function () {
return [
this.attr("ColumnBreak", "columnBreakAttr", "ColumnBreak", true, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
ColumnBreakRec.fromStructure = function (str) {
return new ColumnBreakRec(new ColumnBreakRec.RecordClass({
columnBreakAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
ColumnBreakRec.init();
return ColumnBreakRec;
})(OS.DataTypes.GenericRecord);
OutSystemsUIModel.ColumnBreakRec = ColumnBreakRec;

});
define("OutSystemsUI.model$ColumnBreakList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.model$ColumnBreakRec"], function (exports, OutSystems, OutSystemsUIModel) {
var OS = OutSystems.Internal;
var ColumnBreakList = (function (_super) {
__extends(ColumnBreakList, _super);
function ColumnBreakList(defaults) {
_super.apply(this, arguments);
}
ColumnBreakList.itemType = OutSystemsUIModel.ColumnBreakRec;
return ColumnBreakList;
})(OS.DataTypes.GenericRecordList);
OutSystemsUIModel.ColumnBreakList = ColumnBreakList;

});
define("OutSystemsUI.model$DEPRECATED_ColorRec", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model"], function (exports, OutSystems, OutSystemsUIModel) {
var OS = OutSystems.Internal;
var DEPRECATED_ColorRec = (function (_super) {
__extends(DEPRECATED_ColorRec, _super);
function DEPRECATED_ColorRec(defaults) {
_super.apply(this, arguments);
}
DEPRECATED_ColorRec.attributesToDeclare = function () {
return [
this.attr("Color", "colorAttr", "Color", true, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
DEPRECATED_ColorRec.fromStructure = function (str) {
return new DEPRECATED_ColorRec(new DEPRECATED_ColorRec.RecordClass({
colorAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
DEPRECATED_ColorRec.init();
return DEPRECATED_ColorRec;
})(OS.DataTypes.GenericRecord);
OutSystemsUIModel.DEPRECATED_ColorRec = DEPRECATED_ColorRec;

});
define("OutSystemsUI.model$DEPRECATED_ColorList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.model$DEPRECATED_ColorRec"], function (exports, OutSystems, OutSystemsUIModel) {
var OS = OutSystems.Internal;
var DEPRECATED_ColorList = (function (_super) {
__extends(DEPRECATED_ColorList, _super);
function DEPRECATED_ColorList(defaults) {
_super.apply(this, arguments);
}
DEPRECATED_ColorList.itemType = OutSystemsUIModel.DEPRECATED_ColorRec;
return DEPRECATED_ColorList;
})(OS.DataTypes.GenericRecordList);
OutSystemsUIModel.DEPRECATED_ColorList = DEPRECATED_ColorList;

});
define("OutSystemsUI.model$DropdownItemRec", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model"], function (exports, OutSystems, OutSystemsUIModel) {
var OS = OutSystems.Internal;
var DropdownItemRec = (function (_super) {
__extends(DropdownItemRec, _super);
function DropdownItemRec(defaults) {
_super.apply(this, arguments);
}
DropdownItemRec.attributesToDeclare = function () {
return [
this.attr("Value", "valueAttr", "Value", true, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Text", "textAttr", "Text", true, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
DropdownItemRec.init();
return DropdownItemRec;
})(OS.DataTypes.GenericRecord);
OutSystemsUIModel.DropdownItemRec = DropdownItemRec;

});
define("OutSystemsUI.model$GutterSizeRec", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model"], function (exports, OutSystems, OutSystemsUIModel) {
var OS = OutSystems.Internal;
var GutterSizeRec = (function (_super) {
__extends(GutterSizeRec, _super);
function GutterSizeRec(defaults) {
_super.apply(this, arguments);
}
GutterSizeRec.attributesToDeclare = function () {
return [
this.attr("GutterSize", "gutterSizeAttr", "GutterSize", true, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Order", "orderAttr", "Order", true, false, OS.Types.Integer, function () {
return 0;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
GutterSizeRec.init();
return GutterSizeRec;
})(OS.DataTypes.GenericRecord);
OutSystemsUIModel.GutterSizeRec = GutterSizeRec;

});
define("OutSystemsUI.model$MenuActionList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.model$MenuActionRec"], function (exports, OutSystems, OutSystemsUIModel) {
var OS = OutSystems.Internal;
var MenuActionList = (function (_super) {
__extends(MenuActionList, _super);
function MenuActionList(defaults) {
_super.apply(this, arguments);
}
MenuActionList.itemType = OutSystemsUIModel.MenuActionRec;
return MenuActionList;
})(OS.DataTypes.GenericRecordList);
OutSystemsUIModel.MenuActionList = MenuActionList;

});
define("OutSystemsUI.model$BreakColumnsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.model$BreakColumnsRecord"], function (exports, OutSystems, OutSystemsUIModel) {
var OS = OutSystems.Internal;
var BreakColumnsRecordList = (function (_super) {
__extends(BreakColumnsRecordList, _super);
function BreakColumnsRecordList(defaults) {
_super.apply(this, arguments);
}
BreakColumnsRecordList.itemType = OutSystemsUIModel.BreakColumnsRecord;
return BreakColumnsRecordList;
})(OS.DataTypes.GenericRecordList);
OutSystemsUIModel.BreakColumnsRecordList = BreakColumnsRecordList;

});
define("OutSystemsUI.model$DEPRECATED_MasterDetailItemRec", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model"], function (exports, OutSystems, OutSystemsUIModel) {
var OS = OutSystems.Internal;
var DEPRECATED_MasterDetailItemRec = (function (_super) {
__extends(DEPRECATED_MasterDetailItemRec, _super);
function DEPRECATED_MasterDetailItemRec(defaults) {
_super.apply(this, arguments);
}
DEPRECATED_MasterDetailItemRec.attributesToDeclare = function () {
return [
this.attr("Id", "idAttr", "Id", false, false, OS.Types.LongInteger, function () {
return OS.DataTypes.LongInteger.defaultValue;
}, true), 
this.attr("Title", "titleAttr", "Title", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Description", "descriptionAttr", "Description", false, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("ImageUrl", "imageUrlAttr", "ImageUrl", false, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
DEPRECATED_MasterDetailItemRec.init();
return DEPRECATED_MasterDetailItemRec;
})(OS.DataTypes.GenericRecord);
OutSystemsUIModel.DEPRECATED_MasterDetailItemRec = DEPRECATED_MasterDetailItemRec;

});
define("OutSystemsUI.model$ShapeList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.model$ShapeRec"], function (exports, OutSystems, OutSystemsUIModel) {
var OS = OutSystems.Internal;
var ShapeList = (function (_super) {
__extends(ShapeList, _super);
function ShapeList(defaults) {
_super.apply(this, arguments);
}
ShapeList.itemType = OutSystemsUIModel.ShapeRec;
return ShapeList;
})(OS.DataTypes.GenericRecordList);
OutSystemsUIModel.ShapeList = ShapeList;

});
define("OutSystemsUI.model$DropdownItemRecord", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.model$DropdownItemRec"], function (exports, OutSystems, OutSystemsUIModel) {
var OS = OutSystems.Internal;
var DropdownItemRecord = (function (_super) {
__extends(DropdownItemRecord, _super);
function DropdownItemRecord(defaults) {
_super.apply(this, arguments);
}
DropdownItemRecord.attributesToDeclare = function () {
return [
this.attr("DropdownItem", "dropdownItemAttr", "DropdownItem", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsUIModel.DropdownItemRec());
}, true, OutSystemsUIModel.DropdownItemRec)
].concat(_super.attributesToDeclare.call(this));
};
DropdownItemRecord.fromStructure = function (str) {
return new DropdownItemRecord(new DropdownItemRecord.RecordClass({
dropdownItemAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
DropdownItemRecord._isAnonymousRecord = true;
DropdownItemRecord.UniqueId = "56805fde-f633-2e01-f13c-0f9217357dbc";
DropdownItemRecord.init();
return DropdownItemRecord;
})(OS.DataTypes.GenericRecord);
OutSystemsUIModel.DropdownItemRecord = DropdownItemRecord;

});
define("OutSystemsUI.model$ListNavigationList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.model$ListNavigationRec"], function (exports, OutSystems, OutSystemsUIModel) {
var OS = OutSystems.Internal;
var ListNavigationList = (function (_super) {
__extends(ListNavigationList, _super);
function ListNavigationList(defaults) {
_super.apply(this, arguments);
}
ListNavigationList.itemType = OutSystemsUIModel.ListNavigationRec;
return ListNavigationList;
})(OS.DataTypes.GenericRecordList);
OutSystemsUIModel.ListNavigationList = ListNavigationList;

});
define("OutSystemsUI.model$PositionRec", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model"], function (exports, OutSystems, OutSystemsUIModel) {
var OS = OutSystems.Internal;
var PositionRec = (function (_super) {
__extends(PositionRec, _super);
function PositionRec(defaults) {
_super.apply(this, arguments);
}
PositionRec.attributesToDeclare = function () {
return [
this.attr("Position", "positionAttr", "Position", true, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
PositionRec.fromStructure = function (str) {
return new PositionRec(new PositionRec.RecordClass({
positionAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
PositionRec.init();
return PositionRec;
})(OS.DataTypes.GenericRecord);
OutSystemsUIModel.PositionRec = PositionRec;

});
define("OutSystemsUI.model$PositionRecord", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.model$PositionRec"], function (exports, OutSystems, OutSystemsUIModel) {
var OS = OutSystems.Internal;
var PositionRecord = (function (_super) {
__extends(PositionRecord, _super);
function PositionRecord(defaults) {
_super.apply(this, arguments);
}
PositionRecord.attributesToDeclare = function () {
return [
this.attr("Position", "positionAttr", "Position", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsUIModel.PositionRec());
}, true, OutSystemsUIModel.PositionRec)
].concat(_super.attributesToDeclare.call(this));
};
PositionRecord.fromStructure = function (str) {
return new PositionRecord(new PositionRecord.RecordClass({
positionAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
PositionRecord._isAnonymousRecord = true;
PositionRecord.UniqueId = "5f28219a-5e30-fb90-023f-cbc295513e7c";
PositionRecord.init();
return PositionRecord;
})(OS.DataTypes.GenericRecord);
OutSystemsUIModel.PositionRecord = PositionRecord;

});
define("OutSystemsUI.model$PositionRecordList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.model$PositionRecord"], function (exports, OutSystems, OutSystemsUIModel) {
var OS = OutSystems.Internal;
var PositionRecordList = (function (_super) {
__extends(PositionRecordList, _super);
function PositionRecordList(defaults) {
_super.apply(this, arguments);
}
PositionRecordList.itemType = OutSystemsUIModel.PositionRecord;
return PositionRecordList;
})(OS.DataTypes.GenericRecordList);
OutSystemsUIModel.PositionRecordList = PositionRecordList;

});
define("OutSystemsUI.model$DEPRECATED_MasterDetailItemRecord", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.model$DEPRECATED_MasterDetailItemRec"], function (exports, OutSystems, OutSystemsUIModel) {
var OS = OutSystems.Internal;
var DEPRECATED_MasterDetailItemRecord = (function (_super) {
__extends(DEPRECATED_MasterDetailItemRecord, _super);
function DEPRECATED_MasterDetailItemRecord(defaults) {
_super.apply(this, arguments);
}
DEPRECATED_MasterDetailItemRecord.attributesToDeclare = function () {
return [
this.attr("DEPRECATED_MasterDetailItem", "dEPRECATED_MasterDetailItemAttr", "DEPRECATED_MasterDetailItem", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsUIModel.DEPRECATED_MasterDetailItemRec());
}, true, OutSystemsUIModel.DEPRECATED_MasterDetailItemRec)
].concat(_super.attributesToDeclare.call(this));
};
DEPRECATED_MasterDetailItemRecord.fromStructure = function (str) {
return new DEPRECATED_MasterDetailItemRecord(new DEPRECATED_MasterDetailItemRecord.RecordClass({
dEPRECATED_MasterDetailItemAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
DEPRECATED_MasterDetailItemRecord._isAnonymousRecord = true;
DEPRECATED_MasterDetailItemRecord.UniqueId = "c7e749f2-1266-5bf8-3f6d-7b6126e9e92e";
DEPRECATED_MasterDetailItemRecord.init();
return DEPRECATED_MasterDetailItemRecord;
})(OS.DataTypes.GenericRecord);
OutSystemsUIModel.DEPRECATED_MasterDetailItemRecord = DEPRECATED_MasterDetailItemRecord;

});
define("OutSystemsUI.model$DEPRECATED_MasterDetailItemRecordList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.model$DEPRECATED_MasterDetailItemRecord"], function (exports, OutSystems, OutSystemsUIModel) {
var OS = OutSystems.Internal;
var DEPRECATED_MasterDetailItemRecordList = (function (_super) {
__extends(DEPRECATED_MasterDetailItemRecordList, _super);
function DEPRECATED_MasterDetailItemRecordList(defaults) {
_super.apply(this, arguments);
}
DEPRECATED_MasterDetailItemRecordList.itemType = OutSystemsUIModel.DEPRECATED_MasterDetailItemRecord;
return DEPRECATED_MasterDetailItemRecordList;
})(OS.DataTypes.GenericRecordList);
OutSystemsUIModel.DEPRECATED_MasterDetailItemRecordList = DEPRECATED_MasterDetailItemRecordList;

});
define("OutSystemsUI.model$BreakColumnsList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.model$BreakColumnsRec"], function (exports, OutSystems, OutSystemsUIModel) {
var OS = OutSystems.Internal;
var BreakColumnsList = (function (_super) {
__extends(BreakColumnsList, _super);
function BreakColumnsList(defaults) {
_super.apply(this, arguments);
}
BreakColumnsList.itemType = OutSystemsUIModel.BreakColumnsRec;
return BreakColumnsList;
})(OS.DataTypes.GenericRecordList);
OutSystemsUIModel.BreakColumnsList = BreakColumnsList;

});
define("OutSystemsUI.model$ShapeRecordList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.model$ShapeRecord"], function (exports, OutSystems, OutSystemsUIModel) {
var OS = OutSystems.Internal;
var ShapeRecordList = (function (_super) {
__extends(ShapeRecordList, _super);
function ShapeRecordList(defaults) {
_super.apply(this, arguments);
}
ShapeRecordList.itemType = OutSystemsUIModel.ShapeRecord;
return ShapeRecordList;
})(OS.DataTypes.GenericRecordList);
OutSystemsUIModel.ShapeRecordList = ShapeRecordList;

});
define("OutSystemsUI.model$DeviceConfigurationRecord", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.model$DeviceConfigurationRec"], function (exports, OutSystems, OutSystemsUIModel) {
var OS = OutSystems.Internal;
var DeviceConfigurationRecord = (function (_super) {
__extends(DeviceConfigurationRecord, _super);
function DeviceConfigurationRecord(defaults) {
_super.apply(this, arguments);
}
DeviceConfigurationRecord.attributesToDeclare = function () {
return [
this.attr("DeviceConfiguration", "deviceConfigurationAttr", "DeviceConfiguration", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsUIModel.DeviceConfigurationRec());
}, true, OutSystemsUIModel.DeviceConfigurationRec)
].concat(_super.attributesToDeclare.call(this));
};
DeviceConfigurationRecord.fromStructure = function (str) {
return new DeviceConfigurationRecord(new DeviceConfigurationRecord.RecordClass({
deviceConfigurationAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
DeviceConfigurationRecord._isAnonymousRecord = true;
DeviceConfigurationRecord.UniqueId = "abb6a3eb-a858-3e4a-b062-5de8f38fb719";
DeviceConfigurationRecord.init();
return DeviceConfigurationRecord;
})(OS.DataTypes.GenericRecord);
OutSystemsUIModel.DeviceConfigurationRecord = DeviceConfigurationRecord;

});
define("OutSystemsUI.model$DeviceConfigurationRecordList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.model$DeviceConfigurationRecord"], function (exports, OutSystems, OutSystemsUIModel) {
var OS = OutSystems.Internal;
var DeviceConfigurationRecordList = (function (_super) {
__extends(DeviceConfigurationRecordList, _super);
function DeviceConfigurationRecordList(defaults) {
_super.apply(this, arguments);
}
DeviceConfigurationRecordList.itemType = OutSystemsUIModel.DeviceConfigurationRecord;
return DeviceConfigurationRecordList;
})(OS.DataTypes.GenericRecordList);
OutSystemsUIModel.DeviceConfigurationRecordList = DeviceConfigurationRecordList;

});
define("OutSystemsUI.model$MessageStatusList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.model$MessageStatusRec"], function (exports, OutSystems, OutSystemsUIModel) {
var OS = OutSystems.Internal;
var MessageStatusList = (function (_super) {
__extends(MessageStatusList, _super);
function MessageStatusList(defaults) {
_super.apply(this, arguments);
}
MessageStatusList.itemType = OutSystemsUIModel.MessageStatusRec;
return MessageStatusList;
})(OS.DataTypes.GenericRecordList);
OutSystemsUIModel.MessageStatusList = MessageStatusList;

});
define("OutSystemsUI.model$StackedCardsPositionRecord", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.model$StackedCardsPositionRec"], function (exports, OutSystems, OutSystemsUIModel) {
var OS = OutSystems.Internal;
var StackedCardsPositionRecord = (function (_super) {
__extends(StackedCardsPositionRecord, _super);
function StackedCardsPositionRecord(defaults) {
_super.apply(this, arguments);
}
StackedCardsPositionRecord.attributesToDeclare = function () {
return [
this.attr("StackedCardsPosition", "stackedCardsPositionAttr", "StackedCardsPosition", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsUIModel.StackedCardsPositionRec());
}, true, OutSystemsUIModel.StackedCardsPositionRec)
].concat(_super.attributesToDeclare.call(this));
};
StackedCardsPositionRecord.fromStructure = function (str) {
return new StackedCardsPositionRecord(new StackedCardsPositionRecord.RecordClass({
stackedCardsPositionAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
StackedCardsPositionRecord._isAnonymousRecord = true;
StackedCardsPositionRecord.UniqueId = "967cb657-10fd-1a34-6ebf-0b0d8dbea56b";
StackedCardsPositionRecord.init();
return StackedCardsPositionRecord;
})(OS.DataTypes.GenericRecord);
OutSystemsUIModel.StackedCardsPositionRecord = StackedCardsPositionRecord;

});
define("OutSystemsUI.model$StackedCardsPositionRecordList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.model$StackedCardsPositionRecord"], function (exports, OutSystems, OutSystemsUIModel) {
var OS = OutSystems.Internal;
var StackedCardsPositionRecordList = (function (_super) {
__extends(StackedCardsPositionRecordList, _super);
function StackedCardsPositionRecordList(defaults) {
_super.apply(this, arguments);
}
StackedCardsPositionRecordList.itemType = OutSystemsUIModel.StackedCardsPositionRecord;
return StackedCardsPositionRecordList;
})(OS.DataTypes.GenericRecordList);
OutSystemsUIModel.StackedCardsPositionRecordList = StackedCardsPositionRecordList;

});
define("OutSystemsUI.model$BooleanBooleanIntegerIntegerIntegerIntegerIntegerIntegerRecord", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model"], function (exports, OutSystems, OutSystemsUIModel) {
var OS = OutSystems.Internal;
var BooleanBooleanIntegerIntegerIntegerIntegerIntegerIntegerRecord = (function (_super) {
__extends(BooleanBooleanIntegerIntegerIntegerIntegerIntegerIntegerRecord, _super);
function BooleanBooleanIntegerIntegerIntegerIntegerIntegerIntegerRecord(defaults) {
_super.apply(this, arguments);
}
BooleanBooleanIntegerIntegerIntegerIntegerIntegerIntegerRecord.attributesToDeclare = function () {
return [
this.attr("ChangeEventDuringSlide", "changeEventDuringSlideAttr", "ChangeEventDuringSlide", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("ShowPips", "showPipsAttr", "ShowPips", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("InitialIntervalEnd", "initialIntervalEndAttr", "InitialIntervalEnd", false, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("InitialIntervalStart", "initialIntervalStartAttr", "InitialIntervalStart", false, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("MaxValue", "maxValueAttr", "MaxValue", false, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("MinValue", "minValueAttr", "MinValue", false, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("PipsStep", "pipsStepAttr", "PipsStep", false, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("Step", "stepAttr", "Step", false, false, OS.Types.Integer, function () {
return 0;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
BooleanBooleanIntegerIntegerIntegerIntegerIntegerIntegerRecord._isAnonymousRecord = true;
BooleanBooleanIntegerIntegerIntegerIntegerIntegerIntegerRecord.UniqueId = "845b5f28-a6e4-8277-561b-d4b51c5e965a";
BooleanBooleanIntegerIntegerIntegerIntegerIntegerIntegerRecord.init();
return BooleanBooleanIntegerIntegerIntegerIntegerIntegerIntegerRecord;
})(OS.DataTypes.GenericRecord);
OutSystemsUIModel.BooleanBooleanIntegerIntegerIntegerIntegerIntegerIntegerRecord = BooleanBooleanIntegerIntegerIntegerIntegerIntegerIntegerRecord;

});
define("OutSystemsUI.model$BooleanBooleanIntegerIntegerIntegerIntegerIntegerIntegerRecordList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.model$BooleanBooleanIntegerIntegerIntegerIntegerIntegerIntegerRecord"], function (exports, OutSystems, OutSystemsUIModel) {
var OS = OutSystems.Internal;
var BooleanBooleanIntegerIntegerIntegerIntegerIntegerIntegerRecordList = (function (_super) {
__extends(BooleanBooleanIntegerIntegerIntegerIntegerIntegerIntegerRecordList, _super);
function BooleanBooleanIntegerIntegerIntegerIntegerIntegerIntegerRecordList(defaults) {
_super.apply(this, arguments);
}
BooleanBooleanIntegerIntegerIntegerIntegerIntegerIntegerRecordList.itemType = OutSystemsUIModel.BooleanBooleanIntegerIntegerIntegerIntegerIntegerIntegerRecord;
return BooleanBooleanIntegerIntegerIntegerIntegerIntegerIntegerRecordList;
})(OS.DataTypes.GenericRecordList);
OutSystemsUIModel.BooleanBooleanIntegerIntegerIntegerIntegerIntegerIntegerRecordList = BooleanBooleanIntegerIntegerIntegerIntegerIntegerIntegerRecordList;

});
define("OutSystemsUI.model$DeviceResponsiveRecordList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.model$DeviceResponsiveRecord"], function (exports, OutSystems, OutSystemsUIModel) {
var OS = OutSystems.Internal;
var DeviceResponsiveRecordList = (function (_super) {
__extends(DeviceResponsiveRecordList, _super);
function DeviceResponsiveRecordList(defaults) {
_super.apply(this, arguments);
}
DeviceResponsiveRecordList.itemType = OutSystemsUIModel.DeviceResponsiveRecord;
return DeviceResponsiveRecordList;
})(OS.DataTypes.GenericRecordList);
OutSystemsUIModel.DeviceResponsiveRecordList = DeviceResponsiveRecordList;

});
define("OutSystemsUI.model$ColorRec", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model"], function (exports, OutSystems, OutSystemsUIModel) {
var OS = OutSystems.Internal;
var ColorRec = (function (_super) {
__extends(ColorRec, _super);
function ColorRec(defaults) {
_super.apply(this, arguments);
}
ColorRec.attributesToDeclare = function () {
return [
this.attr("Color", "colorAttr", "Color", true, false, OS.Types.Text, function () {
return "";
}, true), 
this.attr("Order", "orderAttr", "Order", true, false, OS.Types.Integer, function () {
return 0;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
ColorRec.init();
return ColorRec;
})(OS.DataTypes.GenericRecord);
OutSystemsUIModel.ColorRec = ColorRec;

});
define("OutSystemsUI.model$ColorRecord", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.model$ColorRec"], function (exports, OutSystems, OutSystemsUIModel) {
var OS = OutSystems.Internal;
var ColorRecord = (function (_super) {
__extends(ColorRecord, _super);
function ColorRecord(defaults) {
_super.apply(this, arguments);
}
ColorRecord.attributesToDeclare = function () {
return [
this.attr("Color", "colorAttr", "Color", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsUIModel.ColorRec());
}, true, OutSystemsUIModel.ColorRec)
].concat(_super.attributesToDeclare.call(this));
};
ColorRecord.fromStructure = function (str) {
return new ColorRecord(new ColorRecord.RecordClass({
colorAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
ColorRecord._isAnonymousRecord = true;
ColorRecord.UniqueId = "87351e3b-0fa2-ca59-cf6c-6749c6405006";
ColorRecord.init();
return ColorRecord;
})(OS.DataTypes.GenericRecord);
OutSystemsUIModel.ColorRecord = ColorRecord;

});
define("OutSystemsUI.model$SizeList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.model$SizeRec"], function (exports, OutSystems, OutSystemsUIModel) {
var OS = OutSystems.Internal;
var SizeList = (function (_super) {
__extends(SizeList, _super);
function SizeList(defaults) {
_super.apply(this, arguments);
}
SizeList.itemType = OutSystemsUIModel.SizeRec;
return SizeList;
})(OS.DataTypes.GenericRecordList);
OutSystemsUIModel.SizeList = SizeList;

});
define("OutSystemsUI.model$AlertRec", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model"], function (exports, OutSystems, OutSystemsUIModel) {
var OS = OutSystems.Internal;
var AlertRec = (function (_super) {
__extends(AlertRec, _super);
function AlertRec(defaults) {
_super.apply(this, arguments);
}
AlertRec.attributesToDeclare = function () {
return [
this.attr("Alert", "alertAttr", "Alert", true, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
AlertRec.fromStructure = function (str) {
return new AlertRec(new AlertRec.RecordClass({
alertAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
AlertRec.init();
return AlertRec;
})(OS.DataTypes.GenericRecord);
OutSystemsUIModel.AlertRec = AlertRec;

});
define("OutSystemsUI.model$AlertRecord", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.model$AlertRec"], function (exports, OutSystems, OutSystemsUIModel) {
var OS = OutSystems.Internal;
var AlertRecord = (function (_super) {
__extends(AlertRecord, _super);
function AlertRecord(defaults) {
_super.apply(this, arguments);
}
AlertRecord.attributesToDeclare = function () {
return [
this.attr("Alert", "alertAttr", "Alert", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsUIModel.AlertRec());
}, true, OutSystemsUIModel.AlertRec)
].concat(_super.attributesToDeclare.call(this));
};
AlertRecord.fromStructure = function (str) {
return new AlertRecord(new AlertRecord.RecordClass({
alertAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
AlertRecord._isAnonymousRecord = true;
AlertRecord.UniqueId = "9ca6a18c-c49c-a724-6c44-c0f7c2cef62a";
AlertRecord.init();
return AlertRecord;
})(OS.DataTypes.GenericRecord);
OutSystemsUIModel.AlertRecord = AlertRecord;

});
define("OutSystemsUI.model$ColorRecordList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.model$ColorRecord"], function (exports, OutSystems, OutSystemsUIModel) {
var OS = OutSystems.Internal;
var ColorRecordList = (function (_super) {
__extends(ColorRecordList, _super);
function ColorRecordList(defaults) {
_super.apply(this, arguments);
}
ColorRecordList.itemType = OutSystemsUIModel.ColorRecord;
return ColorRecordList;
})(OS.DataTypes.GenericRecordList);
OutSystemsUIModel.ColorRecordList = ColorRecordList;

});
define("OutSystemsUI.model$AnimationTypeList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.model$AnimationTypeRec"], function (exports, OutSystems, OutSystemsUIModel) {
var OS = OutSystems.Internal;
var AnimationTypeList = (function (_super) {
__extends(AnimationTypeList, _super);
function AnimationTypeList(defaults) {
_super.apply(this, arguments);
}
AnimationTypeList.itemType = OutSystemsUIModel.AnimationTypeRec;
return AnimationTypeList;
})(OS.DataTypes.GenericRecordList);
OutSystemsUIModel.AnimationTypeList = AnimationTypeList;

});
define("OutSystemsUI.model$GutterSizeRecord", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.model$GutterSizeRec"], function (exports, OutSystems, OutSystemsUIModel) {
var OS = OutSystems.Internal;
var GutterSizeRecord = (function (_super) {
__extends(GutterSizeRecord, _super);
function GutterSizeRecord(defaults) {
_super.apply(this, arguments);
}
GutterSizeRecord.attributesToDeclare = function () {
return [
this.attr("GutterSize", "gutterSizeAttr", "GutterSize", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsUIModel.GutterSizeRec());
}, true, OutSystemsUIModel.GutterSizeRec)
].concat(_super.attributesToDeclare.call(this));
};
GutterSizeRecord.fromStructure = function (str) {
return new GutterSizeRecord(new GutterSizeRecord.RecordClass({
gutterSizeAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
GutterSizeRecord._isAnonymousRecord = true;
GutterSizeRecord.UniqueId = "a5018402-fa6c-90c5-e826-e54b2748cedc";
GutterSizeRecord.init();
return GutterSizeRecord;
})(OS.DataTypes.GenericRecord);
OutSystemsUIModel.GutterSizeRecord = GutterSizeRecord;

});
define("OutSystemsUI.model$DEPRECATED_ColorRecord", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.model$DEPRECATED_ColorRec"], function (exports, OutSystems, OutSystemsUIModel) {
var OS = OutSystems.Internal;
var DEPRECATED_ColorRecord = (function (_super) {
__extends(DEPRECATED_ColorRecord, _super);
function DEPRECATED_ColorRecord(defaults) {
_super.apply(this, arguments);
}
DEPRECATED_ColorRecord.attributesToDeclare = function () {
return [
this.attr("DEPRECATED_Color", "dEPRECATED_ColorAttr", "DEPRECATED_Color", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsUIModel.DEPRECATED_ColorRec());
}, true, OutSystemsUIModel.DEPRECATED_ColorRec)
].concat(_super.attributesToDeclare.call(this));
};
DEPRECATED_ColorRecord.fromStructure = function (str) {
return new DEPRECATED_ColorRecord(new DEPRECATED_ColorRecord.RecordClass({
dEPRECATED_ColorAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
DEPRECATED_ColorRecord._isAnonymousRecord = true;
DEPRECATED_ColorRecord.UniqueId = "c47826b7-e423-2fbf-8907-84243715f5a8";
DEPRECATED_ColorRecord.init();
return DEPRECATED_ColorRecord;
})(OS.DataTypes.GenericRecord);
OutSystemsUIModel.DEPRECATED_ColorRecord = DEPRECATED_ColorRecord;

});
define("OutSystemsUI.model$DEPRECATED_ColorRecordList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.model$DEPRECATED_ColorRecord"], function (exports, OutSystems, OutSystemsUIModel) {
var OS = OutSystems.Internal;
var DEPRECATED_ColorRecordList = (function (_super) {
__extends(DEPRECATED_ColorRecordList, _super);
function DEPRECATED_ColorRecordList(defaults) {
_super.apply(this, arguments);
}
DEPRECATED_ColorRecordList.itemType = OutSystemsUIModel.DEPRECATED_ColorRecord;
return DEPRECATED_ColorRecordList;
})(OS.DataTypes.GenericRecordList);
OutSystemsUIModel.DEPRECATED_ColorRecordList = DEPRECATED_ColorRecordList;

});
define("OutSystemsUI.model$AlertList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.model$AlertRec"], function (exports, OutSystems, OutSystemsUIModel) {
var OS = OutSystems.Internal;
var AlertList = (function (_super) {
__extends(AlertList, _super);
function AlertList(defaults) {
_super.apply(this, arguments);
}
AlertList.itemType = OutSystemsUIModel.AlertRec;
return AlertList;
})(OS.DataTypes.GenericRecordList);
OutSystemsUIModel.AlertList = AlertList;

});
define("OutSystemsUI.model$DeviceConfigurationList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.model$DeviceConfigurationRec"], function (exports, OutSystems, OutSystemsUIModel) {
var OS = OutSystems.Internal;
var DeviceConfigurationList = (function (_super) {
__extends(DeviceConfigurationList, _super);
function DeviceConfigurationList(defaults) {
_super.apply(this, arguments);
}
DeviceConfigurationList.itemType = OutSystemsUIModel.DeviceConfigurationRec;
return DeviceConfigurationList;
})(OS.DataTypes.GenericRecordList);
OutSystemsUIModel.DeviceConfigurationList = DeviceConfigurationList;

});
define("OutSystemsUI.model$ColumnBreakRecord", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.model$ColumnBreakRec"], function (exports, OutSystems, OutSystemsUIModel) {
var OS = OutSystems.Internal;
var ColumnBreakRecord = (function (_super) {
__extends(ColumnBreakRecord, _super);
function ColumnBreakRecord(defaults) {
_super.apply(this, arguments);
}
ColumnBreakRecord.attributesToDeclare = function () {
return [
this.attr("ColumnBreak", "columnBreakAttr", "ColumnBreak", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsUIModel.ColumnBreakRec());
}, true, OutSystemsUIModel.ColumnBreakRec)
].concat(_super.attributesToDeclare.call(this));
};
ColumnBreakRecord.fromStructure = function (str) {
return new ColumnBreakRecord(new ColumnBreakRecord.RecordClass({
columnBreakAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
ColumnBreakRecord._isAnonymousRecord = true;
ColumnBreakRecord.UniqueId = "b6adbbf4-e08b-ad29-75a6-f8f796279b71";
ColumnBreakRecord.init();
return ColumnBreakRecord;
})(OS.DataTypes.GenericRecord);
OutSystemsUIModel.ColumnBreakRecord = ColumnBreakRecord;

});
define("OutSystemsUI.model$ColumnBreakRecordList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.model$ColumnBreakRecord"], function (exports, OutSystems, OutSystemsUIModel) {
var OS = OutSystems.Internal;
var ColumnBreakRecordList = (function (_super) {
__extends(ColumnBreakRecordList, _super);
function ColumnBreakRecordList(defaults) {
_super.apply(this, arguments);
}
ColumnBreakRecordList.itemType = OutSystemsUIModel.ColumnBreakRecord;
return ColumnBreakRecordList;
})(OS.DataTypes.GenericRecordList);
OutSystemsUIModel.ColumnBreakRecordList = ColumnBreakRecordList;

});
define("OutSystemsUI.model$DropdownItemList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.model$DropdownItemRec"], function (exports, OutSystems, OutSystemsUIModel) {
var OS = OutSystems.Internal;
var DropdownItemList = (function (_super) {
__extends(DropdownItemList, _super);
function DropdownItemList(defaults) {
_super.apply(this, arguments);
}
DropdownItemList.itemType = OutSystemsUIModel.DropdownItemRec;
return DropdownItemList;
})(OS.DataTypes.GenericRecordList);
OutSystemsUIModel.DropdownItemList = DropdownItemList;

});
define("OutSystemsUI.model$SideMenuBehaviorRec", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model"], function (exports, OutSystems, OutSystemsUIModel) {
var OS = OutSystems.Internal;
var SideMenuBehaviorRec = (function (_super) {
__extends(SideMenuBehaviorRec, _super);
function SideMenuBehaviorRec(defaults) {
_super.apply(this, arguments);
}
SideMenuBehaviorRec.attributesToDeclare = function () {
return [
this.attr("SideMenuBehavior", "sideMenuBehaviorAttr", "SideMenuBehavior", true, false, OS.Types.Text, function () {
return "";
}, true)
].concat(_super.attributesToDeclare.call(this));
};
SideMenuBehaviorRec.fromStructure = function (str) {
return new SideMenuBehaviorRec(new SideMenuBehaviorRec.RecordClass({
sideMenuBehaviorAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
SideMenuBehaviorRec.init();
return SideMenuBehaviorRec;
})(OS.DataTypes.GenericRecord);
OutSystemsUIModel.SideMenuBehaviorRec = SideMenuBehaviorRec;

});
define("OutSystemsUI.model$StepsList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.model$StepsRec"], function (exports, OutSystems, OutSystemsUIModel) {
var OS = OutSystems.Internal;
var StepsList = (function (_super) {
__extends(StepsList, _super);
function StepsList(defaults) {
_super.apply(this, arguments);
}
StepsList.itemType = OutSystemsUIModel.StepsRec;
return StepsList;
})(OS.DataTypes.GenericRecordList);
OutSystemsUIModel.StepsList = StepsList;

});
define("OutSystemsUI.model$SpeedRecord", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.model$SpeedRec"], function (exports, OutSystems, OutSystemsUIModel) {
var OS = OutSystems.Internal;
var SpeedRecord = (function (_super) {
__extends(SpeedRecord, _super);
function SpeedRecord(defaults) {
_super.apply(this, arguments);
}
SpeedRecord.attributesToDeclare = function () {
return [
this.attr("Speed", "speedAttr", "Speed", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsUIModel.SpeedRec());
}, true, OutSystemsUIModel.SpeedRec)
].concat(_super.attributesToDeclare.call(this));
};
SpeedRecord.fromStructure = function (str) {
return new SpeedRecord(new SpeedRecord.RecordClass({
speedAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
SpeedRecord._isAnonymousRecord = true;
SpeedRecord.UniqueId = "d15ba8cc-56cc-5ee5-8bd8-acaffd974239";
SpeedRecord.init();
return SpeedRecord;
})(OS.DataTypes.GenericRecord);
OutSystemsUIModel.SpeedRecord = SpeedRecord;

});
define("OutSystemsUI.model$DeviceResponsiveList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.model$DeviceResponsiveRec"], function (exports, OutSystems, OutSystemsUIModel) {
var OS = OutSystems.Internal;
var DeviceResponsiveList = (function (_super) {
__extends(DeviceResponsiveList, _super);
function DeviceResponsiveList(defaults) {
_super.apply(this, arguments);
}
DeviceResponsiveList.itemType = OutSystemsUIModel.DeviceResponsiveRec;
return DeviceResponsiveList;
})(OS.DataTypes.GenericRecordList);
OutSystemsUIModel.DeviceResponsiveList = DeviceResponsiveList;

});
define("OutSystemsUI.model$SideMenuBehaviorList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.model$SideMenuBehaviorRec"], function (exports, OutSystems, OutSystemsUIModel) {
var OS = OutSystems.Internal;
var SideMenuBehaviorList = (function (_super) {
__extends(SideMenuBehaviorList, _super);
function SideMenuBehaviorList(defaults) {
_super.apply(this, arguments);
}
SideMenuBehaviorList.itemType = OutSystemsUIModel.SideMenuBehaviorRec;
return SideMenuBehaviorList;
})(OS.DataTypes.GenericRecordList);
OutSystemsUIModel.SideMenuBehaviorList = SideMenuBehaviorList;

});
define("OutSystemsUI.model$ColorList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.model$ColorRec"], function (exports, OutSystems, OutSystemsUIModel) {
var OS = OutSystems.Internal;
var ColorList = (function (_super) {
__extends(ColorList, _super);
function ColorList(defaults) {
_super.apply(this, arguments);
}
ColorList.itemType = OutSystemsUIModel.ColorRec;
return ColorList;
})(OS.DataTypes.GenericRecordList);
OutSystemsUIModel.ColorList = ColorList;

});
define("OutSystemsUI.model$GutterSizeList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.model$GutterSizeRec"], function (exports, OutSystems, OutSystemsUIModel) {
var OS = OutSystems.Internal;
var GutterSizeList = (function (_super) {
__extends(GutterSizeList, _super);
function GutterSizeList(defaults) {
_super.apply(this, arguments);
}
GutterSizeList.itemType = OutSystemsUIModel.GutterSizeRec;
return GutterSizeList;
})(OS.DataTypes.GenericRecordList);
OutSystemsUIModel.GutterSizeList = GutterSizeList;

});
define("OutSystemsUI.model$PositionList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.model$PositionRec"], function (exports, OutSystems, OutSystemsUIModel) {
var OS = OutSystems.Internal;
var PositionList = (function (_super) {
__extends(PositionList, _super);
function PositionList(defaults) {
_super.apply(this, arguments);
}
PositionList.itemType = OutSystemsUIModel.PositionRec;
return PositionList;
})(OS.DataTypes.GenericRecordList);
OutSystemsUIModel.PositionList = PositionList;

});
define("OutSystemsUI.model$DropdownItemRecordList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.model$DropdownItemRecord"], function (exports, OutSystems, OutSystemsUIModel) {
var OS = OutSystems.Internal;
var DropdownItemRecordList = (function (_super) {
__extends(DropdownItemRecordList, _super);
function DropdownItemRecordList(defaults) {
_super.apply(this, arguments);
}
DropdownItemRecordList.itemType = OutSystemsUIModel.DropdownItemRecord;
return DropdownItemRecordList;
})(OS.DataTypes.GenericRecordList);
OutSystemsUIModel.DropdownItemRecordList = DropdownItemRecordList;

});
define("OutSystemsUI.model$AutoplayList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.model$AutoplayRec"], function (exports, OutSystems, OutSystemsUIModel) {
var OS = OutSystems.Internal;
var AutoplayList = (function (_super) {
__extends(AutoplayList, _super);
function AutoplayList(defaults) {
_super.apply(this, arguments);
}
AutoplayList.itemType = OutSystemsUIModel.AutoplayRec;
return AutoplayList;
})(OS.DataTypes.GenericRecordList);
OutSystemsUIModel.AutoplayList = AutoplayList;

});
define("OutSystemsUI.model$DEPRECATED_MasterDetailItemList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.model$DEPRECATED_MasterDetailItemRec"], function (exports, OutSystems, OutSystemsUIModel) {
var OS = OutSystems.Internal;
var DEPRECATED_MasterDetailItemList = (function (_super) {
__extends(DEPRECATED_MasterDetailItemList, _super);
function DEPRECATED_MasterDetailItemList(defaults) {
_super.apply(this, arguments);
}
DEPRECATED_MasterDetailItemList.itemType = OutSystemsUIModel.DEPRECATED_MasterDetailItemRec;
return DEPRECATED_MasterDetailItemList;
})(OS.DataTypes.GenericRecordList);
OutSystemsUIModel.DEPRECATED_MasterDetailItemList = DEPRECATED_MasterDetailItemList;

});
define("OutSystemsUI.model$SideMenuBehaviorRecord", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.model$SideMenuBehaviorRec"], function (exports, OutSystems, OutSystemsUIModel) {
var OS = OutSystems.Internal;
var SideMenuBehaviorRecord = (function (_super) {
__extends(SideMenuBehaviorRecord, _super);
function SideMenuBehaviorRecord(defaults) {
_super.apply(this, arguments);
}
SideMenuBehaviorRecord.attributesToDeclare = function () {
return [
this.attr("SideMenuBehavior", "sideMenuBehaviorAttr", "SideMenuBehavior", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsUIModel.SideMenuBehaviorRec());
}, true, OutSystemsUIModel.SideMenuBehaviorRec)
].concat(_super.attributesToDeclare.call(this));
};
SideMenuBehaviorRecord.fromStructure = function (str) {
return new SideMenuBehaviorRecord(new SideMenuBehaviorRecord.RecordClass({
sideMenuBehaviorAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
SideMenuBehaviorRecord._isAnonymousRecord = true;
SideMenuBehaviorRecord.UniqueId = "e3607d6b-9254-5e57-93fb-eb99fc16b7e7";
SideMenuBehaviorRecord.init();
return SideMenuBehaviorRecord;
})(OS.DataTypes.GenericRecord);
OutSystemsUIModel.SideMenuBehaviorRecord = SideMenuBehaviorRecord;

});
define("OutSystemsUI.model$BooleanBooleanIntegerIntegerIntegerIntegerIntegerRecord", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model"], function (exports, OutSystems, OutSystemsUIModel) {
var OS = OutSystems.Internal;
var BooleanBooleanIntegerIntegerIntegerIntegerIntegerRecord = (function (_super) {
__extends(BooleanBooleanIntegerIntegerIntegerIntegerIntegerRecord, _super);
function BooleanBooleanIntegerIntegerIntegerIntegerIntegerRecord(defaults) {
_super.apply(this, arguments);
}
BooleanBooleanIntegerIntegerIntegerIntegerIntegerRecord.attributesToDeclare = function () {
return [
this.attr("ChangeEventDuringSlide", "changeEventDuringSlideAttr", "ChangeEventDuringSlide", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("ShowPips", "showPipsAttr", "ShowPips", false, false, OS.Types.Boolean, function () {
return false;
}, true), 
this.attr("InitialValue", "initialValueAttr", "InitialValue", false, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("MaxValue", "maxValueAttr", "MaxValue", false, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("MinValue", "minValueAttr", "MinValue", false, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("PipsStep", "pipsStepAttr", "PipsStep", false, false, OS.Types.Integer, function () {
return 0;
}, true), 
this.attr("Step", "stepAttr", "Step", false, false, OS.Types.Integer, function () {
return 0;
}, true)
].concat(_super.attributesToDeclare.call(this));
};
BooleanBooleanIntegerIntegerIntegerIntegerIntegerRecord._isAnonymousRecord = true;
BooleanBooleanIntegerIntegerIntegerIntegerIntegerRecord.UniqueId = "e57d7c30-9592-d9b0-9e76-04ad507fe534";
BooleanBooleanIntegerIntegerIntegerIntegerIntegerRecord.init();
return BooleanBooleanIntegerIntegerIntegerIntegerIntegerRecord;
})(OS.DataTypes.GenericRecord);
OutSystemsUIModel.BooleanBooleanIntegerIntegerIntegerIntegerIntegerRecord = BooleanBooleanIntegerIntegerIntegerIntegerIntegerRecord;

});
define("OutSystemsUI.model$SpeedList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.model$SpeedRec"], function (exports, OutSystems, OutSystemsUIModel) {
var OS = OutSystems.Internal;
var SpeedList = (function (_super) {
__extends(SpeedList, _super);
function SpeedList(defaults) {
_super.apply(this, arguments);
}
SpeedList.itemType = OutSystemsUIModel.SpeedRec;
return SpeedList;
})(OS.DataTypes.GenericRecordList);
OutSystemsUIModel.SpeedList = SpeedList;

});
define("OutSystemsUI.model$StepsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.model$StepsRecord"], function (exports, OutSystems, OutSystemsUIModel) {
var OS = OutSystems.Internal;
var StepsRecordList = (function (_super) {
__extends(StepsRecordList, _super);
function StepsRecordList(defaults) {
_super.apply(this, arguments);
}
StepsRecordList.itemType = OutSystemsUIModel.StepsRecord;
return StepsRecordList;
})(OS.DataTypes.GenericRecordList);
OutSystemsUIModel.StepsRecordList = StepsRecordList;

});
define("OutSystemsUI.model$BooleanBooleanIntegerIntegerIntegerIntegerIntegerRecordList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.model$BooleanBooleanIntegerIntegerIntegerIntegerIntegerRecord"], function (exports, OutSystems, OutSystemsUIModel) {
var OS = OutSystems.Internal;
var BooleanBooleanIntegerIntegerIntegerIntegerIntegerRecordList = (function (_super) {
__extends(BooleanBooleanIntegerIntegerIntegerIntegerIntegerRecordList, _super);
function BooleanBooleanIntegerIntegerIntegerIntegerIntegerRecordList(defaults) {
_super.apply(this, arguments);
}
BooleanBooleanIntegerIntegerIntegerIntegerIntegerRecordList.itemType = OutSystemsUIModel.BooleanBooleanIntegerIntegerIntegerIntegerIntegerRecord;
return BooleanBooleanIntegerIntegerIntegerIntegerIntegerRecordList;
})(OS.DataTypes.GenericRecordList);
OutSystemsUIModel.BooleanBooleanIntegerIntegerIntegerIntegerIntegerRecordList = BooleanBooleanIntegerIntegerIntegerIntegerIntegerRecordList;

});
define("OutSystemsUI.model$GutterSizeRecordList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.model$GutterSizeRecord"], function (exports, OutSystems, OutSystemsUIModel) {
var OS = OutSystems.Internal;
var GutterSizeRecordList = (function (_super) {
__extends(GutterSizeRecordList, _super);
function GutterSizeRecordList(defaults) {
_super.apply(this, arguments);
}
GutterSizeRecordList.itemType = OutSystemsUIModel.GutterSizeRecord;
return GutterSizeRecordList;
})(OS.DataTypes.GenericRecordList);
OutSystemsUIModel.GutterSizeRecordList = GutterSizeRecordList;

});
define("OutSystemsUI.model$SideMenuBehaviorRecordList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.model$SideMenuBehaviorRecord"], function (exports, OutSystems, OutSystemsUIModel) {
var OS = OutSystems.Internal;
var SideMenuBehaviorRecordList = (function (_super) {
__extends(SideMenuBehaviorRecordList, _super);
function SideMenuBehaviorRecordList(defaults) {
_super.apply(this, arguments);
}
SideMenuBehaviorRecordList.itemType = OutSystemsUIModel.SideMenuBehaviorRecord;
return SideMenuBehaviorRecordList;
})(OS.DataTypes.GenericRecordList);
OutSystemsUIModel.SideMenuBehaviorRecordList = SideMenuBehaviorRecordList;

});
define("OutSystemsUI.model$AlertRecordList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.model$AlertRecord"], function (exports, OutSystems, OutSystemsUIModel) {
var OS = OutSystems.Internal;
var AlertRecordList = (function (_super) {
__extends(AlertRecordList, _super);
function AlertRecordList(defaults) {
_super.apply(this, arguments);
}
AlertRecordList.itemType = OutSystemsUIModel.AlertRecord;
return AlertRecordList;
})(OS.DataTypes.GenericRecordList);
OutSystemsUIModel.AlertRecordList = AlertRecordList;

});
define("OutSystemsUI.model$SpeedRecordList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.model$SpeedRecord"], function (exports, OutSystems, OutSystemsUIModel) {
var OS = OutSystems.Internal;
var SpeedRecordList = (function (_super) {
__extends(SpeedRecordList, _super);
function SpeedRecordList(defaults) {
_super.apply(this, arguments);
}
SpeedRecordList.itemType = OutSystemsUIModel.SpeedRecord;
return SpeedRecordList;
})(OS.DataTypes.GenericRecordList);
OutSystemsUIModel.SpeedRecordList = SpeedRecordList;

});
define("OutSystemsUI.model", ["exports", "OutSystems/ClientRuntime/Main"], function (exports, OutSystems) {
var OS = OutSystems.Internal;
var OutSystemsUIModel = exports;
Object.defineProperty(OutSystemsUIModel, "module", {
get: function () {
return OS.ApplicationInfo.getModules()["8be17f2a-431c-4958-b894-c77b988a7271"];
}
});

OutSystemsUIModel.staticEntities = {};
OutSystemsUIModel.staticEntities.animationType = {};
var getAnimationTypeRecord = function (record) {
return OutSystemsUIModel.module.staticEntities["0463d449-6834-40d5-817b-3d74d1a71bb2"][record];
};
Object.defineProperty(OutSystemsUIModel.staticEntities.animationType, "topToBottom", {
get: function () {
return getAnimationTypeRecord("2d5a98f9-381b-4ff8-9219-085bc35dfc44");
}
});

Object.defineProperty(OutSystemsUIModel.staticEntities.animationType, "bounce", {
get: function () {
return getAnimationTypeRecord("3c3ad352-52fc-43c5-ae3a-f8d651bfa094");
}
});

Object.defineProperty(OutSystemsUIModel.staticEntities.animationType, "fadeIn", {
get: function () {
return getAnimationTypeRecord("69814f09-c20b-4d55-b06a-7231a5515d2c");
}
});

Object.defineProperty(OutSystemsUIModel.staticEntities.animationType, "scaleDown", {
get: function () {
return getAnimationTypeRecord("7d8fd3a6-eac4-4ae8-b865-18f5711814cb");
}
});

Object.defineProperty(OutSystemsUIModel.staticEntities.animationType, "scale", {
get: function () {
return getAnimationTypeRecord("8a8e0e8b-0e5a-407c-9739-4942e1c708e8");
}
});

Object.defineProperty(OutSystemsUIModel.staticEntities.animationType, "spinner", {
get: function () {
return getAnimationTypeRecord("b1e2a22f-cd5a-49a8-83e2-a82471745aea");
}
});

Object.defineProperty(OutSystemsUIModel.staticEntities.animationType, "bottomToTop", {
get: function () {
return getAnimationTypeRecord("b71cef18-b0ee-4e9b-8b98-5700b6c6b9e4");
}
});

Object.defineProperty(OutSystemsUIModel.staticEntities.animationType, "rightToLeft", {
get: function () {
return getAnimationTypeRecord("b7a58aaa-e1f6-4bbb-9557-5fb4742ef542");
}
});

Object.defineProperty(OutSystemsUIModel.staticEntities.animationType, "leftToRight", {
get: function () {
return getAnimationTypeRecord("f4c21a73-5f0c-4d9e-a9e6-7053b68c2cea");
}
});

OutSystemsUIModel.staticEntities.speed = {};
var getSpeedRecord = function (record) {
return OutSystemsUIModel.module.staticEntities["0a5cc4ae-b54f-4ea3-9ace-9f49c7724606"][record];
};
Object.defineProperty(OutSystemsUIModel.staticEntities.speed, "fast", {
get: function () {
return getSpeedRecord("4fb2b6d9-70ff-415d-a09d-4ee05adda5c4");
}
});

Object.defineProperty(OutSystemsUIModel.staticEntities.speed, "normal", {
get: function () {
return getSpeedRecord("93b9215f-8fb1-4f08-8555-9b0125b18f51");
}
});

Object.defineProperty(OutSystemsUIModel.staticEntities.speed, "slow", {
get: function () {
return getSpeedRecord("b2c67d31-506d-42e7-890e-0e4f29234ae6");
}
});

OutSystemsUIModel.staticEntities.sideMenuBehavior = {};
var getSideMenuBehaviorRecord = function (record) {
return OutSystemsUIModel.module.staticEntities["11a5937b-e94d-4250-99a8-9c8358d3d965"][record];
};
Object.defineProperty(OutSystemsUIModel.staticEntities.sideMenuBehavior, "visible", {
get: function () {
return getSideMenuBehaviorRecord("25b95337-61e5-4cc7-95a0-fb2bee22c75f");
}
});

Object.defineProperty(OutSystemsUIModel.staticEntities.sideMenuBehavior, "expandable", {
get: function () {
return getSideMenuBehaviorRecord("db935269-7a37-40aa-898b-e17e546a932a");
}
});

Object.defineProperty(OutSystemsUIModel.staticEntities.sideMenuBehavior, "overlay", {
get: function () {
return getSideMenuBehaviorRecord("f194be06-0135-4afc-9be2-3f9a7ecd107c");
}
});

OutSystemsUIModel.staticEntities.size = {};
var getSizeRecord = function (record) {
return OutSystemsUIModel.module.staticEntities["1ac110b4-8964-470b-a6b2-81ae4a6b5bde"][record];
};
Object.defineProperty(OutSystemsUIModel.staticEntities.size, "medium", {
get: function () {
return getSizeRecord("0f4cba2c-32d2-4bef-b0e8-0ecd7eadbffa");
}
});

Object.defineProperty(OutSystemsUIModel.staticEntities.size, "small", {
get: function () {
return getSizeRecord("9133cb8a-ca17-4e39-a9fd-4a07cf123c82");
}
});

OutSystemsUIModel.staticEntities.deviceResponsive = {};
var getDeviceResponsiveRecord = function (record) {
return OutSystemsUIModel.module.staticEntities["29468e1d-a25a-42c3-bf53-b232accc150d"][record];
};
Object.defineProperty(OutSystemsUIModel.staticEntities.deviceResponsive, "desktopAndTablet", {
get: function () {
return getDeviceResponsiveRecord("0a533047-a7d6-4897-bfb2-140047b8fccd");
}
});

Object.defineProperty(OutSystemsUIModel.staticEntities.deviceResponsive, "tabletOnly", {
get: function () {
return getDeviceResponsiveRecord("4164cab0-7b05-43a4-9c78-e81a53431a7d");
}
});

Object.defineProperty(OutSystemsUIModel.staticEntities.deviceResponsive, "allDevices", {
get: function () {
return getDeviceResponsiveRecord("5283ef6e-84da-42b1-b937-5efa0ee1a6b0");
}
});

Object.defineProperty(OutSystemsUIModel.staticEntities.deviceResponsive, "phoneOnly", {
get: function () {
return getDeviceResponsiveRecord("a671987e-7b94-462a-9685-e6bcf890454e");
}
});

Object.defineProperty(OutSystemsUIModel.staticEntities.deviceResponsive, "tabletAndPhone", {
get: function () {
return getDeviceResponsiveRecord("e04f86d2-6c26-47db-9e53-434eb6386498");
}
});

Object.defineProperty(OutSystemsUIModel.staticEntities.deviceResponsive, "desktopOnly", {
get: function () {
return getDeviceResponsiveRecord("ebed41f5-fbac-4f23-9ae0-429c2e439ff2");
}
});

OutSystemsUIModel.staticEntities.gutterSize = {};
var getGutterSizeRecord = function (record) {
return OutSystemsUIModel.module.staticEntities["2e81a1e8-4fa4-4bd0-a945-65352999b0be"][record];
};
Object.defineProperty(OutSystemsUIModel.staticEntities.gutterSize, "xXLarge", {
get: function () {
return getGutterSizeRecord("087ea4c4-96ff-4fc5-87c9-70e35c61fe6e");
}
});

Object.defineProperty(OutSystemsUIModel.staticEntities.gutterSize, "medium", {
get: function () {
return getGutterSizeRecord("12874371-fb77-4707-afda-cdddbba81173");
}
});

Object.defineProperty(OutSystemsUIModel.staticEntities.gutterSize, "none", {
get: function () {
return getGutterSizeRecord("1a6cb2a2-b448-4f08-ba92-5bd24d30a422");
}
});

Object.defineProperty(OutSystemsUIModel.staticEntities.gutterSize, "extraLarge", {
get: function () {
return getGutterSizeRecord("8d669ecd-b220-4b80-b57b-4700987734dd");
}
});

Object.defineProperty(OutSystemsUIModel.staticEntities.gutterSize, "small", {
get: function () {
return getGutterSizeRecord("96f816b9-2511-49f9-8e9c-c6ab4ff8683e");
}
});

Object.defineProperty(OutSystemsUIModel.staticEntities.gutterSize, "large", {
get: function () {
return getGutterSizeRecord("a9dce78b-0487-49ef-b5c0-d3054293816b");
}
});

Object.defineProperty(OutSystemsUIModel.staticEntities.gutterSize, "base", {
get: function () {
return getGutterSizeRecord("b7549354-102c-45e6-8c2e-b171c6f589c5");
}
});

Object.defineProperty(OutSystemsUIModel.staticEntities.gutterSize, "extraSmall", {
get: function () {
return getGutterSizeRecord("b8734df5-7557-4609-a566-cf5c35a6dade");
}
});

OutSystemsUIModel.staticEntities.dEPRECATED_Color = {};
var getDEPRECATED_ColorRecord = function (record) {
return OutSystemsUIModel.module.staticEntities["4a5b3b8d-44e7-4c03-9b89-453fa2feee20"][record];
};
Object.defineProperty(OutSystemsUIModel.staticEntities.dEPRECATED_Color, "white", {
get: function () {
return getDEPRECATED_ColorRecord("05505a13-1fe9-4adf-9845-11368c74e98b");
}
});

Object.defineProperty(OutSystemsUIModel.staticEntities.dEPRECATED_Color, "blue", {
get: function () {
return getDEPRECATED_ColorRecord("0772a1e6-baf6-4f8d-9b63-aef9b16bec31");
}
});

Object.defineProperty(OutSystemsUIModel.staticEntities.dEPRECATED_Color, "black", {
get: function () {
return getDEPRECATED_ColorRecord("26ba2ced-6bce-452f-b33a-7874dc80d8d1");
}
});

Object.defineProperty(OutSystemsUIModel.staticEntities.dEPRECATED_Color, "violet", {
get: function () {
return getDEPRECATED_ColorRecord("3269784e-d6b0-46db-a0b5-5a9a64ee0e41");
}
});

Object.defineProperty(OutSystemsUIModel.staticEntities.dEPRECATED_Color, "none", {
get: function () {
return getDEPRECATED_ColorRecord("342260d0-74a4-44fd-9e9d-f0505a330244");
}
});

Object.defineProperty(OutSystemsUIModel.staticEntities.dEPRECATED_Color, "orange", {
get: function () {
return getDEPRECATED_ColorRecord("833f5f9b-2325-4b92-9285-e14aa1a17c25");
}
});

Object.defineProperty(OutSystemsUIModel.staticEntities.dEPRECATED_Color, "red", {
get: function () {
return getDEPRECATED_ColorRecord("94682198-3a70-458e-9889-3eef131d1b00");
}
});

Object.defineProperty(OutSystemsUIModel.staticEntities.dEPRECATED_Color, "primaryColor", {
get: function () {
return getDEPRECATED_ColorRecord("9bd951e1-c94c-434b-85cb-a4cde3ffe638");
}
});

Object.defineProperty(OutSystemsUIModel.staticEntities.dEPRECATED_Color, "green", {
get: function () {
return getDEPRECATED_ColorRecord("ad00278a-a271-46de-ac30-9f99c87f97a4");
}
});

Object.defineProperty(OutSystemsUIModel.staticEntities.dEPRECATED_Color, "grey", {
get: function () {
return getDEPRECATED_ColorRecord("f986e894-0745-46fd-aa63-7680b5fd9234");
}
});

OutSystemsUIModel.staticEntities.breakColumns = {};
var getBreakColumnsRecord = function (record) {
return OutSystemsUIModel.module.staticEntities["68f74593-a5c4-4e65-858b-f44211eaf122"][record];
};
Object.defineProperty(OutSystemsUIModel.staticEntities.breakColumns, "none", {
get: function () {
return getBreakColumnsRecord("0712904e-03be-4b5f-9b9e-ecc640f84913");
}
});

Object.defineProperty(OutSystemsUIModel.staticEntities.breakColumns, "first", {
get: function () {
return getBreakColumnsRecord("3d55ca44-9c70-4bd4-bf96-7d0a7ec1c3b6");
}
});

Object.defineProperty(OutSystemsUIModel.staticEntities.breakColumns, "all", {
get: function () {
return getBreakColumnsRecord("63e0af38-8b6c-4970-b96a-acd8c6d863e4");
}
});

Object.defineProperty(OutSystemsUIModel.staticEntities.breakColumns, "middle", {
get: function () {
return getBreakColumnsRecord("694d423c-ce17-45a1-9993-cb57c30ec674");
}
});

Object.defineProperty(OutSystemsUIModel.staticEntities.breakColumns, "last", {
get: function () {
return getBreakColumnsRecord("6c98320a-c178-4925-b42b-7165ed805ea0");
}
});

OutSystemsUIModel.staticEntities.shape = {};
var getShapeRecord = function (record) {
return OutSystemsUIModel.module.staticEntities["6fe168a9-c16d-4cdb-9b6f-a9e6c6b79326"][record];
};
Object.defineProperty(OutSystemsUIModel.staticEntities.shape, "sharp", {
get: function () {
return getShapeRecord("94deb1f5-6153-4438-92ad-cedea3c1f6f0");
}
});

Object.defineProperty(OutSystemsUIModel.staticEntities.shape, "softRounded", {
get: function () {
return getShapeRecord("d1093539-d77d-439d-8d53-03d2e0053a52");
}
});

Object.defineProperty(OutSystemsUIModel.staticEntities.shape, "rounded", {
get: function () {
return getShapeRecord("f20c2269-270a-43b2-ba29-bd8fbff2519f");
}
});

OutSystemsUIModel.staticEntities.stackedCardsPosition = {};
var getStackedCardsPositionRecord = function (record) {
return OutSystemsUIModel.module.staticEntities["71865eb4-55fe-40a5-bc7f-45b005a3a0b5"][record];
};
Object.defineProperty(OutSystemsUIModel.staticEntities.stackedCardsPosition, "bottom", {
get: function () {
return getStackedCardsPositionRecord("2e9dd7c6-b9a7-404f-b207-9a3da7fb05ed");
}
});

Object.defineProperty(OutSystemsUIModel.staticEntities.stackedCardsPosition, "top", {
get: function () {
return getStackedCardsPositionRecord("5766b18f-82ef-49f1-9476-cf8f49249f25");
}
});

Object.defineProperty(OutSystemsUIModel.staticEntities.stackedCardsPosition, "none", {
get: function () {
return getStackedCardsPositionRecord("89cf1ed9-b6fd-4e0a-af41-cfd79db935d7");
}
});

OutSystemsUIModel.staticEntities.autoplay = {};
var getAutoplayRecord = function (record) {
return OutSystemsUIModel.module.staticEntities["82aa58b4-8bbb-4d19-92b6-2944affad02c"][record];
};
Object.defineProperty(OutSystemsUIModel.staticEntities.autoplay, "disabled", {
get: function () {
return getAutoplayRecord("1ffcca5d-17d0-492e-9e9e-b8addde7fd80");
}
});

Object.defineProperty(OutSystemsUIModel.staticEntities.autoplay, "slow", {
get: function () {
return getAutoplayRecord("4167f601-5731-452d-9653-1be7f25199f1");
}
});

Object.defineProperty(OutSystemsUIModel.staticEntities.autoplay, "fast", {
get: function () {
return getAutoplayRecord("41b9ec04-2023-4f87-b953-0c01713d1992");
}
});

Object.defineProperty(OutSystemsUIModel.staticEntities.autoplay, "normal", {
get: function () {
return getAutoplayRecord("e3033046-77ba-49cd-928a-5d831105f349");
}
});

OutSystemsUIModel.staticEntities.position = {};
var getPositionRecord = function (record) {
return OutSystemsUIModel.module.staticEntities["83c073e8-bac2-4122-9772-aa6e122a5d36"][record];
};
Object.defineProperty(OutSystemsUIModel.staticEntities.position, "top", {
get: function () {
return getPositionRecord("3bbcac35-309e-49a8-bf1b-a3c66e1ef3cd");
}
});

Object.defineProperty(OutSystemsUIModel.staticEntities.position, "left", {
get: function () {
return getPositionRecord("4d70c81a-67bd-4a1f-a21a-c6aa13d0f364");
}
});

Object.defineProperty(OutSystemsUIModel.staticEntities.position, "bottomRight", {
get: function () {
return getPositionRecord("73459c44-0160-4454-8ad0-c9bd44778a61");
}
});

Object.defineProperty(OutSystemsUIModel.staticEntities.position, "bottomLeft", {
get: function () {
return getPositionRecord("7352570c-243a-4f05-b6d1-608495931118");
}
});

Object.defineProperty(OutSystemsUIModel.staticEntities.position, "right", {
get: function () {
return getPositionRecord("bf43697b-2483-4855-a6c2-0a786bab472f");
}
});

Object.defineProperty(OutSystemsUIModel.staticEntities.position, "topLeft", {
get: function () {
return getPositionRecord("c1d22c62-5a36-4d69-b188-02d62b8fe7c4");
}
});

Object.defineProperty(OutSystemsUIModel.staticEntities.position, "topRight", {
get: function () {
return getPositionRecord("d14d8aae-f1c9-4538-a4a9-91a2690e6d92");
}
});

Object.defineProperty(OutSystemsUIModel.staticEntities.position, "center", {
get: function () {
return getPositionRecord("dcc9ffa2-34a7-4097-86d0-dde224907425");
}
});

Object.defineProperty(OutSystemsUIModel.staticEntities.position, "bottom", {
get: function () {
return getPositionRecord("fb8d90f9-5432-4678-932b-f468c00d3361");
}
});

OutSystemsUIModel.staticEntities.space = {};
var getSpaceRecord = function (record) {
return OutSystemsUIModel.module.staticEntities["8fb3d471-82a4-439c-9cc1-0555dfa91451"][record];
};
Object.defineProperty(OutSystemsUIModel.staticEntities.space, "large", {
get: function () {
return getSpaceRecord("51b55067-e608-49ed-9f00-1faf9e4a694a");
}
});

Object.defineProperty(OutSystemsUIModel.staticEntities.space, "medium", {
get: function () {
return getSpaceRecord("7340e97f-de64-4337-ad0d-1defcab8adb2");
}
});

Object.defineProperty(OutSystemsUIModel.staticEntities.space, "xXLarge", {
get: function () {
return getSpaceRecord("823213f8-9df9-4de0-8aba-2b5566e6f87d");
}
});

Object.defineProperty(OutSystemsUIModel.staticEntities.space, "extraSmall", {
get: function () {
return getSpaceRecord("83adf9ba-fbcf-4ce0-b4a4-bc6330956b89");
}
});

Object.defineProperty(OutSystemsUIModel.staticEntities.space, "small", {
get: function () {
return getSpaceRecord("919210a5-6b3b-40c9-9a28-b4e2c28a46f8");
}
});

Object.defineProperty(OutSystemsUIModel.staticEntities.space, "base", {
get: function () {
return getSpaceRecord("f0572ad3-54ac-4755-8c8e-a9004171fcb1");
}
});

Object.defineProperty(OutSystemsUIModel.staticEntities.space, "extraLarge", {
get: function () {
return getSpaceRecord("f8dafab9-63b9-40b2-9755-f2f8fa3d6e84");
}
});

Object.defineProperty(OutSystemsUIModel.staticEntities.space, "none", {
get: function () {
return getSpaceRecord("fb937b97-bd94-4ba4-80ff-446cb3bdf6ae");
}
});

OutSystemsUIModel.staticEntities.alert = {};
var getAlertRecord = function (record) {
return OutSystemsUIModel.module.staticEntities["924486c0-dd9a-46ea-ad74-2cf9ac0c84d9"][record];
};
Object.defineProperty(OutSystemsUIModel.staticEntities.alert, "success", {
get: function () {
return getAlertRecord("4aac6381-179c-477f-a0d2-8aa7c0e2ece5");
}
});

Object.defineProperty(OutSystemsUIModel.staticEntities.alert, "error", {
get: function () {
return getAlertRecord("85c06001-4d3a-4a08-b18f-4f9ebdc60d33");
}
});

Object.defineProperty(OutSystemsUIModel.staticEntities.alert, "info", {
get: function () {
return getAlertRecord("e7c6b907-0f56-481e-b267-eb69bd92ed26");
}
});

Object.defineProperty(OutSystemsUIModel.staticEntities.alert, "warning", {
get: function () {
return getAlertRecord("ed710523-9de5-47b6-b3ac-736fb4848c04");
}
});

OutSystemsUIModel.staticEntities.menuAction = {};
var getMenuActionRecord = function (record) {
return OutSystemsUIModel.module.staticEntities["9cc12883-06ab-4cf0-9997-ede7c6c02d67"][record];
};
Object.defineProperty(OutSystemsUIModel.staticEntities.menuAction, "menu", {
get: function () {
return getMenuActionRecord("55ba18a9-cd6b-45dd-99ce-9081ee1387ea");
}
});

Object.defineProperty(OutSystemsUIModel.staticEntities.menuAction, "auto", {
get: function () {
return getMenuActionRecord("6c0c753a-86f4-4e76-9781-6e821c850c72");
}
});

Object.defineProperty(OutSystemsUIModel.staticEntities.menuAction, "hidden", {
get: function () {
return getMenuActionRecord("86c9d356-be64-46a1-b027-843ab93b4aea");
}
});

Object.defineProperty(OutSystemsUIModel.staticEntities.menuAction, "back", {
get: function () {
return getMenuActionRecord("f2db3c50-4c38-4ee7-a770-aa9476cb0d68");
}
});

OutSystemsUIModel.staticEntities.messageStatus = {};
var getMessageStatusRecord = function (record) {
return OutSystemsUIModel.module.staticEntities["c1015fc0-c81c-40cc-a046-bf99cf21a280"][record];
};
Object.defineProperty(OutSystemsUIModel.staticEntities.messageStatus, "hidden", {
get: function () {
return getMessageStatusRecord("2f2266ed-167a-45db-ac12-ca1e3cfa0fd2");
}
});

Object.defineProperty(OutSystemsUIModel.staticEntities.messageStatus, "read", {
get: function () {
return getMessageStatusRecord("34f4ff93-8e4e-4933-baae-8b9f122eb3cc");
}
});

Object.defineProperty(OutSystemsUIModel.staticEntities.messageStatus, "sent", {
get: function () {
return getMessageStatusRecord("a1f1ba89-bd84-4943-a94c-a84ea4a142bf");
}
});

Object.defineProperty(OutSystemsUIModel.staticEntities.messageStatus, "received", {
get: function () {
return getMessageStatusRecord("c90b88d0-8f7d-484a-8d17-b0d1b9795a94");
}
});

OutSystemsUIModel.staticEntities.color = {};
var getColorRecord = function (record) {
return OutSystemsUIModel.module.staticEntities["cb6d1da7-26d4-45d9-bc22-9a4c482e6ce2"][record];
};
Object.defineProperty(OutSystemsUIModel.staticEntities.color, "neutral9", {
get: function () {
return getColorRecord("04a6c700-0ae5-44d5-81ce-34ec81d72c1c");
}
});

Object.defineProperty(OutSystemsUIModel.staticEntities.color, "grape", {
get: function () {
return getColorRecord("0d81324f-81ae-44eb-b81e-cd27ebce7460");
}
});

Object.defineProperty(OutSystemsUIModel.staticEntities.color, "neutral7", {
get: function () {
return getColorRecord("1434454b-4d44-4ec7-a9ee-8353529b1621");
}
});

Object.defineProperty(OutSystemsUIModel.staticEntities.color, "neutral10", {
get: function () {
return getColorRecord("1566893e-a30d-405f-878b-e64efdab7f7b");
}
});

Object.defineProperty(OutSystemsUIModel.staticEntities.color, "teal", {
get: function () {
return getColorRecord("19254415-08b2-4887-a6cf-36433bb1ade0");
}
});

Object.defineProperty(OutSystemsUIModel.staticEntities.color, "primary", {
get: function () {
return getColorRecord("1df261bf-454e-49a0-951e-87f6077cbbc1");
}
});

Object.defineProperty(OutSystemsUIModel.staticEntities.color, "neutral4", {
get: function () {
return getColorRecord("20d4e7d1-c296-4853-b584-d2b004ddf9f5");
}
});

Object.defineProperty(OutSystemsUIModel.staticEntities.color, "neutral8", {
get: function () {
return getColorRecord("31cd8495-438d-4825-8a93-c083bf6f016a");
}
});

Object.defineProperty(OutSystemsUIModel.staticEntities.color, "indigo", {
get: function () {
return getColorRecord("47b9565a-4f82-4a9d-a543-4aaa707853ac");
}
});

Object.defineProperty(OutSystemsUIModel.staticEntities.color, "orange", {
get: function () {
return getColorRecord("4d20d5b8-5570-4e18-9345-55772434a9ad");
}
});

Object.defineProperty(OutSystemsUIModel.staticEntities.color, "lime", {
get: function () {
return getColorRecord("50b20d51-09a6-43df-aa5d-6ae3c99f31e8");
}
});

Object.defineProperty(OutSystemsUIModel.staticEntities.color, "cyan", {
get: function () {
return getColorRecord("59edafdd-089e-409e-a2d2-78298e55e0f2");
}
});

Object.defineProperty(OutSystemsUIModel.staticEntities.color, "secondary", {
get: function () {
return getColorRecord("61f545b9-e074-40ee-a884-8102a56d9ee7");
}
});

Object.defineProperty(OutSystemsUIModel.staticEntities.color, "neutral6", {
get: function () {
return getColorRecord("69c65fbc-5ddc-4e41-afcf-03acff40e7a8");
}
});

Object.defineProperty(OutSystemsUIModel.staticEntities.color, "yellow", {
get: function () {
return getColorRecord("80145099-0e84-4301-902b-2bd6a933e319");
}
});

Object.defineProperty(OutSystemsUIModel.staticEntities.color, "neutral2", {
get: function () {
return getColorRecord("8577e423-4296-434f-9ca1-9a18b91e0c29");
}
});

Object.defineProperty(OutSystemsUIModel.staticEntities.color, "neutral1", {
get: function () {
return getColorRecord("9946980c-176a-4345-90ff-312523579ef0");
}
});

Object.defineProperty(OutSystemsUIModel.staticEntities.color, "neutral3", {
get: function () {
return getColorRecord("b7447296-c2b5-4d01-883b-b49d25b1c8a6");
}
});

Object.defineProperty(OutSystemsUIModel.staticEntities.color, "transparent", {
get: function () {
return getColorRecord("b87c59d9-4a95-4567-876d-b978ca413429");
}
});

Object.defineProperty(OutSystemsUIModel.staticEntities.color, "violet", {
get: function () {
return getColorRecord("bb39306e-ce82-47a7-9c0f-a78f92ff53c6");
}
});

Object.defineProperty(OutSystemsUIModel.staticEntities.color, "blue", {
get: function () {
return getColorRecord("c1bb8b1b-2f09-4fe9-bec9-eeb243b903d5");
}
});

Object.defineProperty(OutSystemsUIModel.staticEntities.color, "neutral5", {
get: function () {
return getColorRecord("c1d63249-fde7-4438-b4c9-d445bcfc9257");
}
});

Object.defineProperty(OutSystemsUIModel.staticEntities.color, "red", {
get: function () {
return getColorRecord("d6c564f5-847a-4155-ba84-91b826bd676f");
}
});

Object.defineProperty(OutSystemsUIModel.staticEntities.color, "pink", {
get: function () {
return getColorRecord("e9991560-a98c-431e-a583-b707840dc2f3");
}
});

Object.defineProperty(OutSystemsUIModel.staticEntities.color, "green", {
get: function () {
return getColorRecord("ede4099b-595f-47f0-98ed-583414f4f6bd");
}
});

Object.defineProperty(OutSystemsUIModel.staticEntities.color, "neutral0", {
get: function () {
return getColorRecord("fb934ce5-6b33-4c96-8d40-b06352706a8d");
}
});

OutSystemsUIModel.staticEntities.columnBreak = {};
var getColumnBreakRecord = function (record) {
return OutSystemsUIModel.module.staticEntities["cce6ac21-942a-492f-8b46-64c5e6ea057b"][record];
};
Object.defineProperty(OutSystemsUIModel.staticEntities.columnBreak, "breakMiddle", {
get: function () {
return getColumnBreakRecord("3b01fc99-ef23-4043-8771-f88660720e01");
}
});

Object.defineProperty(OutSystemsUIModel.staticEntities.columnBreak, "breakAll", {
get: function () {
return getColumnBreakRecord("43788f73-6893-4396-b67a-04a6ff690e74");
}
});

Object.defineProperty(OutSystemsUIModel.staticEntities.columnBreak, "breakNone", {
get: function () {
return getColumnBreakRecord("69e6c609-9e8a-45a7-b006-45b92275ec49");
}
});

Object.defineProperty(OutSystemsUIModel.staticEntities.columnBreak, "breakLast", {
get: function () {
return getColumnBreakRecord("6b3725c8-8951-48ed-a977-cbfaf003c896");
}
});

Object.defineProperty(OutSystemsUIModel.staticEntities.columnBreak, "breakFirst", {
get: function () {
return getColumnBreakRecord("8c8b45b6-c1af-4b11-907e-3c8a5ce161e2");
}
});

OutSystemsUIModel.staticEntities.steps = {};
var getStepsRecord = function (record) {
return OutSystemsUIModel.module.staticEntities["e4dd8e9f-a620-4df5-b619-9b8a771be5a3"][record];
};
Object.defineProperty(OutSystemsUIModel.staticEntities.steps, "next", {
get: function () {
return getStepsRecord("03e9ec31-9b26-4304-b532-29aa077d99ea");
}
});

Object.defineProperty(OutSystemsUIModel.staticEntities.steps, "past", {
get: function () {
return getStepsRecord("5452e8a1-02ca-4ff2-8d74-bff1512fc4a3");
}
});

Object.defineProperty(OutSystemsUIModel.staticEntities.steps, "active", {
get: function () {
return getStepsRecord("dbde9903-8367-49e7-8302-f6758c190844");
}
});

});
