﻿define("InAppBrowserSampleApp.controller", ["exports", "OutSystems/ClientRuntime/Main", "InAppBrowserSampleApp.model"], function (exports, OutSystems, InAppBrowserSampleAppModel) {
var OS = OutSystems.Internal;
var InAppBrowserSampleAppController = exports;
var Controller = (function (_super) {
__extends(Controller, _super);
function Controller() {
_super.apply(this, arguments);
}
Controller.prototype.clientActionProxies = {};
Controller.prototype.roles = {};
Controller.prototype.defaultTimeout = 10;
Controller.prototype.getDefaultTimeout = function () {
return InAppBrowserSampleAppController.default.defaultTimeout;
};
return Controller;
})(OS.Controller.BaseModuleController);
InAppBrowserSampleAppController.default = new Controller();
});
