﻿define("InAppBrowserPlugin.referencesHealth$CommonPlugin", [], function () {
// Reference to producer 'CommonPlugin' is OK.
});
define("InAppBrowserPlugin.referencesHealth$ServiceCenter", [], function () {
// Reference to producer 'ServiceCenter' is OK.
});
define("InAppBrowserPlugin.referencesHealth", [], function () {
});
