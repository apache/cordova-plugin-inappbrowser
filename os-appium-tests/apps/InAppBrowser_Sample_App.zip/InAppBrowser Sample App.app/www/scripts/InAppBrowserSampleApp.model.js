﻿define("InAppBrowserSampleApp.model$IOSOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "InAppBrowserPlugin.model", "InAppBrowserSampleApp.model", "InAppBrowserPlugin.model$IOSOptionsRec", "InAppBrowserSampleApp.referencesHealth", "InAppBrowserSampleApp.referencesHealth$InAppBrowserPlugin"], function (exports, OutSystems, InAppBrowserPluginModel, InAppBrowserSampleAppModel) {
var OS = OutSystems.Internal;
var IOSOptionsRecord = (function (_super) {
__extends(IOSOptionsRecord, _super);
function IOSOptionsRecord(defaults) {
_super.apply(this, arguments);
}
IOSOptionsRecord.attributesToDeclare = function () {
return [
this.attr("IOSOptions", "iOSOptionsAttr", "IOSOptions", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new InAppBrowserPluginModel.IOSOptionsRec());
}, true, InAppBrowserPluginModel.IOSOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
IOSOptionsRecord.fromStructure = function (str) {
return new IOSOptionsRecord(new IOSOptionsRecord.RecordClass({
iOSOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
IOSOptionsRecord._isAnonymousRecord = true;
IOSOptionsRecord.UniqueId = "0c270b9a-e7cb-7adc-70b9-1068cb7a9326";
IOSOptionsRecord.init();
return IOSOptionsRecord;
})(OS.DataTypes.GenericRecord);
InAppBrowserSampleAppModel.IOSOptionsRecord = IOSOptionsRecord;

});
define("InAppBrowserSampleApp.model$OptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "InAppBrowserPlugin.model", "InAppBrowserSampleApp.model", "InAppBrowserPlugin.model$OptionsRec", "InAppBrowserSampleApp.referencesHealth", "InAppBrowserSampleApp.referencesHealth$InAppBrowserPlugin"], function (exports, OutSystems, InAppBrowserPluginModel, InAppBrowserSampleAppModel) {
var OS = OutSystems.Internal;
var OptionsRecord = (function (_super) {
__extends(OptionsRecord, _super);
function OptionsRecord(defaults) {
_super.apply(this, arguments);
}
OptionsRecord.attributesToDeclare = function () {
return [
this.attr("Options", "optionsAttr", "Options", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new InAppBrowserPluginModel.OptionsRec());
}, true, InAppBrowserPluginModel.OptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
OptionsRecord.fromStructure = function (str) {
return new OptionsRecord(new OptionsRecord.RecordClass({
optionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
OptionsRecord._isAnonymousRecord = true;
OptionsRecord.UniqueId = "3345668e-036d-b903-ca5a-e74e58f9b56c";
OptionsRecord.init();
return OptionsRecord;
})(OS.DataTypes.GenericRecord);
InAppBrowserSampleAppModel.OptionsRecord = OptionsRecord;

});
define("InAppBrowserSampleApp.model$OptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "InAppBrowserSampleApp.model", "InAppBrowserSampleApp.model$OptionsRecord"], function (exports, OutSystems, InAppBrowserSampleAppModel) {
var OS = OutSystems.Internal;
var OptionsRecordList = (function (_super) {
__extends(OptionsRecordList, _super);
function OptionsRecordList(defaults) {
_super.apply(this, arguments);
}
OptionsRecordList.itemType = InAppBrowserSampleAppModel.OptionsRecord;
return OptionsRecordList;
})(OS.DataTypes.GenericRecordList);
InAppBrowserSampleAppModel.OptionsRecordList = OptionsRecordList;

});
define("InAppBrowserSampleApp.model$AndroidOptionsRecord", ["exports", "OutSystems/ClientRuntime/Main", "InAppBrowserPlugin.model", "InAppBrowserSampleApp.model", "InAppBrowserPlugin.model$AndroidOptionsRec", "InAppBrowserSampleApp.referencesHealth", "InAppBrowserSampleApp.referencesHealth$InAppBrowserPlugin"], function (exports, OutSystems, InAppBrowserPluginModel, InAppBrowserSampleAppModel) {
var OS = OutSystems.Internal;
var AndroidOptionsRecord = (function (_super) {
__extends(AndroidOptionsRecord, _super);
function AndroidOptionsRecord(defaults) {
_super.apply(this, arguments);
}
AndroidOptionsRecord.attributesToDeclare = function () {
return [
this.attr("AndroidOptions", "androidOptionsAttr", "AndroidOptions", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new InAppBrowserPluginModel.AndroidOptionsRec());
}, true, InAppBrowserPluginModel.AndroidOptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
AndroidOptionsRecord.fromStructure = function (str) {
return new AndroidOptionsRecord(new AndroidOptionsRecord.RecordClass({
androidOptionsAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
AndroidOptionsRecord._isAnonymousRecord = true;
AndroidOptionsRecord.UniqueId = "d46e748b-594b-42e4-f501-94e3f47f06cc";
AndroidOptionsRecord.init();
return AndroidOptionsRecord;
})(OS.DataTypes.GenericRecord);
InAppBrowserSampleAppModel.AndroidOptionsRecord = AndroidOptionsRecord;

});
define("InAppBrowserSampleApp.model$AndroidOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "InAppBrowserSampleApp.model", "InAppBrowserSampleApp.model$AndroidOptionsRecord"], function (exports, OutSystems, InAppBrowserSampleAppModel) {
var OS = OutSystems.Internal;
var AndroidOptionsRecordList = (function (_super) {
__extends(AndroidOptionsRecordList, _super);
function AndroidOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
AndroidOptionsRecordList.itemType = InAppBrowserSampleAppModel.AndroidOptionsRecord;
return AndroidOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
InAppBrowserSampleAppModel.AndroidOptionsRecordList = AndroidOptionsRecordList;

});
define("InAppBrowserSampleApp.model$MenuActionRecord", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "InAppBrowserSampleApp.model", "OutSystemsUI.model$MenuActionRec", "InAppBrowserSampleApp.referencesHealth", "InAppBrowserSampleApp.referencesHealth$OutSystemsUI"], function (exports, OutSystems, OutSystemsUIModel, InAppBrowserSampleAppModel) {
var OS = OutSystems.Internal;
var MenuActionRecord = (function (_super) {
__extends(MenuActionRecord, _super);
function MenuActionRecord(defaults) {
_super.apply(this, arguments);
}
MenuActionRecord.attributesToDeclare = function () {
return [
this.attr("MenuAction", "menuActionAttr", "MenuAction", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsUIModel.MenuActionRec());
}, true, OutSystemsUIModel.MenuActionRec)
].concat(_super.attributesToDeclare.call(this));
};
MenuActionRecord.fromStructure = function (str) {
return new MenuActionRecord(new MenuActionRecord.RecordClass({
menuActionAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
MenuActionRecord._isAnonymousRecord = true;
MenuActionRecord.UniqueId = "954cd123-1210-e70f-33f1-84017bf580ac";
MenuActionRecord.init();
return MenuActionRecord;
})(OS.DataTypes.GenericRecord);
InAppBrowserSampleAppModel.MenuActionRecord = MenuActionRecord;

});
define("InAppBrowserSampleApp.model$MenuActionRecordList", ["exports", "OutSystems/ClientRuntime/Main", "InAppBrowserSampleApp.model", "InAppBrowserSampleApp.model$MenuActionRecord"], function (exports, OutSystems, InAppBrowserSampleAppModel) {
var OS = OutSystems.Internal;
var MenuActionRecordList = (function (_super) {
__extends(MenuActionRecordList, _super);
function MenuActionRecordList(defaults) {
_super.apply(this, arguments);
}
MenuActionRecordList.itemType = InAppBrowserSampleAppModel.MenuActionRecord;
return MenuActionRecordList;
})(OS.DataTypes.GenericRecordList);
InAppBrowserSampleAppModel.MenuActionRecordList = MenuActionRecordList;

});
define("InAppBrowserSampleApp.model$ErrorList", ["exports", "OutSystems/ClientRuntime/Main", "CommonPlugin.model", "InAppBrowserSampleApp.model", "CommonPlugin.model$ErrorRec", "InAppBrowserSampleApp.referencesHealth", "InAppBrowserSampleApp.referencesHealth$CommonPlugin"], function (exports, OutSystems, CommonPluginModel, InAppBrowserSampleAppModel) {
var OS = OutSystems.Internal;
var ErrorList = (function (_super) {
__extends(ErrorList, _super);
function ErrorList(defaults) {
_super.apply(this, arguments);
}
ErrorList.itemType = CommonPluginModel.ErrorRec;
return ErrorList;
})(OS.DataTypes.GenericRecordList);
InAppBrowserSampleAppModel.ErrorList = ErrorList;

});
define("InAppBrowserSampleApp.model$ColumnBreakList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "InAppBrowserSampleApp.model", "OutSystemsUI.model$ColumnBreakRec", "InAppBrowserSampleApp.referencesHealth", "InAppBrowserSampleApp.referencesHealth$OutSystemsUI"], function (exports, OutSystems, OutSystemsUIModel, InAppBrowserSampleAppModel) {
var OS = OutSystems.Internal;
var ColumnBreakList = (function (_super) {
__extends(ColumnBreakList, _super);
function ColumnBreakList(defaults) {
_super.apply(this, arguments);
}
ColumnBreakList.itemType = OutSystemsUIModel.ColumnBreakRec;
return ColumnBreakList;
})(OS.DataTypes.GenericRecordList);
InAppBrowserSampleAppModel.ColumnBreakList = ColumnBreakList;

});
define("InAppBrowserSampleApp.model$Mobile_OperatingSystemRecord", ["exports", "OutSystems/ClientRuntime/Main", "CommonPlugin.model", "InAppBrowserSampleApp.model", "CommonPlugin.model$Mobile_OperatingSystemRec", "InAppBrowserSampleApp.referencesHealth", "InAppBrowserSampleApp.referencesHealth$CommonPlugin"], function (exports, OutSystems, CommonPluginModel, InAppBrowserSampleAppModel) {
var OS = OutSystems.Internal;
var Mobile_OperatingSystemRecord = (function (_super) {
__extends(Mobile_OperatingSystemRecord, _super);
function Mobile_OperatingSystemRecord(defaults) {
_super.apply(this, arguments);
}
Mobile_OperatingSystemRecord.attributesToDeclare = function () {
return [
this.attr("Mobile_OperatingSystem", "mobile_OperatingSystemAttr", "Mobile_OperatingSystem", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new CommonPluginModel.Mobile_OperatingSystemRec());
}, true, CommonPluginModel.Mobile_OperatingSystemRec)
].concat(_super.attributesToDeclare.call(this));
};
Mobile_OperatingSystemRecord.fromStructure = function (str) {
return new Mobile_OperatingSystemRecord(new Mobile_OperatingSystemRecord.RecordClass({
mobile_OperatingSystemAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
Mobile_OperatingSystemRecord._isAnonymousRecord = true;
Mobile_OperatingSystemRecord.UniqueId = "f56bdc75-0614-38d3-e901-3cdbe4073c38";
Mobile_OperatingSystemRecord.init();
return Mobile_OperatingSystemRecord;
})(OS.DataTypes.GenericRecord);
InAppBrowserSampleAppModel.Mobile_OperatingSystemRecord = Mobile_OperatingSystemRecord;

});
define("InAppBrowserSampleApp.model$Mobile_OperatingSystemRecordList", ["exports", "OutSystems/ClientRuntime/Main", "InAppBrowserSampleApp.model", "InAppBrowserSampleApp.model$Mobile_OperatingSystemRecord"], function (exports, OutSystems, InAppBrowserSampleAppModel) {
var OS = OutSystems.Internal;
var Mobile_OperatingSystemRecordList = (function (_super) {
__extends(Mobile_OperatingSystemRecordList, _super);
function Mobile_OperatingSystemRecordList(defaults) {
_super.apply(this, arguments);
}
Mobile_OperatingSystemRecordList.itemType = InAppBrowserSampleAppModel.Mobile_OperatingSystemRecord;
return Mobile_OperatingSystemRecordList;
})(OS.DataTypes.GenericRecordList);
InAppBrowserSampleAppModel.Mobile_OperatingSystemRecordList = Mobile_OperatingSystemRecordList;

});
define("InAppBrowserSampleApp.model$MenuActionList", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "InAppBrowserSampleApp.model", "OutSystemsUI.model$MenuActionRec", "InAppBrowserSampleApp.referencesHealth", "InAppBrowserSampleApp.referencesHealth$OutSystemsUI"], function (exports, OutSystems, OutSystemsUIModel, InAppBrowserSampleAppModel) {
var OS = OutSystems.Internal;
var MenuActionList = (function (_super) {
__extends(MenuActionList, _super);
function MenuActionList(defaults) {
_super.apply(this, arguments);
}
MenuActionList.itemType = OutSystemsUIModel.MenuActionRec;
return MenuActionList;
})(OS.DataTypes.GenericRecordList);
InAppBrowserSampleAppModel.MenuActionList = MenuActionList;

});
define("InAppBrowserSampleApp.model$InAppBrowserParametersRec", ["exports", "OutSystems/ClientRuntime/Main", "InAppBrowserPlugin.model", "InAppBrowserSampleApp.model", "InAppBrowserPlugin.model$OptionsRec", "InAppBrowserSampleApp.referencesHealth", "InAppBrowserSampleApp.referencesHealth$InAppBrowserPlugin"], function (exports, OutSystems, InAppBrowserPluginModel, InAppBrowserSampleAppModel) {
var OS = OutSystems.Internal;
var InAppBrowserParametersRec = (function (_super) {
__extends(InAppBrowserParametersRec, _super);
function InAppBrowserParametersRec(defaults) {
_super.apply(this, arguments);
}
InAppBrowserParametersRec.attributesToDeclare = function () {
return [
this.attr("URL", "uRLAttr", "URL", false, false, OS.Types.Text, function () {
return "https://www.outsystems.com/";
}, true), 
this.attr("TargetId", "targetIdAttr", "TargetId", false, false, OS.Types.Text, function () {
return InAppBrowserSampleAppModel.staticEntities.target.iN_APP_BROWSER;
}, true), 
this.attr("Options", "optionsAttr", "Options", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new InAppBrowserPluginModel.OptionsRec());
}, true, InAppBrowserPluginModel.OptionsRec)
].concat(_super.attributesToDeclare.call(this));
};
InAppBrowserParametersRec.init();
return InAppBrowserParametersRec;
})(OS.DataTypes.GenericRecord);
InAppBrowserSampleAppModel.InAppBrowserParametersRec = InAppBrowserParametersRec;

});
define("InAppBrowserSampleApp.model$InAppBrowserParametersList", ["exports", "OutSystems/ClientRuntime/Main", "InAppBrowserSampleApp.model", "InAppBrowserSampleApp.model$InAppBrowserParametersRec"], function (exports, OutSystems, InAppBrowserSampleAppModel) {
var OS = OutSystems.Internal;
var InAppBrowserParametersList = (function (_super) {
__extends(InAppBrowserParametersList, _super);
function InAppBrowserParametersList(defaults) {
_super.apply(this, arguments);
}
InAppBrowserParametersList.itemType = InAppBrowserSampleAppModel.InAppBrowserParametersRec;
return InAppBrowserParametersList;
})(OS.DataTypes.GenericRecordList);
InAppBrowserSampleAppModel.InAppBrowserParametersList = InAppBrowserParametersList;

});
define("InAppBrowserSampleApp.model$AndroidOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "InAppBrowserPlugin.model", "InAppBrowserSampleApp.model", "InAppBrowserPlugin.model$AndroidOptionsRec", "InAppBrowserSampleApp.referencesHealth", "InAppBrowserSampleApp.referencesHealth$InAppBrowserPlugin"], function (exports, OutSystems, InAppBrowserPluginModel, InAppBrowserSampleAppModel) {
var OS = OutSystems.Internal;
var AndroidOptionsList = (function (_super) {
__extends(AndroidOptionsList, _super);
function AndroidOptionsList(defaults) {
_super.apply(this, arguments);
}
AndroidOptionsList.itemType = InAppBrowserPluginModel.AndroidOptionsRec;
return AndroidOptionsList;
})(OS.DataTypes.GenericRecordList);
InAppBrowserSampleAppModel.AndroidOptionsList = AndroidOptionsList;

});
define("InAppBrowserSampleApp.model$TargetRecord", ["exports", "OutSystems/ClientRuntime/Main", "InAppBrowserPlugin.model", "InAppBrowserSampleApp.model", "InAppBrowserPlugin.model$TargetRec", "InAppBrowserSampleApp.referencesHealth", "InAppBrowserSampleApp.referencesHealth$InAppBrowserPlugin"], function (exports, OutSystems, InAppBrowserPluginModel, InAppBrowserSampleAppModel) {
var OS = OutSystems.Internal;
var TargetRecord = (function (_super) {
__extends(TargetRecord, _super);
function TargetRecord(defaults) {
_super.apply(this, arguments);
}
TargetRecord.attributesToDeclare = function () {
return [
this.attr("Target", "targetAttr", "Target", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new InAppBrowserPluginModel.TargetRec());
}, true, InAppBrowserPluginModel.TargetRec)
].concat(_super.attributesToDeclare.call(this));
};
TargetRecord.fromStructure = function (str) {
return new TargetRecord(new TargetRecord.RecordClass({
targetAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
TargetRecord._isAnonymousRecord = true;
TargetRecord.UniqueId = "f83c2a2d-e7f3-9c90-b767-e99968f2cc70";
TargetRecord.init();
return TargetRecord;
})(OS.DataTypes.GenericRecord);
InAppBrowserSampleAppModel.TargetRecord = TargetRecord;

});
define("InAppBrowserSampleApp.model$TargetRecordList", ["exports", "OutSystems/ClientRuntime/Main", "InAppBrowserSampleApp.model", "InAppBrowserSampleApp.model$TargetRecord"], function (exports, OutSystems, InAppBrowserSampleAppModel) {
var OS = OutSystems.Internal;
var TargetRecordList = (function (_super) {
__extends(TargetRecordList, _super);
function TargetRecordList(defaults) {
_super.apply(this, arguments);
}
TargetRecordList.itemType = InAppBrowserSampleAppModel.TargetRecord;
return TargetRecordList;
})(OS.DataTypes.GenericRecordList);
InAppBrowserSampleAppModel.TargetRecordList = TargetRecordList;

});
define("InAppBrowserSampleApp.model$ErrorRecord", ["exports", "OutSystems/ClientRuntime/Main", "CommonPlugin.model", "InAppBrowserSampleApp.model", "CommonPlugin.model$ErrorRec", "InAppBrowserSampleApp.referencesHealth", "InAppBrowserSampleApp.referencesHealth$CommonPlugin"], function (exports, OutSystems, CommonPluginModel, InAppBrowserSampleAppModel) {
var OS = OutSystems.Internal;
var ErrorRecord = (function (_super) {
__extends(ErrorRecord, _super);
function ErrorRecord(defaults) {
_super.apply(this, arguments);
}
ErrorRecord.attributesToDeclare = function () {
return [
this.attr("Error", "errorAttr", "Error", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new CommonPluginModel.ErrorRec());
}, true, CommonPluginModel.ErrorRec)
].concat(_super.attributesToDeclare.call(this));
};
ErrorRecord.fromStructure = function (str) {
return new ErrorRecord(new ErrorRecord.RecordClass({
errorAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
ErrorRecord._isAnonymousRecord = true;
ErrorRecord.UniqueId = "cbbd7d57-66e1-86ff-28ab-3b75adf75b93";
ErrorRecord.init();
return ErrorRecord;
})(OS.DataTypes.GenericRecord);
InAppBrowserSampleAppModel.ErrorRecord = ErrorRecord;

});
define("InAppBrowserSampleApp.model$ErrorRecordList", ["exports", "OutSystems/ClientRuntime/Main", "InAppBrowserSampleApp.model", "InAppBrowserSampleApp.model$ErrorRecord"], function (exports, OutSystems, InAppBrowserSampleAppModel) {
var OS = OutSystems.Internal;
var ErrorRecordList = (function (_super) {
__extends(ErrorRecordList, _super);
function ErrorRecordList(defaults) {
_super.apply(this, arguments);
}
ErrorRecordList.itemType = InAppBrowserSampleAppModel.ErrorRecord;
return ErrorRecordList;
})(OS.DataTypes.GenericRecordList);
InAppBrowserSampleAppModel.ErrorRecordList = ErrorRecordList;

});
define("InAppBrowserSampleApp.model$InAppBrowserParametersRecord", ["exports", "OutSystems/ClientRuntime/Main", "InAppBrowserSampleApp.model", "InAppBrowserSampleApp.model$InAppBrowserParametersRec"], function (exports, OutSystems, InAppBrowserSampleAppModel) {
var OS = OutSystems.Internal;
var InAppBrowserParametersRecord = (function (_super) {
__extends(InAppBrowserParametersRecord, _super);
function InAppBrowserParametersRecord(defaults) {
_super.apply(this, arguments);
}
InAppBrowserParametersRecord.attributesToDeclare = function () {
return [
this.attr("InAppBrowserParameters", "inAppBrowserParametersAttr", "InAppBrowserParameters", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new InAppBrowserSampleAppModel.InAppBrowserParametersRec());
}, true, InAppBrowserSampleAppModel.InAppBrowserParametersRec)
].concat(_super.attributesToDeclare.call(this));
};
InAppBrowserParametersRecord.fromStructure = function (str) {
return new InAppBrowserParametersRecord(new InAppBrowserParametersRecord.RecordClass({
inAppBrowserParametersAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
InAppBrowserParametersRecord._isAnonymousRecord = true;
InAppBrowserParametersRecord.UniqueId = "d2d6fa7b-4726-d406-5073-53d67b2dcd5e";
InAppBrowserParametersRecord.init();
return InAppBrowserParametersRecord;
})(OS.DataTypes.GenericRecord);
InAppBrowserSampleAppModel.InAppBrowserParametersRecord = InAppBrowserParametersRecord;

});
define("InAppBrowserSampleApp.model$InAppBrowserParametersRecordList", ["exports", "OutSystems/ClientRuntime/Main", "InAppBrowserSampleApp.model", "InAppBrowserSampleApp.model$InAppBrowserParametersRecord"], function (exports, OutSystems, InAppBrowserSampleAppModel) {
var OS = OutSystems.Internal;
var InAppBrowserParametersRecordList = (function (_super) {
__extends(InAppBrowserParametersRecordList, _super);
function InAppBrowserParametersRecordList(defaults) {
_super.apply(this, arguments);
}
InAppBrowserParametersRecordList.itemType = InAppBrowserSampleAppModel.InAppBrowserParametersRecord;
return InAppBrowserParametersRecordList;
})(OS.DataTypes.GenericRecordList);
InAppBrowserSampleAppModel.InAppBrowserParametersRecordList = InAppBrowserParametersRecordList;

});
define("InAppBrowserSampleApp.model$ColumnBreakRecord", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "InAppBrowserSampleApp.model", "OutSystemsUI.model$ColumnBreakRec", "InAppBrowserSampleApp.referencesHealth", "InAppBrowserSampleApp.referencesHealth$OutSystemsUI"], function (exports, OutSystems, OutSystemsUIModel, InAppBrowserSampleAppModel) {
var OS = OutSystems.Internal;
var ColumnBreakRecord = (function (_super) {
__extends(ColumnBreakRecord, _super);
function ColumnBreakRecord(defaults) {
_super.apply(this, arguments);
}
ColumnBreakRecord.attributesToDeclare = function () {
return [
this.attr("ColumnBreak", "columnBreakAttr", "ColumnBreak", false, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new OutSystemsUIModel.ColumnBreakRec());
}, true, OutSystemsUIModel.ColumnBreakRec)
].concat(_super.attributesToDeclare.call(this));
};
ColumnBreakRecord.fromStructure = function (str) {
return new ColumnBreakRecord(new ColumnBreakRecord.RecordClass({
columnBreakAttr: OS.DataTypes.ImmutableBase.getData(str)
}));
};
ColumnBreakRecord._isAnonymousRecord = true;
ColumnBreakRecord.UniqueId = "b6adbbf4-e08b-ad29-75a6-f8f796279b71";
ColumnBreakRecord.init();
return ColumnBreakRecord;
})(OS.DataTypes.GenericRecord);
InAppBrowserSampleAppModel.ColumnBreakRecord = ColumnBreakRecord;

});
define("InAppBrowserSampleApp.model$ColumnBreakRecordList", ["exports", "OutSystems/ClientRuntime/Main", "InAppBrowserSampleApp.model", "InAppBrowserSampleApp.model$ColumnBreakRecord"], function (exports, OutSystems, InAppBrowserSampleAppModel) {
var OS = OutSystems.Internal;
var ColumnBreakRecordList = (function (_super) {
__extends(ColumnBreakRecordList, _super);
function ColumnBreakRecordList(defaults) {
_super.apply(this, arguments);
}
ColumnBreakRecordList.itemType = InAppBrowserSampleAppModel.ColumnBreakRecord;
return ColumnBreakRecordList;
})(OS.DataTypes.GenericRecordList);
InAppBrowserSampleAppModel.ColumnBreakRecordList = ColumnBreakRecordList;

});
define("InAppBrowserSampleApp.model$TargetList", ["exports", "OutSystems/ClientRuntime/Main", "InAppBrowserPlugin.model", "InAppBrowserSampleApp.model", "InAppBrowserPlugin.model$TargetRec", "InAppBrowserSampleApp.referencesHealth", "InAppBrowserSampleApp.referencesHealth$InAppBrowserPlugin"], function (exports, OutSystems, InAppBrowserPluginModel, InAppBrowserSampleAppModel) {
var OS = OutSystems.Internal;
var TargetList = (function (_super) {
__extends(TargetList, _super);
function TargetList(defaults) {
_super.apply(this, arguments);
}
TargetList.itemType = InAppBrowserPluginModel.TargetRec;
return TargetList;
})(OS.DataTypes.GenericRecordList);
InAppBrowserSampleAppModel.TargetList = TargetList;

});
define("InAppBrowserSampleApp.model$IOSOptionsList", ["exports", "OutSystems/ClientRuntime/Main", "InAppBrowserPlugin.model", "InAppBrowserSampleApp.model", "InAppBrowserPlugin.model$IOSOptionsRec", "InAppBrowserSampleApp.referencesHealth", "InAppBrowserSampleApp.referencesHealth$InAppBrowserPlugin"], function (exports, OutSystems, InAppBrowserPluginModel, InAppBrowserSampleAppModel) {
var OS = OutSystems.Internal;
var IOSOptionsList = (function (_super) {
__extends(IOSOptionsList, _super);
function IOSOptionsList(defaults) {
_super.apply(this, arguments);
}
IOSOptionsList.itemType = InAppBrowserPluginModel.IOSOptionsRec;
return IOSOptionsList;
})(OS.DataTypes.GenericRecordList);
InAppBrowserSampleAppModel.IOSOptionsList = IOSOptionsList;

});
define("InAppBrowserSampleApp.model$OptionsList", ["exports", "OutSystems/ClientRuntime/Main", "InAppBrowserPlugin.model", "InAppBrowserSampleApp.model", "InAppBrowserPlugin.model$OptionsRec", "InAppBrowserSampleApp.referencesHealth", "InAppBrowserSampleApp.referencesHealth$InAppBrowserPlugin"], function (exports, OutSystems, InAppBrowserPluginModel, InAppBrowserSampleAppModel) {
var OS = OutSystems.Internal;
var OptionsList = (function (_super) {
__extends(OptionsList, _super);
function OptionsList(defaults) {
_super.apply(this, arguments);
}
OptionsList.itemType = InAppBrowserPluginModel.OptionsRec;
return OptionsList;
})(OS.DataTypes.GenericRecordList);
InAppBrowserSampleAppModel.OptionsList = OptionsList;

});
define("InAppBrowserSampleApp.model$IOSOptionsRecordList", ["exports", "OutSystems/ClientRuntime/Main", "InAppBrowserSampleApp.model", "InAppBrowserSampleApp.model$IOSOptionsRecord"], function (exports, OutSystems, InAppBrowserSampleAppModel) {
var OS = OutSystems.Internal;
var IOSOptionsRecordList = (function (_super) {
__extends(IOSOptionsRecordList, _super);
function IOSOptionsRecordList(defaults) {
_super.apply(this, arguments);
}
IOSOptionsRecordList.itemType = InAppBrowserSampleAppModel.IOSOptionsRecord;
return IOSOptionsRecordList;
})(OS.DataTypes.GenericRecordList);
InAppBrowserSampleAppModel.IOSOptionsRecordList = IOSOptionsRecordList;

});
define("InAppBrowserSampleApp.model$Mobile_OperatingSystemList", ["exports", "OutSystems/ClientRuntime/Main", "CommonPlugin.model", "InAppBrowserSampleApp.model", "CommonPlugin.model$Mobile_OperatingSystemRec", "InAppBrowserSampleApp.referencesHealth", "InAppBrowserSampleApp.referencesHealth$CommonPlugin"], function (exports, OutSystems, CommonPluginModel, InAppBrowserSampleAppModel) {
var OS = OutSystems.Internal;
var Mobile_OperatingSystemList = (function (_super) {
__extends(Mobile_OperatingSystemList, _super);
function Mobile_OperatingSystemList(defaults) {
_super.apply(this, arguments);
}
Mobile_OperatingSystemList.itemType = CommonPluginModel.Mobile_OperatingSystemRec;
return Mobile_OperatingSystemList;
})(OS.DataTypes.GenericRecordList);
InAppBrowserSampleAppModel.Mobile_OperatingSystemList = Mobile_OperatingSystemList;

});
define("InAppBrowserSampleApp.model", ["exports", "OutSystems/ClientRuntime/Main"], function (exports, OutSystems) {
var OS = OutSystems.Internal;
var InAppBrowserSampleAppModel = exports;
Object.defineProperty(InAppBrowserSampleAppModel, "module", {
get: function () {
return OS.ApplicationInfo.getModules()["67dab9a1-c6e7-44f2-8cdf-ce2e51c431b0"];
}
});

InAppBrowserSampleAppModel.staticEntities = {};
InAppBrowserSampleAppModel.staticEntities.target = {};
var getTargetRecord = function (record) {
return OS.ApplicationInfo.getModules()["411582e0-1482-4652-8bb1-ff206acc32fc"].staticEntities["571957b2-a064-4298-b194-fd269b3c9073"][record];
};
Object.defineProperty(InAppBrowserSampleAppModel.staticEntities.target, "iN_APP_BROWSER", {
get: function () {
return getTargetRecord("2b573f5a-c9be-4fce-9c58-143fd1cd4286");
}
});

Object.defineProperty(InAppBrowserSampleAppModel.staticEntities.target, "sYSTEM", {
get: function () {
return getTargetRecord("85ecde5b-e3d1-4a92-a878-5c3fead6481e");
}
});

InAppBrowserSampleAppModel.staticEntities.mobile_OperatingSystem = {};
var getMobile_OperatingSystemRecord = function (record) {
return OS.ApplicationInfo.getModules()["5b6515d9-f417-41d9-9c45-5dfc1a7b019f"].staticEntities["c1eb5dfb-b8c1-47fc-bc7d-1cd017f67311"][record];
};
Object.defineProperty(InAppBrowserSampleAppModel.staticEntities.mobile_OperatingSystem, "android", {
get: function () {
return getMobile_OperatingSystemRecord("01edb2f7-0e57-4dc0-9509-92d0d28ebfe3");
}
});

Object.defineProperty(InAppBrowserSampleAppModel.staticEntities.mobile_OperatingSystem, "windows", {
get: function () {
return getMobile_OperatingSystemRecord("164b2bee-9204-44fd-99b7-4d8e15ea9c63");
}
});

Object.defineProperty(InAppBrowserSampleAppModel.staticEntities.mobile_OperatingSystem, "iOS", {
get: function () {
return getMobile_OperatingSystemRecord("91c837e3-89f4-4179-9b8c-c79a99090027");
}
});

Object.defineProperty(InAppBrowserSampleAppModel.staticEntities.mobile_OperatingSystem, "other", {
get: function () {
return getMobile_OperatingSystemRecord("e0264a53-735d-4dea-8647-b8bfe757d34b");
}
});

InAppBrowserSampleAppModel.staticEntities.menuAction = {};
var getMenuActionRecord = function (record) {
return OS.ApplicationInfo.getModules()["8be17f2a-431c-4958-b894-c77b988a7271"].staticEntities["9cc12883-06ab-4cf0-9997-ede7c6c02d67"][record];
};
Object.defineProperty(InAppBrowserSampleAppModel.staticEntities.menuAction, "menu", {
get: function () {
return getMenuActionRecord("55ba18a9-cd6b-45dd-99ce-9081ee1387ea");
}
});

Object.defineProperty(InAppBrowserSampleAppModel.staticEntities.menuAction, "auto", {
get: function () {
return getMenuActionRecord("6c0c753a-86f4-4e76-9781-6e821c850c72");
}
});

Object.defineProperty(InAppBrowserSampleAppModel.staticEntities.menuAction, "hidden", {
get: function () {
return getMenuActionRecord("86c9d356-be64-46a1-b027-843ab93b4aea");
}
});

Object.defineProperty(InAppBrowserSampleAppModel.staticEntities.menuAction, "back", {
get: function () {
return getMenuActionRecord("f2db3c50-4c38-4ee7-a770-aa9476cb0d68");
}
});

InAppBrowserSampleAppModel.staticEntities.columnBreak = {};
var getColumnBreakRecord = function (record) {
return OS.ApplicationInfo.getModules()["8be17f2a-431c-4958-b894-c77b988a7271"].staticEntities["cce6ac21-942a-492f-8b46-64c5e6ea057b"][record];
};
Object.defineProperty(InAppBrowserSampleAppModel.staticEntities.columnBreak, "breakMiddle", {
get: function () {
return getColumnBreakRecord("3b01fc99-ef23-4043-8771-f88660720e01");
}
});

Object.defineProperty(InAppBrowserSampleAppModel.staticEntities.columnBreak, "breakAll", {
get: function () {
return getColumnBreakRecord("43788f73-6893-4396-b67a-04a6ff690e74");
}
});

Object.defineProperty(InAppBrowserSampleAppModel.staticEntities.columnBreak, "breakNone", {
get: function () {
return getColumnBreakRecord("69e6c609-9e8a-45a7-b006-45b92275ec49");
}
});

Object.defineProperty(InAppBrowserSampleAppModel.staticEntities.columnBreak, "breakLast", {
get: function () {
return getColumnBreakRecord("6b3725c8-8951-48ed-a977-cbfaf003c896");
}
});

Object.defineProperty(InAppBrowserSampleAppModel.staticEntities.columnBreak, "breakFirst", {
get: function () {
return getColumnBreakRecord("8c8b45b6-c1af-4b11-907e-3c8a5ce161e2");
}
});

});
