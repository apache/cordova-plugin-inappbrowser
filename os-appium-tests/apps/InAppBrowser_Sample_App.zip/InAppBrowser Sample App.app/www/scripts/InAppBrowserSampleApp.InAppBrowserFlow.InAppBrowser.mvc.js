﻿define("InAppBrowserSampleApp.InAppBrowserFlow.InAppBrowser.mvc$model", ["OutSystems/ClientRuntime/Main", "InAppBrowserSampleApp.model", "InAppBrowserPlugin.model", "CommonPlugin.model", "InAppBrowserPlugin.controller", "CommonPlugin.controller", "InAppBrowserPlugin.model$OptionsRec", "InAppBrowserSampleApp.referencesHealth", "InAppBrowserSampleApp.referencesHealth$InAppBrowserPlugin", "CommonPlugin.model$ErrorRec", "InAppBrowserSampleApp.referencesHealth$CommonPlugin", "InAppBrowserPlugin.controller$Open", "CommonPlugin.controller$GetOperatingSystem", "InAppBrowserPlugin.controller$CheckInAppBrowserPlugin", "InAppBrowserSampleApp.model$InAppBrowserParametersRec"], function (OutSystems, InAppBrowserSampleAppModel, InAppBrowserPluginModel, CommonPluginModel, InAppBrowserPluginController, CommonPluginController) {
var OS = OutSystems.Internal;


var VariablesRecord = (function (_super) {
__extends(VariablesRecord, _super);
function VariablesRecord(defaults) {
_super.apply(this, arguments);
}
VariablesRecord.attributesToDeclare = function () {
return [
this.attr("OperatingSystemsId", "operatingSystemsIdVar", "OperatingSystemsId", true, false, OS.Types.Text, function () {
return "";
}, false), 
this.attr("IsCorrectOS", "isCorrectOSVar", "IsCorrectOS", true, false, OS.Types.Boolean, function () {
return false;
}, false), 
this.attr("IsPluginLoaded", "isPluginLoadedVar", "IsPluginLoaded", true, false, OS.Types.Boolean, function () {
return false;
}, false), 
this.attr("IsExecutedOneCall", "isExecutedOneCallVar", "IsExecutedOneCall", true, false, OS.Types.Boolean, function () {
return false;
}, false), 
this.attr("Success", "successVar", "Success", true, false, OS.Types.Boolean, function () {
return false;
}, false), 
this.attr("Error", "errorVar", "Error", true, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new CommonPluginModel.ErrorRec());
}, false, CommonPluginModel.ErrorRec), 
this.attr("Parameters", "parametersVar", "Parameters", true, false, OS.Types.Record, function () {
return OS.DataTypes.ImmutableBase.getData(new InAppBrowserSampleAppModel.InAppBrowserParametersRec());
}, false, InAppBrowserSampleAppModel.InAppBrowserParametersRec)
].concat(_super.attributesToDeclare.call(this));
};
VariablesRecord.init();
return VariablesRecord;
})(OS.DataTypes.GenericRecord);
var WidgetsRecord = (function (_super) {
__extends(WidgetsRecord, _super);
function WidgetsRecord() {
_super.apply(this, arguments);
}
WidgetsRecord.getWidgetsType = function () {
return {
URLinput: OS.Model.ValidationWidgetRecord,
Form1: OS.Model.ValidationWidgetRecord,
ButtonGroup5: OS.Model.ValidationWidgetRecord,
Switch12: OS.Model.ValidationWidgetRecord,
Switch11: OS.Model.ValidationWidgetRecord,
Switch10: OS.Model.ValidationWidgetRecord,
Switch9: OS.Model.ValidationWidgetRecord,
Input_Closebuttoncaption: OS.Model.ValidationWidgetRecord,
Form2: OS.Model.ValidationWidgetRecord,
Switch3: OS.Model.ValidationWidgetRecord,
Switch2: OS.Model.ValidationWidgetRecord,
Switch1: OS.Model.ValidationWidgetRecord,
Form3: OS.Model.ValidationWidgetRecord,
Switch13: OS.Model.ValidationWidgetRecord,
Switch8: OS.Model.ValidationWidgetRecord,
Switch7: OS.Model.ValidationWidgetRecord,
Switch6: OS.Model.ValidationWidgetRecord,
Switch5: OS.Model.ValidationWidgetRecord,
Switch4: OS.Model.ValidationWidgetRecord,
ButtonGroup1: OS.Model.ValidationWidgetRecord,
ButtonGroup2: OS.Model.ValidationWidgetRecord,
ButtonGroup3: OS.Model.ValidationWidgetRecord
};
};

return WidgetsRecord;
})(OS.Model.BaseWidgetRecordMap);
var Model = (function (_super) {
__extends(Model, _super);
function Model() {
_super.apply(this, arguments);
}
Model.getVariablesRecordConstructor = function () {
return VariablesRecord;
};
Model.getWidgetsRecordConstructor = function () {
return WidgetsRecord;
};
Object.defineProperty(Model, "hasValidationWidgets", {
enumerable: true,
configurable: true,
get: function () {
return true;
}
});

Model.prototype.setInputs = function (inputs) {
};
return Model;
})(OS.Model.BaseViewModel);
return new OS.Model.ModelFactory(Model);
});
define("InAppBrowserSampleApp.InAppBrowserFlow.InAppBrowser.mvc$view", ["OutSystems/ClientRuntime/Main", "InAppBrowserSampleApp.model", "InAppBrowserSampleApp.controller", "InAppBrowserPlugin.model", "CommonPlugin.model", "InAppBrowserPlugin.controller", "CommonPlugin.controller", "react", "OutSystems/ReactView/Main", "InAppBrowserSampleApp.InAppBrowserFlow.InAppBrowser.mvc$model", "InAppBrowserSampleApp.InAppBrowserFlow.InAppBrowser.mvc$controller", "InAppBrowserSampleApp.Common.Layout.mvc$view", "OutSystems/ReactWidgets/Main", "OutSystemsUI.Utilities.MarginContainer.mvc$view", "OutSystemsUI.Adaptive.DEPRECATED_Columns2.mvc$view", "OutSystemsUI.Content.Section.mvc$view", "InAppBrowserPlugin.model$OptionsRec", "InAppBrowserSampleApp.referencesHealth", "InAppBrowserSampleApp.referencesHealth$InAppBrowserPlugin", "CommonPlugin.model$ErrorRec", "InAppBrowserSampleApp.referencesHealth$CommonPlugin", "InAppBrowserPlugin.controller$Open", "CommonPlugin.controller$GetOperatingSystem", "InAppBrowserPlugin.controller$CheckInAppBrowserPlugin", "InAppBrowserSampleApp.model$InAppBrowserParametersRec"], function (OutSystems, InAppBrowserSampleAppModel, InAppBrowserSampleAppController, InAppBrowserPluginModel, CommonPluginModel, InAppBrowserPluginController, CommonPluginController, React, OSView, InAppBrowserSampleApp_InAppBrowserFlow_InAppBrowser_mvc_model, InAppBrowserSampleApp_InAppBrowserFlow_InAppBrowser_mvc_controller, InAppBrowserSampleApp_Common_Layout_mvc_view, OSWidgets, OutSystemsUI_Utilities_MarginContainer_mvc_view, OutSystemsUI_Adaptive_DEPRECATED_Columns2_mvc_view, OutSystemsUI_Content_Section_mvc_view) {
    var OS = OutSystems.Internal;
var PlaceholderContent = OSView.Widget.PlaceholderContent;
var IteratorPlaceholderContent = OSView.Widget.IteratorPlaceholderContent;


    var View = (function (_super) {
        __extends(View,_super);
        function View() {
            try {
                this.initialize.apply(this, arguments);
            } catch (error) {
                View.handleError(error);
                throw error;
            }
        }
        View.prototype.initialize = function() {
            _super.apply(this, arguments);
        };
        View.displayName = "InAppBrowserFlow.InAppBrowser";
        View.getCssDependencies = function() {
            return ["css/OutSystemsReactWidgets.css", "css/OutSystemsUI.OSUIMobileBase.css", "css/OutSystemsUI.OSUIMobilePhone.css", "css/InAppBrowserSampleApp.InAppBrowserSampleApp.css", "css/OutSystemsUI.OSUIMobilePhone.extra.css"];
        };
        View.getJsDependencies = function() {
            return [];
        };
        View.getBlocks = function() {
            return [InAppBrowserSampleApp_Common_Layout_mvc_view, OutSystemsUI_Utilities_MarginContainer_mvc_view, OutSystemsUI_Adaptive_DEPRECATED_Columns2_mvc_view, OutSystemsUI_Content_Section_mvc_view];
        };
        Object.defineProperty(View.prototype, "modelFactory", {
            get: function () {
                return InAppBrowserSampleApp_InAppBrowserFlow_InAppBrowser_mvc_model;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "controllerFactory", {
            get: function () {
                return InAppBrowserSampleApp_InAppBrowserFlow_InAppBrowser_mvc_controller;
            },
            enumerable: true,
            configurable: true
        });
        Object.defineProperty(View.prototype, "title", {
            get: function () {
                return "";
            },
            enumerable: true,
            configurable: true
        });
        View.prototype.internalRender = function() {
            var model = this.model;
            var controller = this.controller;
            var idService = this.idService;
            var validationService = controller.validationService;
            var widgetsRecordProvider = this.widgetsRecordProvider;
            var callContext = controller.callContext();
            var $if = View.ifWidget;
            var asPrimitiveValue = View.asPrimitiveValue;
            var _this = this;

            return React.DOM.div(this.getRootNodeProperties(), React.createElement(InAppBrowserSampleApp_Common_Layout_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "0",
alias: "1"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
headerLeft: PlaceholderContent.Empty,
title: new PlaceholderContent(function () {
return ["In App Browser plugin"];
}),
headerRight: PlaceholderContent.Empty,
headerContent: PlaceholderContent.Empty,
content: new PlaceholderContent(function () {
return [$if(model.variables.isCorrectOSVar, false, this, function () {
return [$if(model.variables.isPluginLoadedVar, false, this, function () {
return [React.createElement(OutSystemsUI_Utilities_MarginContainer_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "1",
alias: "2"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
marginContainer: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Label, {
gridProperties: {
classes: "OSFillParent"
},
_idProps: {
service: idService,
uuid: "2"
},
_widgetRecordProvider: widgetsRecordProvider
}, "URL to be open"), React.createElement(OSWidgets.Input, {
_validationProps: {
validationService: validationService
},
enabled: true,
gridProperties: {
classes: "OSFillParent"
},
inputType: /*Text*/ 0,
mandatory: false,
maxLength: 0,
style: "form-control",
variable: model.createVariable(OS.Types.Text, model.variables.parametersVar.uRLAttr, function (value) {
model.variables.parametersVar.uRLAttr = value;
}),
_idProps: {
service: idService,
name: "URLinput"
},
_widgetRecordProvider: widgetsRecordProvider
}), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
extendedProperties: {
"data-style-key": "S0M7J894sEqi6sTU279PoQ"
},
visible: true,
_idProps: {
service: idService,
uuid: "4"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OutSystemsUI_Adaptive_DEPRECATED_Columns2_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "5",
alias: "3"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
column1: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Button, {
enabled: true,
gridProperties: {
classes: "OSFillParent"
},
isDefault: false,
onClick: function () {
var eventHandlerContext = callContext.clone();
controller.imdbTrailerOnClick$Action(controller.callContext(eventHandlerContext));

;
},
style: "btn btn-primary background-grey",
visible: true,
_idProps: {
service: idService,
name: "button_https_valid_url"
},
_widgetRecordProvider: widgetsRecordProvider
}, "HTTPS(IMDB Trailer)")];
}),
column2: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Button, {
enabled: true,
gridProperties: {
classes: "OSFillParent"
},
isDefault: false,
onClick: function () {
var eventHandlerContext = callContext.clone();
controller.enMobiledownl_OnClick$Action(controller.callContext(eventHandlerContext));

;
},
style: "btn btn-primary background-grey",
visible: true,
_idProps: {
service: idService,
name: "button_valid_url_forbidden_connection"
},
_widgetRecordProvider: widgetsRecordProvider
}, "EnMobile downl.")];
})
},
_dependencies: []
})), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
extendedProperties: {
"data-style-key": "_9HdV7vtzEGDL5y3oXXo2g"
},
visible: true,
_idProps: {
service: idService,
uuid: "8"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OutSystemsUI_Adaptive_DEPRECATED_Columns2_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "9",
alias: "4"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
column1: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Button, {
enabled: true,
gridProperties: {
classes: "OSFillParent"
},
isDefault: false,
onClick: function () {
var eventHandlerContext = callContext.clone();
controller.hTTPOnClick$Action(controller.callContext(eventHandlerContext));

;
},
style: "btn btn-primary background-grey",
visible: true,
_idProps: {
service: idService,
name: "button_http_valid_url"
},
_widgetRecordProvider: widgetsRecordProvider
}, "HTTP(Cinema Nos)")];
}),
column2: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Button, {
enabled: true,
gridProperties: {
classes: "OSFillParent"
},
isDefault: false,
onClick: function () {
var eventHandlerContext = callContext.clone();
controller.enMobileopenOnClick$Action(controller.callContext(eventHandlerContext));

;
},
style: "btn btn-primary background-grey",
visible: true,
_idProps: {
service: idService,
uuid: "11"
},
_widgetRecordProvider: widgetsRecordProvider
}, "EnMobile open")];
})
},
_dependencies: []
})), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
extendedProperties: {
"data-style-key": "vAt7OgL0XkGA5eEe_npvZw"
},
visible: true,
_idProps: {
service: idService,
uuid: "12"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OutSystemsUI_Adaptive_DEPRECATED_Columns2_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "13",
alias: "5"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
column1: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Button, {
enabled: true,
gridProperties: {
classes: "OSFillParent"
},
isDefault: false,
onClick: function () {
var eventHandlerContext = callContext.clone();
controller.uRLStrangeOnClick$Action(controller.callContext(eventHandlerContext));

;
},
style: "btn btn-primary background-grey",
visible: true,
_idProps: {
service: idService,
name: "button_https_valid_url_extra_chars_url_constructio"
},
_widgetRecordProvider: widgetsRecordProvider
}, "URL with %, &,...")];
}),
column2: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Button, {
enabled: true,
gridProperties: {
classes: "OSFillParent"
},
isDefault: false,
onClick: function () {
var eventHandlerContext = callContext.clone();
controller.relativeURLOnClick$Action(controller.callContext(eventHandlerContext));

;
},
style: "btn btn-primary background-grey",
visible: true,
_idProps: {
service: idService,
name: "button_no_http_relativ_url_not_working"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Relative URL")];
})
},
_dependencies: []
})), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
extendedProperties: {
"data-style-key": "H2HWX+sR4Emn_t6xEXXmfA"
},
visible: true,
_idProps: {
service: idService,
uuid: "16"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OutSystemsUI_Adaptive_DEPRECATED_Columns2_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "17",
alias: "6"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
column1: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Button, {
enabled: true,
gridProperties: {
classes: "OSFillParent"
},
isDefault: false,
onClick: function () {
var eventHandlerContext = callContext.clone();
controller.uRLwithpdfOnClick$Action(controller.callContext(eventHandlerContext));

;
},
style: "btn btn-primary background-grey",
visible: true,
_idProps: {
service: idService,
name: "button_valid_url_open_doc_format_pdf"
},
_widgetRecordProvider: widgetsRecordProvider
}, "URL with pdf")];
}),
column2: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Button, {
enabled: true,
gridProperties: {
classes: "OSFillParent"
},
isDefault: false,
onClick: function () {
var eventHandlerContext = callContext.clone();
controller.wrongURLOnClick$Action(controller.callContext(eventHandlerContext));

;
},
style: "btn btn-primary background-grey",
visible: true,
_idProps: {
service: idService,
name: "button_h2ttps_invalid_url"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Wrong URL")];
})
},
_dependencies: []
}))];
})
},
_dependencies: [asPrimitiveValue(model.variables.parametersVar.uRLAttr)]
}), React.createElement(OutSystemsUI_Content_Section_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "20",
alias: "7"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
title: new PlaceholderContent(function () {
return ["General Parameters"];
}),
content: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Form, {
_validationProps: {
validationService: validationService
},
gridProperties: {
classes: "OSFillParent"
},
style: "form card",
_idProps: {
service: idService,
name: "Form1"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "22"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Label, {
gridProperties: {
classes: "OSFillParent"
},
_idProps: {
service: idService,
uuid: "23"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Target"), React.createElement(OSWidgets.ButtonGroup, {
_validationProps: {
validationService: validationService,
validationParentId: idService.getId("Form1")
},
enabled: true,
mandatory: false,
style: "button-group",
variable: model.createVariable(OS.Types.Text, model.variables.parametersVar.targetIdAttr, function (value) {
model.variables.parametersVar.targetIdAttr = value;
}),
_idProps: {
service: idService,
name: "ButtonGroup5"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.ButtonGroupItem, {
enabled: true,
style: "button-group-item",
value: InAppBrowserSampleAppModel.staticEntities.target.iN_APP_BROWSER,
visible: true,
_idProps: {
service: idService,
name: "ButtonGroupItem11"
},
_widgetRecordProvider: widgetsRecordProvider
}, "IN APP BROWSER"), React.createElement(OSWidgets.ButtonGroupItem, {
enabled: true,
style: "button-group-item",
value: InAppBrowserSampleAppModel.staticEntities.target.sYSTEM,
visible: true,
_idProps: {
service: idService,
name: "ButtonGroupItem12"
},
_widgetRecordProvider: widgetsRecordProvider
}, "SYSTEM"))), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "text-note",
visible: true,
_idProps: {
service: idService,
uuid: "27"
},
_widgetRecordProvider: widgetsRecordProvider
}, "The target in which to load the URL."), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "OSAutoMarginTop",
visible: true,
_idProps: {
service: idService,
uuid: "28"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Label, {
gridProperties: {
classes: "OSFillParent"
},
targetWidget: "Switch12",
_idProps: {
service: idService,
uuid: "29"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Location"), React.createElement(OSWidgets.Switch, {
_validationProps: {
validationService: validationService,
validationParentId: idService.getId("Form1")
},
enabled: true,
style: "switch",
variable: model.createVariable(OS.Types.Boolean, model.variables.parametersVar.optionsAttr.locationAttr, function (value) {
model.variables.parametersVar.optionsAttr.locationAttr = value;
}),
_idProps: {
service: idService,
name: "Switch12"
},
_widgetRecordProvider: widgetsRecordProvider
}), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "text-note",
visible: true,
_idProps: {
service: idService,
uuid: "31"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Set to Yes or No to turn the InAppBrowser\'s location bar on or off")), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "OSAutoMarginTop",
visible: true,
_idProps: {
service: idService,
uuid: "32"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Label, {
gridProperties: {
classes: "OSFillParent"
},
targetWidget: "Switch11",
_idProps: {
service: idService,
uuid: "33"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Clearcache"), React.createElement(OSWidgets.Switch, {
_validationProps: {
validationService: validationService,
validationParentId: idService.getId("Form1")
},
enabled: true,
style: "switch",
variable: model.createVariable(OS.Types.Boolean, model.variables.parametersVar.optionsAttr.clearcacheAttr, function (value) {
model.variables.parametersVar.optionsAttr.clearcacheAttr = value;
}),
_idProps: {
service: idService,
name: "Switch11"
},
_widgetRecordProvider: widgetsRecordProvider
}), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "text-note",
visible: true,
_idProps: {
service: idService,
uuid: "35"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Set to True to have the browser\'s cookie cache cleared before the new window is opened")), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "OSAutoMarginTop",
visible: true,
_idProps: {
service: idService,
uuid: "36"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Label, {
gridProperties: {
classes: "OSFillParent"
},
targetWidget: "Switch10",
_idProps: {
service: idService,
uuid: "37"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Clear session cache"), React.createElement(OSWidgets.Switch, {
_validationProps: {
validationService: validationService,
validationParentId: idService.getId("Form1")
},
enabled: true,
style: "switch",
variable: model.createVariable(OS.Types.Boolean, model.variables.parametersVar.optionsAttr.clearsessioncacheAttr, function (value) {
model.variables.parametersVar.optionsAttr.clearsessioncacheAttr = value;
}),
_idProps: {
service: idService,
name: "Switch10"
},
_widgetRecordProvider: widgetsRecordProvider
}), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "text-note",
visible: true,
_idProps: {
service: idService,
uuid: "39"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Set to True to have the session cookie cache cleared before the new window is opened")), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "OSAutoMarginTop",
visible: true,
_idProps: {
service: idService,
uuid: "40"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Label, {
gridProperties: {
classes: "OSFillParent"
},
targetWidget: "Switch9",
_idProps: {
service: idService,
uuid: "41"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Media Playback Requires User Action"), React.createElement(OSWidgets.Switch, {
_validationProps: {
validationService: validationService,
validationParentId: idService.getId("Form1")
},
enabled: true,
style: "switch",
variable: model.createVariable(OS.Types.Boolean, model.variables.parametersVar.optionsAttr.mediaPlaybackRequiresUserActionAttr, function (value) {
model.variables.parametersVar.optionsAttr.mediaPlaybackRequiresUserActionAttr = value;
}),
_idProps: {
service: idService,
name: "Switch9"
},
_widgetRecordProvider: widgetsRecordProvider
}), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "text-note",
visible: true,
_idProps: {
service: idService,
uuid: "43"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Set to True to prevent HTML5 audio or video from autoplaying")), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "OSAutoMarginTop",
visible: true,
_idProps: {
service: idService,
uuid: "44"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Label, {
gridProperties: {
classes: "OSFillParent"
},
mandatory: false,
targetWidget: "Input_Closebuttoncaption",
_idProps: {
service: idService,
uuid: "45"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Close button caption"), React.createElement(OSWidgets.Input, {
_validationProps: {
validationService: validationService,
validationParentId: idService.getId("Form1")
},
enabled: true,
gridProperties: {
classes: "OSFillParent"
},
inputType: /*Text*/ 0,
mandatory: false,
maxLength: 0,
style: "form-control",
variable: model.createVariable(OS.Types.Text, model.variables.parametersVar.optionsAttr.iosAttr.closebuttoncaptionAttr, function (value) {
model.variables.parametersVar.optionsAttr.iosAttr.closebuttoncaptionAttr = value;
}),
_idProps: {
service: idService,
name: "Input_Closebuttoncaption"
},
_widgetRecordProvider: widgetsRecordProvider
}), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "text-note",
visible: true,
_idProps: {
service: idService,
uuid: "47"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Set to a string to use as the Done button\'s caption"), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
extendedProperties: {
"data-style-key": "GFxanJjp4kei5ogkKWiljg"
},
visible: true,
_idProps: {
service: idService,
uuid: "48"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OutSystemsUI_Adaptive_DEPRECATED_Columns2_mvc_view, {
inputs: {
PhoneLandscapeBreak: InAppBrowserSampleAppModel.staticEntities.columnBreak.breakLast
},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService,
validationParentId: idService.getId("Form1")
},
_idProps: {
service: idService,
uuid: "49",
alias: "8"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
column1: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Button, {
enabled: true,
gridProperties: {
classes: "OSFillParent"
},
isDefault: false,
onClick: function () {
_this.validateWidget(idService.getId("Form1"));
var eventHandlerContext = callContext.clone();
controller.emptyOnClick$Action(controller.callContext(eventHandlerContext));


;
},
style: "btn btn-primary background-grey",
visible: true,
_idProps: {
service: idService,
uuid: "50"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Empty")];
}),
column2: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Button, {
enabled: true,
gridProperties: {
classes: "OSFillParent"
},
isDefault: false,
onClick: function () {
_this.validateWidget(idService.getId("Form1"));
var eventHandlerContext = callContext.clone();
controller.textOnClick$Action(controller.callContext(eventHandlerContext));


;
},
style: "btn btn-primary background-grey",
visible: true,
_idProps: {
service: idService,
uuid: "51"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Text")];
})
},
_dependencies: []
})), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
extendedProperties: {
"data-style-key": "VwDFTeILq0GJINEbK8TPag"
},
visible: true,
_idProps: {
service: idService,
uuid: "52"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OutSystemsUI_Adaptive_DEPRECATED_Columns2_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService,
validationParentId: idService.getId("Form1")
},
_idProps: {
service: idService,
uuid: "53",
alias: "9"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
column1: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Button, {
enabled: true,
gridProperties: {
classes: "OSFillParent"
},
isDefault: false,
onClick: function () {
_this.validateWidget(idService.getId("Form1"));
var eventHandlerContext = callContext.clone();
controller.numbersOnClick$Action(controller.callContext(eventHandlerContext));


;
},
style: "btn btn-primary background-grey",
visible: true,
_idProps: {
service: idService,
uuid: "54"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Numbers")];
}),
column2: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Button, {
enabled: true,
gridProperties: {
classes: "OSFillParent"
},
isDefault: false,
onClick: function () {
_this.validateWidget(idService.getId("Form1"));
var eventHandlerContext = callContext.clone();
controller.symbolsOnClick$Action(controller.callContext(eventHandlerContext));


;
},
style: "btn btn-primary background-grey",
visible: true,
_idProps: {
service: idService,
uuid: "55"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Symbols")];
})
},
_dependencies: []
}))))];
})
},
_dependencies: [asPrimitiveValue(model.variables.parametersVar.optionsAttr.iosAttr.closebuttoncaptionAttr), asPrimitiveValue(model.variables.parametersVar.optionsAttr.mediaPlaybackRequiresUserActionAttr), asPrimitiveValue(model.variables.parametersVar.optionsAttr.clearsessioncacheAttr), asPrimitiveValue(model.variables.parametersVar.optionsAttr.clearcacheAttr), asPrimitiveValue(model.variables.parametersVar.optionsAttr.locationAttr), asPrimitiveValue(model.variables.parametersVar.targetIdAttr)]
}), React.createElement(OutSystemsUI_Content_Section_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "56",
alias: "10"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
title: new PlaceholderContent(function () {
return [$if((model.variables.operatingSystemsIdVar === InAppBrowserSampleAppModel.staticEntities.mobile_OperatingSystem.android), false, this, function () {
return ["Android"];
}, function () {
return ["iOS"];
}), " specific Parameters"];
}),
content: new PlaceholderContent(function () {
return [$if((model.variables.operatingSystemsIdVar === InAppBrowserSampleAppModel.staticEntities.mobile_OperatingSystem.android), false, this, function () {
return [React.createElement(OSWidgets.Form, {
_validationProps: {
validationService: validationService
},
gridProperties: {
classes: "OSFillParent"
},
style: "form card",
_idProps: {
service: idService,
name: "Form2"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "58"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Label, {
gridProperties: {
classes: "OSFillParent"
},
targetWidget: "Switch3",
_idProps: {
service: idService,
uuid: "59"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Zoom"), React.createElement(OSWidgets.Switch, {
_validationProps: {
validationService: validationService,
validationParentId: idService.getId("Form2")
},
enabled: true,
style: "switch",
variable: model.createVariable(OS.Types.Boolean, model.variables.parametersVar.optionsAttr.androidAttr.zoomAttr, function (value) {
model.variables.parametersVar.optionsAttr.androidAttr.zoomAttr = value;
}),
_idProps: {
service: idService,
name: "Switch3"
},
_widgetRecordProvider: widgetsRecordProvider
}), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "text-note",
visible: true,
_idProps: {
service: idService,
uuid: "61"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Set to True to show Android browser\'s zoom controls, set to False to hide them")), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "OSAutoMarginTop",
visible: true,
_idProps: {
service: idService,
uuid: "62"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Label, {
gridProperties: {
classes: "OSFillParent"
},
targetWidget: "Switch2",
_idProps: {
service: idService,
uuid: "63"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Hardware back"), React.createElement(OSWidgets.Switch, {
_validationProps: {
validationService: validationService,
validationParentId: idService.getId("Form2")
},
enabled: true,
style: "switch",
variable: model.createVariable(OS.Types.Boolean, model.variables.parametersVar.optionsAttr.androidAttr.hardwarebackAttr, function (value) {
model.variables.parametersVar.optionsAttr.androidAttr.hardwarebackAttr = value;
}),
_idProps: {
service: idService,
name: "Switch2"
},
_widgetRecordProvider: widgetsRecordProvider
}), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "text-note",
visible: true,
_idProps: {
service: idService,
uuid: "65"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Set to yes to use the hardware back button to navigate backwards through the InAppBrowser\'s history. If there is no previous page, the InAppBrowser will close. The default value is True, so you must set it to False if you want the back button to simply close the InAppBrowser")), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "OSAutoMarginTop",
visible: true,
_idProps: {
service: idService,
uuid: "66"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Label, {
gridProperties: {
classes: "OSFillParent"
},
targetWidget: "Switch1",
_idProps: {
service: idService,
uuid: "67"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Should Pause On Suspend"), React.createElement(OSWidgets.Switch, {
_validationProps: {
validationService: validationService,
validationParentId: idService.getId("Form2")
},
enabled: true,
style: "switch",
variable: model.createVariable(OS.Types.Boolean, model.variables.parametersVar.optionsAttr.androidAttr.shouldPauseOnSuspendAttr, function (value) {
model.variables.parametersVar.optionsAttr.androidAttr.shouldPauseOnSuspendAttr = value;
}),
_idProps: {
service: idService,
name: "Switch1"
},
_widgetRecordProvider: widgetsRecordProvider
}), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "text-note",
visible: true,
_idProps: {
service: idService,
uuid: "69"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Set to True to make InAppBrowser WebView to pause/resume with the app to stop background audio. Note, this may be required to avoid Google Play issues like Youtube videos playback while the application is in background")))];
}, function () {
return [React.createElement(OSWidgets.Form, {
_validationProps: {
validationService: validationService
},
gridProperties: {
classes: "OSFillParent"
},
style: "form card",
_idProps: {
service: idService,
name: "Form3"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "71"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Label, {
gridProperties: {
classes: "OSFillParent"
},
targetWidget: "Switch13",
_idProps: {
service: idService,
uuid: "72"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Disallow overscroll"), React.createElement(OSWidgets.Switch, {
_validationProps: {
validationService: validationService,
validationParentId: idService.getId("Form3")
},
enabled: true,
style: "switch",
variable: model.createVariable(OS.Types.Boolean, model.variables.successVar, function (value) {
model.variables.successVar = value;
}),
_idProps: {
service: idService,
name: "Switch13"
},
_widgetRecordProvider: widgetsRecordProvider
}), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "text-note",
visible: true,
_idProps: {
service: idService,
uuid: "74"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Set to True or False to turn on or off the WebView bounce property")), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "OSAutoMarginTop",
visible: true,
_idProps: {
service: idService,
uuid: "75"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Label, {
gridProperties: {
classes: "OSFillParent"
},
targetWidget: "Switch8",
_idProps: {
service: idService,
uuid: "76"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Toolbar"), React.createElement(OSWidgets.Switch, {
_validationProps: {
validationService: validationService,
validationParentId: idService.getId("Form3")
},
enabled: true,
style: "switch",
variable: model.createVariable(OS.Types.Boolean, model.variables.parametersVar.optionsAttr.iosAttr.toolbarAttr, function (value) {
model.variables.parametersVar.optionsAttr.iosAttr.toolbarAttr = value;
}),
_idProps: {
service: idService,
name: "Switch8"
},
_widgetRecordProvider: widgetsRecordProvider
}), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "text-note",
visible: true,
_idProps: {
service: idService,
uuid: "78"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Set to True or False to turn the toolbar on or off for the InAppBrowser")), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "OSAutoMarginTop",
visible: true,
_idProps: {
service: idService,
uuid: "79"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Label, {
gridProperties: {
classes: "OSFillParent"
},
targetWidget: "Switch7",
_idProps: {
service: idService,
uuid: "80"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Enable Viewport Scale"), React.createElement(OSWidgets.Switch, {
_validationProps: {
validationService: validationService,
validationParentId: idService.getId("Form3")
},
enabled: true,
style: "switch",
variable: model.createVariable(OS.Types.Boolean, model.variables.parametersVar.optionsAttr.iosAttr.enableViewportScaleAttr, function (value) {
model.variables.parametersVar.optionsAttr.iosAttr.enableViewportScaleAttr = value;
}),
_idProps: {
service: idService,
name: "Switch7"
},
_widgetRecordProvider: widgetsRecordProvider
}), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "text-note",
visible: true,
_idProps: {
service: idService,
uuid: "82"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Set to True or False to prevent viewport scaling through a meta tag")), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "OSAutoMarginTop",
visible: true,
_idProps: {
service: idService,
uuid: "83"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Label, {
gridProperties: {
classes: "OSFillParent"
},
targetWidget: "Switch6",
_idProps: {
service: idService,
uuid: "84"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Allow Inline Media Playback"), React.createElement(OSWidgets.Switch, {
_validationProps: {
validationService: validationService,
validationParentId: idService.getId("Form3")
},
enabled: true,
style: "switch",
variable: model.createVariable(OS.Types.Boolean, model.variables.parametersVar.optionsAttr.iosAttr.allowInlineMediaPlaybackAttr, function (value) {
model.variables.parametersVar.optionsAttr.iosAttr.allowInlineMediaPlaybackAttr = value;
}),
_idProps: {
service: idService,
name: "Switch6"
},
_widgetRecordProvider: widgetsRecordProvider
}), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "text-note",
visible: true,
_idProps: {
service: idService,
uuid: "86"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Set to True or False to allow in-line HTML5 media playback, displaying within the browser window rather than a device-specific playback interface. Note: The HTML\'s video element must also include the webkit-playsinline attribute")), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "OSAutoMarginTop",
visible: true,
_idProps: {
service: idService,
uuid: "87"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Label, {
gridProperties: {
classes: "OSFillParent"
},
targetWidget: "Switch5",
_idProps: {
service: idService,
uuid: "88"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Keyboard Display Requires User Action"), React.createElement(OSWidgets.Switch, {
_validationProps: {
validationService: validationService,
validationParentId: idService.getId("Form3")
},
enabled: true,
style: "switch",
variable: model.createVariable(OS.Types.Boolean, model.variables.parametersVar.optionsAttr.iosAttr.keyboardDisplayRequiresUserActionAttr, function (value) {
model.variables.parametersVar.optionsAttr.iosAttr.keyboardDisplayRequiresUserActionAttr = value;
}),
_idProps: {
service: idService,
name: "Switch5"
},
_widgetRecordProvider: widgetsRecordProvider
}), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "text-note",
visible: true,
_idProps: {
service: idService,
uuid: "90"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Set to True or False to open the keyboard when form elements receive focus via JavaScript\'s focus() call")), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "OSAutoMarginTop",
visible: true,
_idProps: {
service: idService,
uuid: "91"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Label, {
gridProperties: {
classes: "OSFillParent"
},
targetWidget: "Switch4",
_idProps: {
service: idService,
uuid: "92"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Suppresses Incremental Rendering"), React.createElement(OSWidgets.Switch, {
_validationProps: {
validationService: validationService,
validationParentId: idService.getId("Form3")
},
enabled: true,
style: "switch",
variable: model.createVariable(OS.Types.Boolean, model.variables.parametersVar.optionsAttr.iosAttr.suppressesIncrementalRenderingAttr, function (value) {
model.variables.parametersVar.optionsAttr.iosAttr.suppressesIncrementalRenderingAttr = value;
}),
_idProps: {
service: idService,
name: "Switch4"
},
_widgetRecordProvider: widgetsRecordProvider
}), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "text-note",
visible: true,
_idProps: {
service: idService,
uuid: "94"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Set to True or False to wait until all new view content is received before being rendered")), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "OSAutoMarginTop",
visible: true,
_idProps: {
service: idService,
uuid: "95"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Label, {
gridProperties: {
classes: "OSFillParent"
},
_idProps: {
service: idService,
uuid: "96"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Presentation style"), React.createElement(OSWidgets.ButtonGroup, {
_validationProps: {
validationService: validationService,
validationParentId: idService.getId("Form3")
},
enabled: true,
mandatory: false,
style: "button-group",
variable: model.createVariable(OS.Types.Text, model.variables.parametersVar.optionsAttr.iosAttr.presentationstyleAttr, function (value) {
model.variables.parametersVar.optionsAttr.iosAttr.presentationstyleAttr = value;
}),
_idProps: {
service: idService,
name: "ButtonGroup1"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.ButtonGroupItem, {
enabled: true,
style: "button-group-item",
value: "pagesheet",
visible: true,
_idProps: {
service: idService,
name: "ButtonGroupItem1"
},
_widgetRecordProvider: widgetsRecordProvider
}, "pagesheet"), React.createElement(OSWidgets.ButtonGroupItem, {
enabled: true,
style: "button-group-item",
value: "formsheet",
visible: true,
_idProps: {
service: idService,
name: "ButtonGroupItem2"
},
_widgetRecordProvider: widgetsRecordProvider
}, "formsheet"), React.createElement(OSWidgets.ButtonGroupItem, {
enabled: true,
style: "button-group-item",
value: "fullscreen",
visible: true,
_idProps: {
service: idService,
name: "ButtonGroupItem3"
},
_widgetRecordProvider: widgetsRecordProvider
}, "fullscreen")), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "text-note",
visible: true,
_idProps: {
service: idService,
uuid: "101"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Set to \"pagesheet\", \"formsheet\" or \"fullscreen\" to set the presentation style")), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "OSAutoMarginTop",
visible: true,
_idProps: {
service: idService,
uuid: "102"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Label, {
gridProperties: {
classes: "OSFillParent"
},
_idProps: {
service: idService,
uuid: "103"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Transition style"), React.createElement(OSWidgets.ButtonGroup, {
_validationProps: {
validationService: validationService,
validationParentId: idService.getId("Form3")
},
enabled: true,
mandatory: false,
style: "button-group",
variable: model.createVariable(OS.Types.Text, model.variables.parametersVar.optionsAttr.iosAttr.transitionstyleAttr, function (value) {
model.variables.parametersVar.optionsAttr.iosAttr.transitionstyleAttr = value;
}),
_idProps: {
service: idService,
name: "ButtonGroup2"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.ButtonGroupItem, {
enabled: true,
style: "button-group-item",
value: "fliphorizontal",
visible: true,
_idProps: {
service: idService,
name: "ButtonGroupItem4"
},
_widgetRecordProvider: widgetsRecordProvider
}, "fliphorizontal"), React.createElement(OSWidgets.ButtonGroupItem, {
enabled: true,
style: "button-group-item",
value: "crossdissolve",
visible: true,
_idProps: {
service: idService,
name: "ButtonGroupItem5"
},
_widgetRecordProvider: widgetsRecordProvider
}, "crossdissolve"), React.createElement(OSWidgets.ButtonGroupItem, {
enabled: true,
style: "button-group-item",
value: "coververtical",
visible: true,
_idProps: {
service: idService,
name: "ButtonGroupItem6"
},
_widgetRecordProvider: widgetsRecordProvider
}, "coververtical")), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "text-note",
visible: true,
_idProps: {
service: idService,
uuid: "108"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Set to \"fliphorizontal\", \"crossdissolve\" or \"coververtical\" to set the transition style")), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "OSAutoMarginTop",
visible: true,
_idProps: {
service: idService,
uuid: "109"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Label, {
gridProperties: {
classes: "OSFillParent"
},
_idProps: {
service: idService,
uuid: "110"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Toolbar position"), React.createElement(OSWidgets.ButtonGroup, {
_validationProps: {
validationService: validationService,
validationParentId: idService.getId("Form3")
},
enabled: true,
mandatory: false,
style: "button-group",
variable: model.createVariable(OS.Types.Text, model.variables.parametersVar.optionsAttr.iosAttr.toolbarpositionAttr, function (value) {
model.variables.parametersVar.optionsAttr.iosAttr.toolbarpositionAttr = value;
}),
_idProps: {
service: idService,
name: "ButtonGroup3"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.ButtonGroupItem, {
enabled: true,
style: "button-group-item",
value: "top",
visible: true,
_idProps: {
service: idService,
name: "ButtonGroupItem7"
},
_widgetRecordProvider: widgetsRecordProvider
}, "top"), React.createElement(OSWidgets.ButtonGroupItem, {
enabled: true,
style: "button-group-item",
value: "bottom",
visible: true,
_idProps: {
service: idService,
name: "ButtonGroupItem8"
},
_widgetRecordProvider: widgetsRecordProvider
}, "bottom")), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "text-note",
visible: true,
_idProps: {
service: idService,
uuid: "114"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Set to \"top\" or \"bottom\". Causes the toolbar to be at the top or bottom of the window.")))];
})];
})
},
_dependencies: [asPrimitiveValue(model.variables.successVar), asPrimitiveValue(model.variables.parametersVar.optionsAttr.iosAttr.toolbarpositionAttr), asPrimitiveValue(model.variables.parametersVar.optionsAttr.iosAttr.transitionstyleAttr), asPrimitiveValue(model.variables.parametersVar.optionsAttr.iosAttr.presentationstyleAttr), asPrimitiveValue(model.variables.parametersVar.optionsAttr.iosAttr.suppressesIncrementalRenderingAttr), asPrimitiveValue(model.variables.parametersVar.optionsAttr.iosAttr.keyboardDisplayRequiresUserActionAttr), asPrimitiveValue(model.variables.parametersVar.optionsAttr.iosAttr.allowInlineMediaPlaybackAttr), asPrimitiveValue(model.variables.parametersVar.optionsAttr.iosAttr.enableViewportScaleAttr), asPrimitiveValue(model.variables.parametersVar.optionsAttr.iosAttr.toolbarAttr), asPrimitiveValue(model.variables.parametersVar.optionsAttr.androidAttr.shouldPauseOnSuspendAttr), asPrimitiveValue(model.variables.parametersVar.optionsAttr.androidAttr.hardwarebackAttr), asPrimitiveValue(model.variables.parametersVar.optionsAttr.androidAttr.zoomAttr), asPrimitiveValue(model.variables.operatingSystemsIdVar)]
}), $if(model.variables.isExecutedOneCallVar, false, this, function () {
return [React.createElement(OutSystemsUI_Utilities_MarginContainer_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "115",
alias: "11"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
marginContainer: new PlaceholderContent(function () {
return [$if(model.variables.successVar, false, this, function () {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
extendedProperties: {
"data-test-id": "Success-message"
},
style: "card card-content text-white background-green",
visible: true,
_idProps: {
service: idService,
uuid: "116"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
gridProperties: {
classes: "ThemeGrid_Width10"
},
visible: true,
_idProps: {
service: idService,
uuid: "117"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Browser successfully open."), React.createElement(OSWidgets.Container, {
align: /*Right*/ 3,
animate: false,
extendedEvents: {
onClick: function () {
var eventHandlerContext = callContext.clone();
controller.dismissOnClick$Action(controller.callContext(eventHandlerContext));

;
}
},
gridProperties: {
classes: "ThemeGrid_Width2 ThemeGrid_MarginGutter"
},
visible: true,
_idProps: {
service: idService,
uuid: "118"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Icon, {
icon: "remove",
iconSize: /*FontSize*/ 0,
style: "icon text-white",
visible: true,
_idProps: {
service: idService,
uuid: "119"
},
_widgetRecordProvider: widgetsRecordProvider
})))];
}, function () {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
extendedProperties: {
"data-test-id": "Failure-message"
},
style: "card card-content text-white background-red",
visible: true,
_idProps: {
service: idService,
uuid: "120"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
gridProperties: {
classes: "ThemeGrid_Width10"
},
visible: true,
_idProps: {
service: idService,
uuid: "121"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Failed to open browser."), React.createElement(OSWidgets.Container, {
align: /*Right*/ 3,
animate: false,
extendedEvents: {
onClick: function () {
var eventHandlerContext = callContext.clone();
controller.dismissOnClick$Action(controller.callContext(eventHandlerContext));

;
}
},
gridProperties: {
classes: "ThemeGrid_Width2 ThemeGrid_MarginGutter"
},
visible: true,
_idProps: {
service: idService,
uuid: "122"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Icon, {
icon: "remove",
iconSize: /*FontSize*/ 0,
style: "icon text-white",
visible: true,
_idProps: {
service: idService,
uuid: "123"
},
_widgetRecordProvider: widgetsRecordProvider
})), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "124"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Error code: ", React.createElement(OSWidgets.Expression, {
gridProperties: {
classes: "ThemeGrid_MarginGutter"
},
value: model.variables.errorVar.errorCodeAttr,
_idProps: {
service: idService,
uuid: "125"
},
_widgetRecordProvider: widgetsRecordProvider
})), React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
visible: true,
_idProps: {
service: idService,
uuid: "126"
},
_widgetRecordProvider: widgetsRecordProvider
}, "Message: ", React.createElement(OSWidgets.Expression, {
gridProperties: {
classes: "ThemeGrid_MarginGutter"
},
value: model.variables.errorVar.errorMessageAttr,
_idProps: {
service: idService,
uuid: "127"
},
_widgetRecordProvider: widgetsRecordProvider
})))];
})];
})
},
_dependencies: [asPrimitiveValue(model.variables.errorVar.errorMessageAttr), asPrimitiveValue(model.variables.errorVar.errorCodeAttr), asPrimitiveValue(model.variables.successVar)]
})];
}, function () {
return [];
})];
}, function () {
return [React.createElement(OutSystemsUI_Utilities_MarginContainer_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "128",
alias: "12"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
marginContainer: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "card card-content background-red text-white",
visible: true,
_idProps: {
service: idService,
uuid: "129"
},
_widgetRecordProvider: widgetsRecordProvider
}, "The plugin is not loaded.", React.DOM.br(), " ", "Error code: ", React.createElement(OSWidgets.Expression, {
gridProperties: {
classes: "ThemeGrid_MarginGutter"
},
value: model.variables.errorVar.errorCodeAttr,
_idProps: {
service: idService,
uuid: "130"
},
_widgetRecordProvider: widgetsRecordProvider
}), React.DOM.br(), "Message: ", React.createElement(OSWidgets.Expression, {
gridProperties: {
classes: "ThemeGrid_MarginGutter"
},
value: model.variables.errorVar.errorMessageAttr,
_idProps: {
service: idService,
uuid: "131"
},
_widgetRecordProvider: widgetsRecordProvider
}))];
})
},
_dependencies: [asPrimitiveValue(model.variables.errorVar.errorMessageAttr), asPrimitiveValue(model.variables.errorVar.errorCodeAttr)]
})];
})];
}, function () {
return [React.createElement(OutSystemsUI_Utilities_MarginContainer_mvc_view, {
inputs: {},
events: {
_handleError: function (ex) {
controller.handleError(ex);
}
},
_validationProps: {
validationService: validationService
},
_idProps: {
service: idService,
uuid: "132",
alias: "13"
},
_widgetRecordProvider: widgetsRecordProvider,
placeholders: {
marginContainer: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Container, {
align: /*Default*/ 0,
animate: false,
style: "card card-content background-red text-white",
visible: true,
_idProps: {
service: idService,
uuid: "133"
},
_widgetRecordProvider: widgetsRecordProvider
}, "The operating systems that you are using is not supported (", React.createElement(OSWidgets.Expression, {
gridProperties: {
marginLeft: "0"
},
value: model.variables.operatingSystemsIdVar,
_idProps: {
service: idService,
uuid: "134"
},
_widgetRecordProvider: widgetsRecordProvider
}), ").")];
})
},
_dependencies: [asPrimitiveValue(model.variables.operatingSystemsIdVar)]
})];
})];
}),
bottom: new PlaceholderContent(function () {
return [React.createElement(OSWidgets.Button, {
enabled: (model.variables.isCorrectOSVar && model.variables.isPluginLoadedVar),
gridProperties: {
classes: "OSFillParent"
},
isDefault: false,
onClick: function () {
var eventHandlerContext = callContext.clone();
controller.openOnClick$Action(controller.callContext(eventHandlerContext));

;
},
style: "btn btn-primary",
visible: true,
_idProps: {
service: idService,
name: "OpenBrowserBtn"
},
_widgetRecordProvider: widgetsRecordProvider
}, React.createElement(OSWidgets.Text, {
style: "btn-fullwidth",
text: ["Open In App Browser"],
_idProps: {
service: idService,
uuid: "136"
},
_widgetRecordProvider: widgetsRecordProvider
}))];
})
},
_dependencies: [asPrimitiveValue(model.variables.errorVar.errorMessageAttr), asPrimitiveValue(model.variables.errorVar.errorCodeAttr), asPrimitiveValue(model.variables.isExecutedOneCallVar), asPrimitiveValue(model.variables.successVar), asPrimitiveValue(model.variables.operatingSystemsIdVar), asPrimitiveValue(model.variables.parametersVar.optionsAttr.androidAttr.shouldPauseOnSuspendAttr), asPrimitiveValue(model.variables.parametersVar.optionsAttr.androidAttr.hardwarebackAttr), asPrimitiveValue(model.variables.parametersVar.optionsAttr.androidAttr.zoomAttr), asPrimitiveValue(model.variables.parametersVar.optionsAttr.iosAttr.toolbarpositionAttr), asPrimitiveValue(model.variables.parametersVar.optionsAttr.iosAttr.transitionstyleAttr), asPrimitiveValue(model.variables.parametersVar.optionsAttr.iosAttr.presentationstyleAttr), asPrimitiveValue(model.variables.parametersVar.optionsAttr.iosAttr.suppressesIncrementalRenderingAttr), asPrimitiveValue(model.variables.parametersVar.optionsAttr.iosAttr.keyboardDisplayRequiresUserActionAttr), asPrimitiveValue(model.variables.parametersVar.optionsAttr.iosAttr.allowInlineMediaPlaybackAttr), asPrimitiveValue(model.variables.parametersVar.optionsAttr.iosAttr.enableViewportScaleAttr), asPrimitiveValue(model.variables.parametersVar.optionsAttr.iosAttr.toolbarAttr), asPrimitiveValue(model.variables.parametersVar.optionsAttr.iosAttr.closebuttoncaptionAttr), asPrimitiveValue(model.variables.parametersVar.optionsAttr.mediaPlaybackRequiresUserActionAttr), asPrimitiveValue(model.variables.parametersVar.optionsAttr.clearsessioncacheAttr), asPrimitiveValue(model.variables.parametersVar.optionsAttr.clearcacheAttr), asPrimitiveValue(model.variables.parametersVar.optionsAttr.locationAttr), asPrimitiveValue(model.variables.parametersVar.targetIdAttr), asPrimitiveValue(model.variables.parametersVar.uRLAttr), asPrimitiveValue(model.variables.isPluginLoadedVar), asPrimitiveValue(model.variables.isCorrectOSVar)]
}));
        };
        return View;
    })(OSView.BaseView.BaseWebScreen);
	
    return View;
});
define("InAppBrowserSampleApp.InAppBrowserFlow.InAppBrowser.mvc$controller", ["OutSystems/ClientRuntime/Main", "InAppBrowserSampleApp.model", "InAppBrowserSampleApp.controller", "InAppBrowserPlugin.model", "CommonPlugin.model", "InAppBrowserPlugin.controller", "CommonPlugin.controller", "InAppBrowserSampleApp.languageResources", "InAppBrowserSampleApp.InAppBrowserFlow.controller", "InAppBrowserPlugin.model$OptionsRec", "InAppBrowserSampleApp.referencesHealth", "InAppBrowserSampleApp.referencesHealth$InAppBrowserPlugin", "CommonPlugin.model$ErrorRec", "InAppBrowserSampleApp.referencesHealth$CommonPlugin", "InAppBrowserPlugin.controller$Open", "CommonPlugin.controller$GetOperatingSystem", "InAppBrowserPlugin.controller$CheckInAppBrowserPlugin", "InAppBrowserSampleApp.model$InAppBrowserParametersRec"], function (OutSystems, InAppBrowserSampleAppModel, InAppBrowserSampleAppController, InAppBrowserPluginModel, CommonPluginModel, InAppBrowserPluginController, CommonPluginController, InAppBrowserSampleAppLanguageResources, InAppBrowserSampleApp_InAppBrowserFlowController) {
var OS = OutSystems.Internal;
var Controller = (function (_super) {
__extends(Controller, _super);
function Controller() {
_super.apply(this, arguments);
var controller = this.controller;
this.clientActionProxies = {};
this.dataFetchDependenciesOriginal = {};
this.dataFetchDependentsGraph = {};
this.useImprovedDataFetch = false;
this.hasDependenciesBetweenSources = false;
this.shouldSendClientVarsToDataSources = false;
}
// Server Actions

// Aggregates and Data Actions

Controller.prototype.dataFetchActionNames = [];
// Client Actions
Controller.prototype._emptyOnClick$Action = function (callContext) {
var model = this.model;
var controller = this.controller;
var idService = this.idService;
controller.ensureControllerAlive("EmptyOnClick");
callContext = controller.callContext(callContext);
// Parameters.Options.Ios.Closebuttoncaption = ""
model.variables.parametersVar.optionsAttr.iosAttr.closebuttoncaptionAttr = "";
};
Controller.prototype._numbersOnClick$Action = function (callContext) {
var model = this.model;
var controller = this.controller;
var idService = this.idService;
controller.ensureControllerAlive("NumbersOnClick");
callContext = controller.callContext(callContext);
// Parameters.Options.Ios.Closebuttoncaption = "0123456789"
model.variables.parametersVar.optionsAttr.iosAttr.closebuttoncaptionAttr = "0123456789";
};
Controller.prototype._openOnClick$Action = function (callContext) {
var model = this.model;
var controller = this.controller;
var idService = this.idService;
controller.ensureControllerAlive("OpenOnClick");
callContext = controller.callContext(callContext);
var openVar = new OS.DataTypes.VariableHolder();
// Execute Action: Open
openVar.value = InAppBrowserPluginController.default.open$Action(model.variables.parametersVar.uRLAttr, model.variables.parametersVar.targetIdAttr, model.variables.parametersVar.optionsAttr, callContext);

// Set Output
// Success = Open.Success
model.variables.successVar = openVar.value.successOut;
// Error = Open.Error
model.variables.errorVar = openVar.value.errorOut;
// IsExecutedOneCall = True
model.variables.isExecutedOneCallVar = true;
};
Controller.prototype._dismissOnClick$Action = function (callContext) {
var model = this.model;
var controller = this.controller;
var idService = this.idService;
controller.ensureControllerAlive("DismissOnClick");
callContext = controller.callContext(callContext);
// IsExecutedOneCall = False
model.variables.isExecutedOneCallVar = false;
};
Controller.prototype._onInitialize$Action = function (callContext) {
var model = this.model;
var controller = this.controller;
var idService = this.idService;
controller.ensureControllerAlive("OnInitialize");
callContext = controller.callContext(callContext);
var getOperatingSystemVar = new OS.DataTypes.VariableHolder();
var checkInAppBrowserPluginVar = new OS.DataTypes.VariableHolder();
// Execute Action: GetOperatingSystem
getOperatingSystemVar.value = CommonPluginController.default.getOperatingSystem$Action(callContext);

// Execute Action: CheckInAppBrowserPlugin
checkInAppBrowserPluginVar.value = InAppBrowserPluginController.default.checkInAppBrowserPlugin$Action(callContext);

// OperatingSystemsId = GetOperatingSystem.OperatingSystemsId
model.variables.operatingSystemsIdVar = getOperatingSystemVar.value.operatingSystemsIdOut;
// Parameters.Options.Ios.Closebuttoncaption = "Oh yeah close!"
model.variables.parametersVar.optionsAttr.iosAttr.closebuttoncaptionAttr = "Oh yeah close!";
// IsCorrectOS = GetOperatingSystem.OperatingSystemsId = Android or GetOperatingSystem.OperatingSystemsId = iOS
model.variables.isCorrectOSVar = ((getOperatingSystemVar.value.operatingSystemsIdOut === InAppBrowserSampleAppModel.staticEntities.mobile_OperatingSystem.android) || (getOperatingSystemVar.value.operatingSystemsIdOut === InAppBrowserSampleAppModel.staticEntities.mobile_OperatingSystem.iOS));
// IsPluginLoaded
// IsPluginLoaded = CheckInAppBrowserPlugin.IsAvailable
model.variables.isPluginLoadedVar = checkInAppBrowserPluginVar.value.isAvailableOut;
// Error = CheckInAppBrowserPlugin.Error
model.variables.errorVar = checkInAppBrowserPluginVar.value.errorOut;
};
Controller.prototype._hTTPOnClick$Action = function (callContext) {
var model = this.model;
var controller = this.controller;
var idService = this.idService;
controller.ensureControllerAlive("HTTPOnClick");
callContext = controller.callContext(callContext);
// Parameters.URL = "http://cinemas.nos.pt/"
model.variables.parametersVar.uRLAttr = "http://cinemas.nos.pt/";
};
Controller.prototype._textOnClick$Action = function (callContext) {
var model = this.model;
var controller = this.controller;
var idService = this.idService;
controller.ensureControllerAlive("TextOnClick");
callContext = controller.callContext(callContext);
// Parameters.Options.Ios.Closebuttoncaption = "Oh yeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeah close!"
model.variables.parametersVar.optionsAttr.iosAttr.closebuttoncaptionAttr = "Oh yeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeah close!";
};
Controller.prototype._wrongURLOnClick$Action = function (callContext) {
var model = this.model;
var controller = this.controller;
var idService = this.idService;
controller.ensureControllerAlive("WrongURLOnClick");
callContext = controller.callContext(callContext);
// Parameters.URL = "h2ttps://www.outsystems.com/"
model.variables.parametersVar.uRLAttr = "h2ttps://www.outsystems.com/";
};
Controller.prototype._relativeURLOnClick$Action = function (callContext) {
var model = this.model;
var controller = this.controller;
var idService = this.idService;
controller.ensureControllerAlive("RelativeURLOnClick");
callContext = controller.callContext(callContext);
// Parameters.URL = "/MyAwesomeApp/HomeScreen"
model.variables.parametersVar.uRLAttr = "/MyAwesomeApp/HomeScreen";
};
Controller.prototype._enMobileopenOnClick$Action = function (callContext) {
var model = this.model;
var controller = this.controller;
var idService = this.idService;
controller.ensureControllerAlive("EnMobileopenOnClick");
callContext = controller.callContext(callContext);
// Parameters.URL = "https://enmobile-tst.outsystemsenterprise.com/ContactsSampleApp/Add"
model.variables.parametersVar.uRLAttr = "https://enmobile-tst.outsystemsenterprise.com/ContactsSampleApp/Add";
};
Controller.prototype._uRLStrangeOnClick$Action = function (callContext) {
var model = this.model;
var controller = this.controller;
var idService = this.idService;
controller.ensureControllerAlive("URLStrangeOnClick");
callContext = controller.callContext(callContext);
// Parameters.URL = "https://www.google.com/search?q=mobile+team&rlz=1C1GCEA_enPT816PT816&oq=mobile+team&aqs=chrome..69i57j0l2j69i61j69i60j69i61.2333j0j4&sourceid=chrome&ie=UTF-8"
model.variables.parametersVar.uRLAttr = "https://www.google.com/search?q=mobile+team&rlz=1C1GCEA_enPT816PT816&oq=mobile+team&aqs=chrome..69i57j0l2j69i61j69i60j69i61.2333j0j4&sourceid=chrome&ie=UTF-8";
};
Controller.prototype._enMobiledownl_OnClick$Action = function (callContext) {
var model = this.model;
var controller = this.controller;
var idService = this.idService;
controller.ensureControllerAlive("EnMobiledownl_OnClick");
callContext = controller.callContext(callContext);
// Parameters.URL = "https://enmobile-dev.outsystemsenterprise.com/NativeAppBuilder/App?Name=SSL+Pinning+Sample+App+2&AppKey=d63b952c-67d4-4661-92bf-be8c67bbcac2"
model.variables.parametersVar.uRLAttr = "https://enmobile-dev.outsystemsenterprise.com/NativeAppBuilder/App?Name=SSL+Pinning+Sample+App+2&AppKey=d63b952c-67d4-4661-92bf-be8c67bbcac2";
};
Controller.prototype._uRLwithpdfOnClick$Action = function (callContext) {
var model = this.model;
var controller = this.controller;
var idService = this.idService;
controller.ensureControllerAlive("URLwithpdfOnClick");
callContext = controller.callContext(callContext);
// Parameters.URL = "http://www.carris.pt/fotos/produtos/e012_1_102018.pdf"
model.variables.parametersVar.uRLAttr = "http://www.carris.pt/fotos/produtos/e012_1_102018.pdf";
};
Controller.prototype._symbolsOnClick$Action = function (callContext) {
var model = this.model;
var controller = this.controller;
var idService = this.idService;
controller.ensureControllerAlive("SymbolsOnClick");
callContext = controller.callContext(callContext);
// Parameters.Options.Ios.Closebuttoncaption = "#$%&/()+'+~º"
model.variables.parametersVar.optionsAttr.iosAttr.closebuttoncaptionAttr = "#$%&/()+\'+~º";
};
Controller.prototype._imdbTrailerOnClick$Action = function (callContext) {
var model = this.model;
var controller = this.controller;
var idService = this.idService;
controller.ensureControllerAlive("ImdbTrailerOnClick");
callContext = controller.callContext(callContext);
// Parameters.URL = "https://www.imdb.com/title/tt7286456/videoplayer/vi1723318041?ref_=tt_ov_vi"
model.variables.parametersVar.uRLAttr = "https://www.imdb.com/title/tt7286456/videoplayer/vi1723318041?ref_=tt_ov_vi";
};

Controller.prototype.emptyOnClick$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._emptyOnClick$Action, callContext);

};
Controller.prototype.numbersOnClick$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._numbersOnClick$Action, callContext);

};
Controller.prototype.openOnClick$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._openOnClick$Action, callContext);

};
Controller.prototype.dismissOnClick$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._dismissOnClick$Action, callContext);

};
Controller.prototype.onInitialize$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._onInitialize$Action, callContext);

};
Controller.prototype.hTTPOnClick$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._hTTPOnClick$Action, callContext);

};
Controller.prototype.textOnClick$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._textOnClick$Action, callContext);

};
Controller.prototype.wrongURLOnClick$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._wrongURLOnClick$Action, callContext);

};
Controller.prototype.relativeURLOnClick$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._relativeURLOnClick$Action, callContext);

};
Controller.prototype.enMobileopenOnClick$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._enMobileopenOnClick$Action, callContext);

};
Controller.prototype.uRLStrangeOnClick$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._uRLStrangeOnClick$Action, callContext);

};
Controller.prototype.enMobiledownl_OnClick$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._enMobiledownl_OnClick$Action, callContext);

};
Controller.prototype.uRLwithpdfOnClick$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._uRLwithpdfOnClick$Action, callContext);

};
Controller.prototype.symbolsOnClick$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._symbolsOnClick$Action, callContext);

};
Controller.prototype.imdbTrailerOnClick$Action = function (callContext) {
var controller = this.controller;
return controller.safeExecuteClientAction(controller._imdbTrailerOnClick$Action, callContext);

};

// Event Handler Actions
Controller.prototype.onInitializeEventHandler = function (callContext) {
var controller = this.controller;
var model = this.model;
var idService = this.idService;

return controller.onInitialize$Action(callContext);

};
Controller.prototype.onReadyEventHandler = null;
Controller.prototype.onRenderEventHandler = null;
Controller.prototype.onDestroyEventHandler = null;
Controller.prototype.onParametersChangedEventHandler = null;
Controller.prototype.handleError = function (ex) {
return InAppBrowserSampleApp_InAppBrowserFlowController.default.handleError(ex, this.callContext());
};
Controller.checkPermissions = function () {
};
Controller.prototype.getDefaultTimeout = function () {
return InAppBrowserSampleAppController.default.defaultTimeout;
};
return Controller;
})(OS.Controller.BaseViewController);
return new OS.Controller.ControllerFactory(Controller, InAppBrowserSampleAppLanguageResources);
});

