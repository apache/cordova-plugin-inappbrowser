﻿define("OutSystemsUI.referencesHealth$ServiceCenter", [], function () {
// Reference to producer 'ServiceCenter' is OK.
});
define("OutSystemsUI.referencesHealth$Users", [], function () {
// Reference to producer 'Users' is OK.
});
define("OutSystemsUI.referencesHealth", [], function () {
});
