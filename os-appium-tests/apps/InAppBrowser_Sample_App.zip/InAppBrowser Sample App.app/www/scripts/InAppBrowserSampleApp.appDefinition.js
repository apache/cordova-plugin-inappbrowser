﻿define("InAppBrowserSampleApp.appDefinition", ["OutSystems/ClientRuntime/Main"], function (OutSystems) {
var OS = OutSystems.Internal;
return {
environmentKey: "dc001285-6c44-4292-b212-9ef4240cf6e9",
environmentName: "Development",
applicationKey: "5567e45b-146d-41e9-bdf1-b2f0102cf0ea",
applicationName: "InAppBrowser Sample App",
userProviderName: "Users",
debugEnabled: false,
homeModuleName: "InAppBrowserSampleApp",
homeModuleKey: "67dab9a1-c6e7-44f2-8cdf-ce2e51c431b0",
homeModuleControllerName: "InAppBrowserSampleApp.controller",
homeModuleLanguageResourcesName: "InAppBrowserSampleApp.languageResources",
defaultTransition: "SlideFromRight",
errorPageConfig: {
showExceptionStack: false,
messages: {
defaultMessage: null,
screenNotFound: null,
noDefaultScreen: null,
appOffline: null,
incompatibleProducer: null
},
extraMessage: null,
reloadLabel: null
},
isWeb: false
};
});
