﻿define("InAppBrowserSampleApp.InAppBrowserFlow.controller", ["exports", "OutSystems/ClientRuntime/Main", "InAppBrowserSampleApp.model", "InAppBrowserSampleApp.controller", "InAppBrowserSampleApp.Common.controller"], function (exports, OutSystems, InAppBrowserSampleAppModel, InAppBrowserSampleAppController, InAppBrowserSampleApp_CommonController) {
var OS = OutSystems.Internal;
var InAppBrowserSampleApp_InAppBrowserFlowController = exports;
var Controller = (function (_super) {
__extends(Controller, _super);
function Controller() {
_super.apply(this, arguments);
}
Controller.prototype.getDefaultTimeout = function () {
return InAppBrowserSampleAppController.default.defaultTimeout;
};
Controller.prototype.handleError = function (ex, callContext) {
var controller = this.controller;
OS.Logger.trace("InAppBrowserFlow", OS.Exceptions.getMessage(ex), ex.name);
return InAppBrowserSampleApp_CommonController.default.handleError(ex, callContext);


};
return Controller;
})(OS.Controller.BaseController);
InAppBrowserSampleApp_InAppBrowserFlowController.default = new Controller();
});

