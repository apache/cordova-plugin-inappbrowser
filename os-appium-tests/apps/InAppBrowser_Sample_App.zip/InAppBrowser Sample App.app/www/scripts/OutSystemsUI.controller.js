﻿define("OutSystemsUI.controller$ApplicationStartWeb", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.controller", "OutSystemsUI.controller$ApplicationStartWeb.CloseMenuOnBodyClickJS", "OutSystemsUI.controller$ECTCall", "OutSystemsUI.controller$DeviceDetection"], function (exports, OutSystems, OutSystemsUIModel, OutSystemsUIController, OutSystemsUI_controller_ApplicationStartWeb_CloseMenuOnBodyClickJS) {
var OS = OutSystems.Internal;
OutSystemsUIController.default.applicationStartWeb$Action = function (callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:jJX7lo_r90KIF783js3cCg:/ClientActionFlows.jJX7lo_r90KIF783js3cCg:cWiNITbKdu31yk1vcyEuvg", "OutSystemsUI", "ApplicationStartWeb", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:FX1i8WzSbEujuTXpQjTJbg", callContext.id);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:kRwKX9EUQUGxLfu93+aKEg", callContext.id);
controller.safeExecuteJSNode(OutSystemsUI_controller_ApplicationStartWeb_CloseMenuOnBodyClickJS, "CloseMenuOnBodyClick", "ApplicationStartWeb", null, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:JB9lnj6A70CiCJSCz7DZNw", callContext.id);
// Execute Action: DeviceDetection
OutSystemsUIController.default.deviceDetection$Action(callContext);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:27DXN7PUNEyRrff6YisdTA", callContext.id);
// Execute Action: ECTCall
OutSystemsUIController.default.eCTCall$Action(callContext);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:p6liRmoEVkiFPvV3m7oVBw", callContext.id);
return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:jJX7lo_r90KIF783js3cCg", callContext.id);
}

};
var controller = OutSystemsUIController.default;
OutSystemsUIController.default.clientActionProxies.applicationStartWeb$Action = function () {
return controller.executeActionInsideJSNode(OutSystemsUIController.default.applicationStartWeb$Action.bind(controller), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("OutSystemsUI.controller$ApplicationStartWeb.CloseMenuOnBodyClickJS", [], function () {
return function ($actions, $roles, $public) {
var isDesktop = document.body.classList.contains('desktop');

var closeOnBodyClick = function() {
    var menu = document.querySelector('.app-menu-links');
    
    if(menu) {
        var subItems = menu.querySelectorAll('.submenu');
        
        if(subItems.length > 0) {
            for(var i = 0; i < subItems.length; i++) {
                if(subItems[i].classList.contains('open')) {
                    subItems[i].CloseMenu();
                } 
            }
        }    
    }
};

// If is Desktop, add eventListener on Body, to close Menu on click
if(isDesktop) {
   document.body.addEventListener('click', closeOnBodyClick);
}








};
});

define("OutSystemsUI.controller$CarouselDisableSwipe", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.controller", "OutSystemsUI.controller$CarouselDisableSwipe.AddClassNoSwipeJS"], function (exports, OutSystems, OutSystemsUIModel, OutSystemsUIController, OutSystemsUI_controller_CarouselDisableSwipe_AddClassNoSwipeJS) {
var OS = OutSystems.Internal;
OutSystemsUIController.default.carouselDisableSwipe$Action = function (carouselIDIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsUI.CarouselDisableSwipe$vars"))());
vars.value.carouselIDInLocal = carouselIDIn;
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:SAFhfi45BU6VeqYFazfRRg:/ClientActionFlows.SAFhfi45BU6VeqYFazfRRg:D15QJoDg7Ut5_m57hWVGeQ", "OutSystemsUI", "CarouselDisableSwipe", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:X0580Gn280imj6vUP3PEwA", callContext.id);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:EA76gLu_y0WEapiQoFodxg", callContext.id);
controller.safeExecuteJSNode(OutSystemsUI_controller_CarouselDisableSwipe_AddClassNoSwipeJS, "AddClassNoSwipe", "CarouselDisableSwipe", {
CarouselID: OS.DataConversion.JSNodeParamConverter.to(vars.value.carouselIDInLocal, OS.Types.Text)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:PqihoXYUMkKbUMgD_UvU5w", callContext.id);
return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:SAFhfi45BU6VeqYFazfRRg", callContext.id);
}

};
var controller = OutSystemsUIController.default;
OutSystemsUIController.default.constructor.registerVariableGroupType("OutSystemsUI.CarouselDisableSwipe$vars", [{
name: "CarouselID",
attrName: "carouselIDInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
OutSystemsUIController.default.clientActionProxies.carouselDisableSwipe$Action = function (carouselIDIn) {
carouselIDIn = (carouselIDIn === undefined) ? "" : carouselIDIn;
return controller.executeActionInsideJSNode(OutSystemsUIController.default.carouselDisableSwipe$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(carouselIDIn, OS.Types.Text)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("OutSystemsUI.controller$CarouselDisableSwipe.AddClassNoSwipeJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
var elem = document.getElementById($parameters.CarouselID).querySelector('.carousel');

if(elem) {
    elem.classList.add('no-swipe');
}
};
});

define("OutSystemsUI.controller$CarouselGoTo", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.controller", "OutSystemsUI.controller$CarouselGoTo.CallGoToActionJS"], function (exports, OutSystems, OutSystemsUIModel, OutSystemsUIController, OutSystemsUI_controller_CarouselGoTo_CallGoToActionJS) {
var OS = OutSystems.Internal;
OutSystemsUIController.default.carouselGoTo$Action = function (widgetIdIn, targetIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsUI.CarouselGoTo$vars"))());
vars.value.widgetIdInLocal = widgetIdIn;
vars.value.targetInLocal = targetIn;
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:Z5AAPK6NwEC74YLVRyAFLQ:/ClientActionFlows.Z5AAPK6NwEC74YLVRyAFLQ:ds3GnwE3FNruQba8+tCuyg", "OutSystemsUI", "CarouselGoTo", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:g8Q4KSOw+kesTnGRUDg74Q", callContext.id);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:dBRtEJ1oXUeFmuSC_CWu9Q", callContext.id);
controller.safeExecuteJSNode(OutSystemsUI_controller_CarouselGoTo_CallGoToActionJS, "CallGoToAction", "CarouselGoTo", {
Target: OS.DataConversion.JSNodeParamConverter.to(vars.value.targetInLocal, OS.Types.Integer),
WidgetId: OS.DataConversion.JSNodeParamConverter.to(vars.value.widgetIdInLocal, OS.Types.Text)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:mDXwbVp8BE+5mlkO+9_7nQ", callContext.id);
return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:Z5AAPK6NwEC74YLVRyAFLQ", callContext.id);
}

};
var controller = OutSystemsUIController.default;
OutSystemsUIController.default.constructor.registerVariableGroupType("OutSystemsUI.CarouselGoTo$vars", [{
name: "WidgetId",
attrName: "widgetIdInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}, {
name: "Target",
attrName: "targetInLocal",
mandatory: true,
dataType: OS.Types.Integer,
defaultValue: function () {
return 0;
}
}]);
OutSystemsUIController.default.clientActionProxies.carouselGoTo$Action = function (widgetIdIn, targetIn) {
widgetIdIn = (widgetIdIn === undefined) ? "" : widgetIdIn;
targetIn = (targetIn === undefined) ? 0 : targetIn;
return controller.executeActionInsideJSNode(OutSystemsUIController.default.carouselGoTo$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(widgetIdIn, OS.Types.Text), OS.DataConversion.JSNodeParamConverter.from(targetIn, OS.Types.Integer)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("OutSystemsUI.controller$CarouselGoTo.CallGoToActionJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
var element = document.getElementById($parameters.WidgetId).querySelector('.carousel-container-content').goto($parameters.Target);
};
});

define("OutSystemsUI.controller$CarouselNext", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.controller", "OutSystemsUI.controller$CarouselNext.CallNextActionJS"], function (exports, OutSystems, OutSystemsUIModel, OutSystemsUIController, OutSystemsUI_controller_CarouselNext_CallNextActionJS) {
var OS = OutSystems.Internal;
OutSystemsUIController.default.carouselNext$Action = function (widgetIdIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsUI.CarouselNext$vars"))());
vars.value.widgetIdInLocal = widgetIdIn;
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:s3o2xkm11kWBC1DM24ANFA:/ClientActionFlows.s3o2xkm11kWBC1DM24ANFA:obnOVxD1pPGIqXcCHeNqaw", "OutSystemsUI", "CarouselNext", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:UlUeFYUFyk6CQLCV7HGwwg", callContext.id);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:53BVu_67OUOpcv5eedIWzw", callContext.id);
controller.safeExecuteJSNode(OutSystemsUI_controller_CarouselNext_CallNextActionJS, "CallNextAction", "CarouselNext", {
WidgetId: OS.DataConversion.JSNodeParamConverter.to(vars.value.widgetIdInLocal, OS.Types.Text)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:CfcmfBv7PE6zw+XQkz6LhQ", callContext.id);
return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:s3o2xkm11kWBC1DM24ANFA", callContext.id);
}

};
var controller = OutSystemsUIController.default;
OutSystemsUIController.default.constructor.registerVariableGroupType("OutSystemsUI.CarouselNext$vars", [{
name: "WidgetId",
attrName: "widgetIdInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
OutSystemsUIController.default.clientActionProxies.carouselNext$Action = function (widgetIdIn) {
widgetIdIn = (widgetIdIn === undefined) ? "" : widgetIdIn;
return controller.executeActionInsideJSNode(OutSystemsUIController.default.carouselNext$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(widgetIdIn, OS.Types.Text)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("OutSystemsUI.controller$CarouselNext.CallNextActionJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
var element = document.getElementById($parameters.WidgetId).querySelector('.carousel-container-content').next();
};
});

define("OutSystemsUI.controller$CarouselPrevious", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.controller", "OutSystemsUI.controller$CarouselPrevious.CallPreviousActionJS"], function (exports, OutSystems, OutSystemsUIModel, OutSystemsUIController, OutSystemsUI_controller_CarouselPrevious_CallPreviousActionJS) {
var OS = OutSystems.Internal;
OutSystemsUIController.default.carouselPrevious$Action = function (widgetIdIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsUI.CarouselPrevious$vars"))());
vars.value.widgetIdInLocal = widgetIdIn;
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:CffDzLB_b06BcWvnmqj02w:/ClientActionFlows.CffDzLB_b06BcWvnmqj02w:6kTaYVQbAnN25tYYrs2kDw", "OutSystemsUI", "CarouselPrevious", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:iABzbqhH5EG01r7OLD2N+g", callContext.id);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:mfJ8xdFCcEm0t1Gi9snU+Q", callContext.id);
controller.safeExecuteJSNode(OutSystemsUI_controller_CarouselPrevious_CallPreviousActionJS, "CallPreviousAction", "CarouselPrevious", {
IdCarousel: OS.DataConversion.JSNodeParamConverter.to(vars.value.widgetIdInLocal, OS.Types.Text)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:nFHHZdm9Fkmgy91n4K5uSA", callContext.id);
return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:CffDzLB_b06BcWvnmqj02w", callContext.id);
}

};
var controller = OutSystemsUIController.default;
OutSystemsUIController.default.constructor.registerVariableGroupType("OutSystemsUI.CarouselPrevious$vars", [{
name: "WidgetId",
attrName: "widgetIdInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
OutSystemsUIController.default.clientActionProxies.carouselPrevious$Action = function (widgetIdIn) {
widgetIdIn = (widgetIdIn === undefined) ? "" : widgetIdIn;
return controller.executeActionInsideJSNode(OutSystemsUIController.default.carouselPrevious$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(widgetIdIn, OS.Types.Text)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("OutSystemsUI.controller$CarouselPrevious.CallPreviousActionJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
var element = document.getElementById($parameters.IdCarousel).querySelector('.carousel-container-content').previous();
};
});

define("OutSystemsUI.controller$CarouselUpdate", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.controller", "OutSystemsUI.controller$CarouselUpdate.CallUpdateActionJS"], function (exports, OutSystems, OutSystemsUIModel, OutSystemsUIController, OutSystemsUI_controller_CarouselUpdate_CallUpdateActionJS) {
var OS = OutSystems.Internal;
OutSystemsUIController.default.carouselUpdate$Action = function (widgetIdIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsUI.CarouselUpdate$vars"))());
vars.value.widgetIdInLocal = widgetIdIn;
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:Q9gj08KLHEKuYcqlD371lQ:/ClientActionFlows.Q9gj08KLHEKuYcqlD371lQ:o_8aYga1jD4AegVoLG7Fqg", "OutSystemsUI", "CarouselUpdate", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:FUpJO9Gw5US7hEcadm2mpQ", callContext.id);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:LrnR4YHuPEaFFAmbmSTz1Q", callContext.id);
controller.safeExecuteJSNode(OutSystemsUI_controller_CarouselUpdate_CallUpdateActionJS, "CallUpdateAction", "CarouselUpdate", {
WidgetId: OS.DataConversion.JSNodeParamConverter.to(vars.value.widgetIdInLocal, OS.Types.Text)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:PMNXmASQ7EWX0M3vuqW2uA", callContext.id);
return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:Q9gj08KLHEKuYcqlD371lQ", callContext.id);
}

};
var controller = OutSystemsUIController.default;
OutSystemsUIController.default.constructor.registerVariableGroupType("OutSystemsUI.CarouselUpdate$vars", [{
name: "WidgetId",
attrName: "widgetIdInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
OutSystemsUIController.default.clientActionProxies.carouselUpdate$Action = function (widgetIdIn) {
widgetIdIn = (widgetIdIn === undefined) ? "" : widgetIdIn;
return controller.executeActionInsideJSNode(OutSystemsUIController.default.carouselUpdate$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(widgetIdIn, OS.Types.Text)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("OutSystemsUI.controller$CarouselUpdate.CallUpdateActionJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
var element = document.getElementById($parameters.WidgetId).querySelector('.carousel-container-content').updateCarousel();
};
});

define("OutSystemsUI.controller$ConfigureOfflineDataSync", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.controller", "OutSystemsUI.controller$ConfigureOfflineDataSync.ConfigureOfflineDataSyncJS"], function (exports, OutSystems, OutSystemsUIModel, OutSystemsUIController, OutSystemsUI_controller_ConfigureOfflineDataSync_ConfigureOfflineDataSyncJS) {
var OS = OutSystems.Internal;
OutSystemsUIController.default.configureOfflineDataSync$Action = function (syncOnOnlineIn, syncOnResumeIn, retryOnErrorIn, retryIntervalInSecondsIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsUI.ConfigureOfflineDataSync$vars"))());
vars.value.syncOnOnlineInLocal = syncOnOnlineIn;
vars.value.syncOnResumeInLocal = syncOnResumeIn;
vars.value.retryOnErrorInLocal = retryOnErrorIn;
vars.value.retryIntervalInSecondsInLocal = retryIntervalInSecondsIn;
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:wlq1EEBDSk6XBVqBnqrN_w:/ClientActionFlows.wlq1EEBDSk6XBVqBnqrN_w:2cSasMUYyxMLULWUER6qdQ", "OutSystemsUI", "ConfigureOfflineDataSync", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:dDeqycVUN0SauMDQ4RwX3Q", callContext.id);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:Q3ziLgpmwEiLfbtrD1nU_A", callContext.id);
controller.safeExecuteJSNode(OutSystemsUI_controller_ConfigureOfflineDataSync_ConfigureOfflineDataSyncJS, "ConfigureOfflineDataSync", "ConfigureOfflineDataSync", {
SyncOnResume: OS.DataConversion.JSNodeParamConverter.to(vars.value.syncOnResumeInLocal, OS.Types.Boolean),
RetryIntervalInSeconds: OS.DataConversion.JSNodeParamConverter.to(vars.value.retryIntervalInSecondsInLocal, OS.Types.Integer),
SyncOnOnline: OS.DataConversion.JSNodeParamConverter.to(vars.value.syncOnOnlineInLocal, OS.Types.Boolean),
RetryOnError: OS.DataConversion.JSNodeParamConverter.to(vars.value.retryOnErrorInLocal, OS.Types.Boolean)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:cata8UPkrUmg_S6Y1sbHKw", callContext.id);
return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:wlq1EEBDSk6XBVqBnqrN_w", callContext.id);
}

};
var controller = OutSystemsUIController.default;
OutSystemsUIController.default.constructor.registerVariableGroupType("OutSystemsUI.ConfigureOfflineDataSync$vars", [{
name: "SyncOnOnline",
attrName: "syncOnOnlineInLocal",
mandatory: true,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}, {
name: "SyncOnResume",
attrName: "syncOnResumeInLocal",
mandatory: true,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}, {
name: "RetryOnError",
attrName: "retryOnErrorInLocal",
mandatory: true,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}, {
name: "RetryIntervalInSeconds",
attrName: "retryIntervalInSecondsInLocal",
mandatory: true,
dataType: OS.Types.Integer,
defaultValue: function () {
return 0;
}
}]);
OutSystemsUIController.default.clientActionProxies.configureOfflineDataSync$Action = function (syncOnOnlineIn, syncOnResumeIn, retryOnErrorIn, retryIntervalInSecondsIn) {
syncOnOnlineIn = (syncOnOnlineIn === undefined) ? false : syncOnOnlineIn;
syncOnResumeIn = (syncOnResumeIn === undefined) ? false : syncOnResumeIn;
retryOnErrorIn = (retryOnErrorIn === undefined) ? false : retryOnErrorIn;
retryIntervalInSecondsIn = (retryIntervalInSecondsIn === undefined) ? 0 : retryIntervalInSecondsIn;
return controller.executeActionInsideJSNode(OutSystemsUIController.default.configureOfflineDataSync$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(syncOnOnlineIn, OS.Types.Boolean), OS.DataConversion.JSNodeParamConverter.from(syncOnResumeIn, OS.Types.Boolean), OS.DataConversion.JSNodeParamConverter.from(retryOnErrorIn, OS.Types.Boolean), OS.DataConversion.JSNodeParamConverter.from(retryIntervalInSecondsIn, OS.Types.Integer)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("OutSystemsUI.controller$ConfigureOfflineDataSync.ConfigureOfflineDataSyncJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
window.offlineDataSync.configure(
    $parameters.SyncOnOnline,
    $parameters.SyncOnResume,
    $parameters.RetryOnError,
    $parameters.RetryIntervalInSeconds);

};
});

define("OutSystemsUI.controller$DeviceDetection", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.controller", "OutSystemsUI.controller$DeviceDetection.StatusBarOverlayJS", "OutSystemsUI.controller$DeviceDetection.AddClassesJS", "OutSystemsUI.controller$GetBrowser", "OutSystemsUI.controller$GetOS", "OutSystemsUI.controller$GetIsTouch"], function (exports, OutSystems, OutSystemsUIModel, OutSystemsUIController, OutSystemsUI_controller_DeviceDetection_StatusBarOverlayJS, OutSystemsUI_controller_DeviceDetection_AddClassesJS) {
var OS = OutSystems.Internal;
OutSystemsUIController.default.deviceDetection$Action = function (callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsUI.DeviceDetection$vars"))());
var getBrowserVar = new OS.DataTypes.VariableHolder();
var getOSVar = new OS.DataTypes.VariableHolder();
var getIsTouchVar = new OS.DataTypes.VariableHolder();
varBag.callContext = callContext;
varBag.vars = vars;
varBag.getBrowserVar = getBrowserVar;
varBag.getOSVar = getOSVar;
varBag.getIsTouchVar = getIsTouchVar;
try {OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:OOQHk+EK0UyAa1lqT_YN4w:/ClientActionFlows.OOQHk+EK0UyAa1lqT_YN4w:tGMyIxwuVYRnfqssN7bcng", "OutSystemsUI", "DeviceDetection", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:TteqoKGApkaHPTQdW6ZGzw", callContext.id);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:RWt+kXHuzUSxVy0cZJHDGw", callContext.id);
// If the device has a transparent status bar, applies default paddings to the required elements
controller.safeExecuteJSNode(OutSystemsUI_controller_DeviceDetection_StatusBarOverlayJS, "StatusBarOverlay", "DeviceDetection", null, function ($parameters) {
}, {}, {});
// Get User Agent
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:Wa2mzxPdA0a8e0hDqn4HSw", callContext.id);
// UserAgent = ToLower
vars.value.userAgentVar = OS.BuiltinFunctions.toLower(OS.BuiltinFunctions.getUserAgent());
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:802dRsv2ZkmMTp_gvSZjQg", callContext.id);
// Execute Action: GetBrowser
getBrowserVar.value = OutSystemsUIController.default.getBrowser$Action(vars.value.userAgentVar, callContext);

OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:SO6yYH8njUOWeZhQo6DNmQ", callContext.id);
// Execute Action: GetOS
getOSVar.value = OutSystemsUIController.default.getOS$Action(vars.value.userAgentVar, callContext);

OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:5WQ6+EOI20qlKf+sVTvE1A", callContext.id);
// Execute Action: GetIsTouch
getIsTouchVar.value = OutSystemsUIController.default.getIsTouch$Action(callContext);

OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:FDjUnNglU0GGZuMXhNjSKQ", callContext.id);
controller.safeExecuteJSNode(OutSystemsUI_controller_DeviceDetection_AddClassesJS, "AddClasses", "DeviceDetection", {
Browser: OS.DataConversion.JSNodeParamConverter.to(getBrowserVar.value.browserOut, OS.Types.Text),
IsTouch: OS.DataConversion.JSNodeParamConverter.to(getIsTouchVar.value.isTouchOut, OS.Types.Boolean),
OS: OS.DataConversion.JSNodeParamConverter.to(getOSVar.value.oSOut, OS.Types.Text)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:8RZidRamT0W1nSDxrR7HUQ", callContext.id);
return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:OOQHk+EK0UyAa1lqT_YN4w", callContext.id);
}

};
var controller = OutSystemsUIController.default;
OutSystemsUIController.default.constructor.registerVariableGroupType("OutSystemsUI.DeviceDetection$vars", [{
name: "UserAgent",
attrName: "userAgentVar",
mandatory: false,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
OutSystemsUIController.default.clientActionProxies.deviceDetection$Action = function () {
return controller.executeActionInsideJSNode(OutSystemsUIController.default.deviceDetection$Action.bind(controller), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("OutSystemsUI.controller$DeviceDetection.StatusBarOverlayJS", [], function () {
return function ($actions, $roles, $public) {
var body = document.querySelector('body');
var statusbarHeight = body.getAttribute('data-status-bar-height');

if(statusbarHeight > 0 ) {
    var header = document.querySelector('.header');
    var appMenu = document.querySelector('.app-menu');
    var notification = document.querySelector('.notification');
    var sidebar = document.querySelector('.sidebar');
    var splitRightClose = document.querySelector('.split-right-close');
    var topBarLightbox = document.querySelector('.pswp__top-bar');
    var headerRight = document.querySelector('.header-right .search-input');
    var loginScreen = document.querySelector('.login-screen');
    var splashScreen = document.querySelector('.splash-screen');
    
    if(header) {
        header.style.paddingTop = statusbarHeight + "px";    
    }
    
    if(appMenu) {
        appMenu.style.paddingTop = statusbarHeight + "px";    
    }
    
    if(notification) {
        notification.style.paddingTop = (parseInt(statusbarHeight) + 20) + "px";    
    }
    
    if(sidebar) {
        sidebar.style.paddingTop = statusbarHeight + "px";    
    }
                
    if(splitRightClose) {
        splitRightClose.style.top = (parseInt(statusbarHeight) + 6) + "px";  
    }
    
    if(topBarLightbox) {
        topBarLightbox.style.top = statusbarHeight + "px"; 
    }
    
    if(headerRight) {
        headerRight.style.paddingTop = (parseInt(statusbarHeight) + 5) + "px";     
    }
    
    if(loginScreen) {
        loginScreen.style.paddingTop = statusbarHeight + "px";     
    }
    
    if(splashScreen) {
        splashScreen.style.paddingTop = statusbarHeight + "px";     
    }
}


};
});
define("OutSystemsUI.controller$DeviceDetection.AddClassesJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
var body = document.querySelector('body');

if($parameters.Browser !== "") {
    body.classList.add($parameters.Browser);
}

if($parameters.OS !== "") {
    body.classList.add($parameters.OS);    
}

if($parameters.IsTouch) {
    body.classList.add('is--touch');
}
};
});

define("OutSystemsUI.controller$ECTCall", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.controller", "OutSystemsUI.controller$ECTCall.InitECTJS", "OutSystemsUI.controller$GetECTURL"], function (exports, OutSystems, OutSystemsUIModel, OutSystemsUIController, OutSystemsUI_controller_ECTCall_InitECTJS) {
var OS = OutSystems.Internal;
OutSystemsUIController.default.eCTCall$Action = function (callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:JQm1Wit7_EeqJznh4EqEmw:/ClientActionFlows.JQm1Wit7_EeqJznh4EqEmw:lv7txFWgEaiq4l4jo7P3+g", "OutSystemsUI", "ECTCall", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:mHckDcDGTkefbeqoxIZ3+w", callContext.id);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:AZ_lAiT4PkqroKU27DpP1Q", callContext.id);
controller.safeExecuteJSNode(OutSystemsUI_controller_ECTCall_InitECTJS, "InitECT", "ECTCall", {
URL: OS.DataConversion.JSNodeParamConverter.to(OutSystemsDebugger.handleFunctionCall(function () {
return OutSystemsUIController.default.getECTURL$Action(callContext).uRLOut;
}, OS.Types.Text, callContext.id), OS.Types.Text),
ModuleName: OS.DataConversion.JSNodeParamConverter.to(OS.BuiltinFunctions.getEntryEspaceName(), OS.Types.Text),
CurrentLocale: OS.DataConversion.JSNodeParamConverter.to(OS.BuiltinFunctions.getCurrentLocale(), OS.Types.Text),
UserId: OS.DataConversion.JSNodeParamConverter.to(OS.BuiltinFunctions.getUserId(), OS.Types.Integer)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:KUo1WCwkPE+5mz3TvPfI1g", callContext.id);
return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:JQm1Wit7_EeqJznh4EqEmw", callContext.id);
}

};
var controller = OutSystemsUIController.default;
OutSystemsUIController.default.clientActionProxies.eCTCall$Action = function () {
return controller.executeActionInsideJSNode(OutSystemsUIController.default.eCTCall$Action.bind(controller), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("OutSystemsUI.controller$ECTCall.InitECTJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
function htmlDecode(input){
  var e = document.createElement('textarea');
  e.innerHTML = input;
  // handle case of empty input
  return e.childNodes.length === 0 ? "" : e.childNodes[0].nodeValue;
}

function createHTMLElement(block){
    var range = document.createRange();
    var node = htmlDecode(block);
    var documentFragment = range.createContextualFragment(node);
    
    // Removes the non existant Theme file
    if(documentFragment.querySelector('#ect_wtOutFeedbackDiv') !== null && documentFragment.querySelector('#ect_wtOutFeedbackDiv').childNodes[0].childNodes[0].href.includes('Theme')) {
        documentFragment.querySelector('#ect_wtOutFeedbackDiv').childNodes[0].childNodes[0].remove();
    }
    
    document.body.appendChild(documentFragment);
}

var soapRequest = new XMLHttpRequest();
var soapBody = '<?xml version="1.0" encoding="utf-8"?>' +
                '<soapenv:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:api="http://127.0.0.1/Integrics/Enswitch/API" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/">' +
                    '<soapenv:Body>' +
                        '<GetModernECT xmlns="http://www.outsystems.com"> <moduleName>' + $parameters.ModuleName + '</moduleName>  <userId>' + $parameters.UserId + '</userId>  <locale>' + $parameters.CurrentLocale + '</locale>  </GetModernECT>' +
                    '</soapenv:Body>' +
                '</soapenv:Envelope>';
var timeout = 2000;
                
                
soapRequest.open('POST', window.location.origin + $parameters.URL, true);

soapRequest.setRequestHeader('Content-Type', 'text/xml');
soapRequest.responseType = 'document';
soapRequest.timeout = timeout;

soapRequest.onload = function() {
    if (soapRequest.readyState === 4) {
        if (soapRequest.status === 200) {
            createHTMLElement(soapRequest.response.getElementsByTagName('GetModernECTResponse')[0].getElementsByTagName('html')[0].innerHTML);
            if(document.getElementById('ect_wtFeedbackInput') !== null) {
                document.getElementById('ect_wtFeedbackInput').setAttribute('onchange', '');
                document.getElementById('ect_wtFeedbackInput').setAttribute('onkeyup', '');
            }
        } else {
            console.error(soapRequest.statusText);
        }
    }
    
} 

soapRequest.send(soapBody);

};
});

define("OutSystemsUI.controller$EndOfflineDataSync", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.controller", "OutSystemsUI.controller$EndOfflineDataSync.TriggerSyncCompleteEventJS", "OutSystemsUI.controller$EndOfflineDataSync.TriggerSyncErrorEventJS"], function (exports, OutSystems, OutSystemsUIModel, OutSystemsUIController, OutSystemsUI_controller_EndOfflineDataSync_TriggerSyncCompleteEventJS, OutSystemsUI_controller_EndOfflineDataSync_TriggerSyncErrorEventJS) {
var OS = OutSystems.Internal;
OutSystemsUIController.default.endOfflineDataSync$Action = function (hasErrorIn, errorMessageIn, allowRetryIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsUI.EndOfflineDataSync$vars"))());
vars.value.hasErrorInLocal = hasErrorIn;
vars.value.errorMessageInLocal = errorMessageIn;
vars.value.allowRetryInLocal = allowRetryIn;
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:AB+048wZeESjgZV4xG1UYg:/ClientActionFlows.AB+048wZeESjgZV4xG1UYg:nzzr3PCOOkTPkRQSPfTDjA", "OutSystemsUI", "EndOfflineDataSync", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:vEmEoYJ_GUeCgNb_hSa5lQ", callContext.id);
if((OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:ncGVGJ0owEmKLlIy4BaxiQ", callContext.id) && vars.value.hasErrorInLocal)) {
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:iIqr4yohpki+TJEMODfuzQ", callContext.id);
controller.safeExecuteJSNode(OutSystemsUI_controller_EndOfflineDataSync_TriggerSyncErrorEventJS, "TriggerSyncErrorEvent", "EndOfflineDataSync", {
ErrorMessage: OS.DataConversion.JSNodeParamConverter.to(vars.value.errorMessageInLocal, OS.Types.Text),
AllowRetry: OS.DataConversion.JSNodeParamConverter.to(vars.value.allowRetryInLocal, OS.Types.Boolean)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:b5IFu_KqQUCcrmTBRopVKw", callContext.id);
} else {
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:v03QPIY87ECIHTsz5R0JNA", callContext.id);
controller.safeExecuteJSNode(OutSystemsUI_controller_EndOfflineDataSync_TriggerSyncCompleteEventJS, "TriggerSyncCompleteEvent", "EndOfflineDataSync", null, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:b5IFu_KqQUCcrmTBRopVKw", callContext.id);
}

return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:AB+048wZeESjgZV4xG1UYg", callContext.id);
}

};
var controller = OutSystemsUIController.default;
OutSystemsUIController.default.constructor.registerVariableGroupType("OutSystemsUI.EndOfflineDataSync$vars", [{
name: "HasError",
attrName: "hasErrorInLocal",
mandatory: true,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}, {
name: "ErrorMessage",
attrName: "errorMessageInLocal",
mandatory: false,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}, {
name: "AllowRetry",
attrName: "allowRetryInLocal",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
OutSystemsUIController.default.clientActionProxies.endOfflineDataSync$Action = function (hasErrorIn, errorMessageIn, allowRetryIn) {
hasErrorIn = (hasErrorIn === undefined) ? false : hasErrorIn;
errorMessageIn = (errorMessageIn === undefined) ? "" : errorMessageIn;
allowRetryIn = (allowRetryIn === undefined) ? false : allowRetryIn;
return controller.executeActionInsideJSNode(OutSystemsUIController.default.endOfflineDataSync$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(hasErrorIn, OS.Types.Boolean), OS.DataConversion.JSNodeParamConverter.from(errorMessageIn, OS.Types.Text), OS.DataConversion.JSNodeParamConverter.from(allowRetryIn, OS.Types.Boolean)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("OutSystemsUI.controller$EndOfflineDataSync.TriggerSyncCompleteEventJS", [], function () {
return function ($actions, $roles, $public) {
window.offlineDataSync.triggerSyncCompleteEvent();

};
});
define("OutSystemsUI.controller$EndOfflineDataSync.TriggerSyncErrorEventJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
window.offlineDataSync.triggerSyncErrorEvent($parameters.ErrorMessage, $parameters.AllowRetry);

};
});

define("OutSystemsUI.controller$FixInputs", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.controller", "OutSystemsUI.controller$FixInputs.FixInputsJS"], function (exports, OutSystems, OutSystemsUIModel, OutSystemsUIController, OutSystemsUI_controller_FixInputs_FixInputsJS) {
var OS = OutSystems.Internal;
OutSystemsUIController.default.fixInputs$Action = function (callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:joiCQJkwhEazo8+aMtGV2Q:/ClientActionFlows.joiCQJkwhEazo8+aMtGV2Q:McVEsuOhRjKyc_XrFjSw2g", "OutSystemsUI", "FixInputs", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:zHVm52HnGkCutkyhJ8Q6sw", callContext.id);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:PQa9fzVt50+PvtBRPKnhgQ", callContext.id);
controller.safeExecuteJSNode(OutSystemsUI_controller_FixInputs_FixInputsJS, "FixInputs", "FixInputs", null, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:MHp2qeIBc0OkgRuqHvU2vQ", callContext.id);
return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:joiCQJkwhEazo8+aMtGV2Q", callContext.id);
}

};
var controller = OutSystemsUIController.default;
OutSystemsUIController.default.clientActionProxies.fixInputs$Action = function () {
return controller.executeActionInsideJSNode(OutSystemsUIController.default.fixInputs$Action.bind(controller), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("OutSystemsUI.controller$FixInputs.FixInputsJS", [], function () {
return function ($actions, $roles, $public) {
// apply the iOS inputs fix for webviews
osui.FixInputs();
};
});

define("OutSystemsUI.controller$GetBrowser", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.controller"], function (exports, OutSystems, OutSystemsUIModel, OutSystemsUIController) {
var OS = OutSystems.Internal;
OutSystemsUIController.default.getBrowser$Action = function (userAgentIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsUI.GetBrowser$vars"))());
vars.value.userAgentInLocal = userAgentIn;
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsUI.GetBrowser$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:dV1fY48Rm0muX7QLAz_Zeg:/ClientActionFlows.dV1fY48Rm0muX7QLAz_Zeg:f0DfeFuzSO96LM1S0+E2vA", "OutSystemsUI", "GetBrowser", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:enpNVcI00UmoatR0IGRzJA", callContext.id);
// DetectBrowser
if((OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:e8RM0whGOUeEDg0Sr0uuNA", callContext.id) && (OS.BuiltinFunctions.index(vars.value.userAgentInLocal, "edge", 0, false, false) > -1))) {
// Edge
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:RMQogNJuREukkmWOqCDqLg", callContext.id);
// Browser = "edge"
outVars.value.browserOut = "edge";
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:tJLANBnAAECuLWQLmQUMQA", callContext.id);
} else {
if((OS.BuiltinFunctions.index(vars.value.userAgentInLocal, "firefox", 0, false, false) > -1)) {
// Firefox
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:dXew8pG+N0ubvxq9eJvk0Q", callContext.id);
// Browser = "firefox"
outVars.value.browserOut = "firefox";
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:tJLANBnAAECuLWQLmQUMQA", callContext.id);
} else {
if(((OS.BuiltinFunctions.index(vars.value.userAgentInLocal, "chrome", 0, false, false) > -1) || (OS.BuiltinFunctions.index(vars.value.userAgentInLocal, "crios", 0, false, false) > -1))) {
// Chrome
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:VRQ0rVhJfU62Aj6UOQjqOg", callContext.id);
// Browser = "chrome"
outVars.value.browserOut = "chrome";
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:tJLANBnAAECuLWQLmQUMQA", callContext.id);
} else {
if(((OS.BuiltinFunctions.index(vars.value.userAgentInLocal, "safari", 0, false, false) > -1) && (OS.BuiltinFunctions.index(vars.value.userAgentInLocal, "chrome", 0, false, false) <= -1))) {
// Safari
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:0uBexWpwIUOBEZnWA1YVWw", callContext.id);
// Browser = "safari"
outVars.value.browserOut = "safari";
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:tJLANBnAAECuLWQLmQUMQA", callContext.id);
} else {
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:tJLANBnAAECuLWQLmQUMQA", callContext.id);
}

}

}

}

return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:dV1fY48Rm0muX7QLAz_Zeg", callContext.id);
}

};
var controller = OutSystemsUIController.default;
OutSystemsUIController.default.constructor.registerVariableGroupType("OutSystemsUI.GetBrowser$vars", [{
name: "UserAgent",
attrName: "userAgentInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
OutSystemsUIController.default.constructor.registerVariableGroupType("OutSystemsUI.GetBrowser$outVars", [{
name: "Browser",
attrName: "browserOut",
mandatory: false,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
OutSystemsUIController.default.clientActionProxies.getBrowser$Action = function (userAgentIn) {
userAgentIn = (userAgentIn === undefined) ? "" : userAgentIn;
return controller.executeActionInsideJSNode(OutSystemsUIController.default.getBrowser$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(userAgentIn, OS.Types.Text)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
Browser: OS.DataConversion.JSNodeParamConverter.to(actionResults.browserOut, OS.Types.Text)
};
});
};
});

define("OutSystemsUI.controller$GetDeviceOrientation", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.controller", "OutSystemsUI.controller$GetDeviceOrientation.CheckDeviceJS"], function (exports, OutSystems, OutSystemsUIModel, OutSystemsUIController, OutSystemsUI_controller_GetDeviceOrientation_CheckDeviceJS) {
var OS = OutSystems.Internal;
OutSystemsUIController.default.getDeviceOrientation$Action = function (callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var checkDeviceJSResult = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsUI.GetDeviceOrientation$outVars"))());
varBag.callContext = callContext;
varBag.checkDeviceJSResult = checkDeviceJSResult;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:tGVz89UL+E+S9m21JwQD0w:/ClientActionFlows.tGVz89UL+E+S9m21JwQD0w:e3jWoXW6l0vG9_rJypZTAA", "OutSystemsUI", "GetDeviceOrientation", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:WlXLDSxzeE2HWrZvOK8R9A", callContext.id);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:gbjVoiko4UGtMqk2GHLr1g", callContext.id);
checkDeviceJSResult.value = controller.safeExecuteJSNode(OutSystemsUI_controller_GetDeviceOrientation_CheckDeviceJS, "CheckDevice", "GetDeviceOrientation", {
Orientation: OS.DataConversion.JSNodeParamConverter.to("", OS.Types.Text)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("OutSystemsUI.GetDeviceOrientation$checkDeviceJSResult"))();
jsNodeResult.orientationOut = OS.DataConversion.JSNodeParamConverter.from($parameters.Orientation, OS.Types.Text);
return jsNodeResult;
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:5mf9zMosH0iwQ_WWqvwkug", callContext.id);
// Orientation = CheckDevice.Orientation
outVars.value.orientationOut = checkDeviceJSResult.value.orientationOut;
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:eJeV2aTII0yt5v5wbvM3kg", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:tGVz89UL+E+S9m21JwQD0w", callContext.id);
}

};
var controller = OutSystemsUIController.default;
OutSystemsUIController.default.constructor.registerVariableGroupType("OutSystemsUI.GetDeviceOrientation$checkDeviceJSResult", [{
name: "Orientation",
attrName: "orientationOut",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
OutSystemsUIController.default.constructor.registerVariableGroupType("OutSystemsUI.GetDeviceOrientation$outVars", [{
name: "Orientation",
attrName: "orientationOut",
mandatory: false,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
OutSystemsUIController.default.clientActionProxies.getDeviceOrientation$Action = function () {
return controller.executeActionInsideJSNode(OutSystemsUIController.default.getDeviceOrientation$Action.bind(controller), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
Orientation: OS.DataConversion.JSNodeParamConverter.to(actionResults.orientationOut, OS.Types.Text)
};
});
};
});
define("OutSystemsUI.controller$GetDeviceOrientation.CheckDeviceJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
var classList = document.body.classList;

if(classList.contains("landscape")) {
    $parameters.Orientation = "landscape";
} else if(classList.contains("portrait")) {
    $parameters.Orientation = "portrait";
}
};
});

define("OutSystemsUI.controller$GetDeviceType", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.controller", "OutSystemsUI.controller$GetDeviceType.CheckDeviceJS"], function (exports, OutSystems, OutSystemsUIModel, OutSystemsUIController, OutSystemsUI_controller_GetDeviceType_CheckDeviceJS) {
var OS = OutSystems.Internal;
OutSystemsUIController.default.getDeviceType$Action = function (callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var checkDeviceJSResult = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsUI.GetDeviceType$outVars"))());
varBag.callContext = callContext;
varBag.checkDeviceJSResult = checkDeviceJSResult;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:V8kn6TfTuUWAmMWp18n+Vw:/ClientActionFlows.V8kn6TfTuUWAmMWp18n+Vw:9Zh_rdLAgDsBOjcR12SHxg", "OutSystemsUI", "GetDeviceType", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:ZvhAJGrMGkeKAvnAYcWXlQ", callContext.id);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:N9WTj9dLUkuBdvhGabzneA", callContext.id);
checkDeviceJSResult.value = controller.safeExecuteJSNode(OutSystemsUI_controller_GetDeviceType_CheckDeviceJS, "CheckDevice", "GetDeviceType", {
Device: OS.DataConversion.JSNodeParamConverter.to("", OS.Types.Text)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("OutSystemsUI.GetDeviceType$checkDeviceJSResult"))();
jsNodeResult.deviceOut = OS.DataConversion.JSNodeParamConverter.from($parameters.Device, OS.Types.Text);
return jsNodeResult;
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:Z+YNE6HFAEC_aV40cAT4ZA", callContext.id);
// Device = CheckDevice.Device
outVars.value.deviceOut = checkDeviceJSResult.value.deviceOut;
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:ivLLSyFVj0uFhq3EYv2bFg", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:V8kn6TfTuUWAmMWp18n+Vw", callContext.id);
}

};
var controller = OutSystemsUIController.default;
OutSystemsUIController.default.constructor.registerVariableGroupType("OutSystemsUI.GetDeviceType$checkDeviceJSResult", [{
name: "Device",
attrName: "deviceOut",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
OutSystemsUIController.default.constructor.registerVariableGroupType("OutSystemsUI.GetDeviceType$outVars", [{
name: "Device",
attrName: "deviceOut",
mandatory: false,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
OutSystemsUIController.default.clientActionProxies.getDeviceType$Action = function () {
return controller.executeActionInsideJSNode(OutSystemsUIController.default.getDeviceType$Action.bind(controller), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
Device: OS.DataConversion.JSNodeParamConverter.to(actionResults.deviceOut, OS.Types.Text)
};
});
};
});
define("OutSystemsUI.controller$GetDeviceType.CheckDeviceJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
var classList = document.body.classList;

if(classList.contains("phone")) {
    $parameters.Device = "phone";
} else if(classList.contains("tablet")) {
    $parameters.Device = "tablet";
} else {
    $parameters.Device = "desktop";
}
};
});

define("OutSystemsUI.controller$GetECTURL", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.controller"], function (exports, OutSystems, OutSystemsUIModel, OutSystemsUIController) {
var OS = OutSystems.Internal;
OutSystemsUIController.default.getECTURL$Action = function (callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsUI.GetECTURL$outVars"))());
varBag.callContext = callContext;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:fXEH2WZHUUydeeqXb58htg:/ClientActionFlows.fXEH2WZHUUydeeqXb58htg:K_xWOJ4lS4zEAMm6dPuYDA", "OutSystemsUI", "GetECTURL", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:F_yOm7loL06q_516kLwKbA", callContext.id);
// URL
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:AoRQO0BVQkKF3zbzl5IiYw", callContext.id);
// URL = "/ECT_Provider/WS_ECT.asmx"
outVars.value.uRLOut = "/ECT_Provider/WS_ECT.asmx";
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:czCiPkd8T0q1ZbAgZlnbjA", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:fXEH2WZHUUydeeqXb58htg", callContext.id);
}

};
var controller = OutSystemsUIController.default;
OutSystemsUIController.default.constructor.registerVariableGroupType("OutSystemsUI.GetECTURL$outVars", [{
name: "URL",
attrName: "uRLOut",
mandatory: false,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
OutSystemsUIController.default.clientActionProxies.getECTURL$Action = function () {
return controller.executeActionInsideJSNode(OutSystemsUIController.default.getECTURL$Action.bind(controller), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
URL: OS.DataConversion.JSNodeParamConverter.to(actionResults.uRLOut, OS.Types.Text)
};
});
};
});

define("OutSystemsUI.controller$GetIsTouch", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.controller", "OutSystemsUI.controller$GetIsTouch.SetIsTouchJS"], function (exports, OutSystems, OutSystemsUIModel, OutSystemsUIController, OutSystemsUI_controller_GetIsTouch_SetIsTouchJS) {
var OS = OutSystems.Internal;
OutSystemsUIController.default.getIsTouch$Action = function (callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var setIsTouchJSResult = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsUI.GetIsTouch$outVars"))());
varBag.callContext = callContext;
varBag.setIsTouchJSResult = setIsTouchJSResult;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:RZ1a65S6TEG+U0tQG3j8vA:/ClientActionFlows.RZ1a65S6TEG+U0tQG3j8vA:JN+MCZB215Jrn64jZwE5Bw", "OutSystemsUI", "GetIsTouch", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:eq_Hnst4vkq_06kai8zFAA", callContext.id);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:UzL18+5tCEyY2xczP1HzpQ", callContext.id);
setIsTouchJSResult.value = controller.safeExecuteJSNode(OutSystemsUI_controller_GetIsTouch_SetIsTouchJS, "SetIsTouch", "GetIsTouch", {
IsTouch: OS.DataConversion.JSNodeParamConverter.to(false, OS.Types.Boolean)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("OutSystemsUI.GetIsTouch$setIsTouchJSResult"))();
jsNodeResult.isTouchOut = OS.DataConversion.JSNodeParamConverter.from($parameters.IsTouch, OS.Types.Boolean);
return jsNodeResult;
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:XxzUi3lJf0C_2edgopB4Tw", callContext.id);
// IsTouch = SetIsTouch.IsTouch
outVars.value.isTouchOut = setIsTouchJSResult.value.isTouchOut;
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:hc1FN68lS0+PvmL2nVXeFQ", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:RZ1a65S6TEG+U0tQG3j8vA", callContext.id);
}

};
var controller = OutSystemsUIController.default;
OutSystemsUIController.default.constructor.registerVariableGroupType("OutSystemsUI.GetIsTouch$setIsTouchJSResult", [{
name: "IsTouch",
attrName: "isTouchOut",
mandatory: true,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
OutSystemsUIController.default.constructor.registerVariableGroupType("OutSystemsUI.GetIsTouch$outVars", [{
name: "IsTouch",
attrName: "isTouchOut",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
OutSystemsUIController.default.clientActionProxies.getIsTouch$Action = function () {
return controller.executeActionInsideJSNode(OutSystemsUIController.default.getIsTouch$Action.bind(controller), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
IsTouch: OS.DataConversion.JSNodeParamConverter.to(actionResults.isTouchOut, OS.Types.Boolean)
};
});
};
});
define("OutSystemsUI.controller$GetIsTouch.SetIsTouchJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
var body = document.body;
var isTouch = false;
  
function detectTouchscreen() {
  if (window.PointerEvent && ('maxTouchPoints' in navigator)) {
    // if Pointer Events are supported, just check maxTouchPoints
    if (navigator.maxTouchPoints > 0) {
      isTouch = true;
    }
  } else {
    // no Pointer Events...
    if (window.matchMedia && window.matchMedia("(any-pointer:coarse)").matches) {
      // check for any-pointer:coarse which mostly means touchscreen
      isTouch = true;
    } else if (window.TouchEvent || ('ontouchstart' in window)) {
      // last resort - check for exposed touch events API / event handler
      isTouch = true;
    }
  }
  
  return isTouch;
  
}

detectTouchscreen();
$parameters.IsTouch = isTouch;
};
});

define("OutSystemsUI.controller$GetNetworkStatus", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.controller", "OutSystemsUI.controller$GetNetworkType"], function (exports, OutSystems, OutSystemsUIModel, OutSystemsUIController) {
var OS = OutSystems.Internal;
OutSystemsUIController.default.getNetworkStatus$Action = function (callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var getNetworkTypeVar = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsUI.GetNetworkStatus$outVars"))());
varBag.callContext = callContext;
varBag.getNetworkTypeVar = getNetworkTypeVar;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:Jy8FxeT960+JHkWnvjJmrA:/ClientActionFlows.Jy8FxeT960+JHkWnvjJmrA:d9m9yXmcuRiF5Zkkl5SrVw", "OutSystemsUI", "GetNetworkStatus", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:xI6lj4cJrkycwMKaYxJ9qg", callContext.id);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:TzWCSMV5Y0mqa6xVBaVkbw", callContext.id);
// Execute Action: GetNetworkType
getNetworkTypeVar.value = OutSystemsUIController.default.getNetworkType$Action(callContext);

OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:EVe_1N6TwkOPoX_6BvPMwg", callContext.id);
// IsOnline = GetNetworkType.NetworkType <> "none" and GetNetworkType.NetworkType <> "unknown"
outVars.value.isOnlineOut = (((getNetworkTypeVar.value.networkTypeOut) !== ("none")) && ((getNetworkTypeVar.value.networkTypeOut) !== ("unknown")));
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:DxBwnwxWYkGRFq2qdQoUeQ", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:Jy8FxeT960+JHkWnvjJmrA", callContext.id);
}

};
var controller = OutSystemsUIController.default;
OutSystemsUIController.default.constructor.registerVariableGroupType("OutSystemsUI.GetNetworkStatus$outVars", [{
name: "IsOnline",
attrName: "isOnlineOut",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
OutSystemsUIController.default.clientActionProxies.getNetworkStatus$Action = function () {
return controller.executeActionInsideJSNode(OutSystemsUIController.default.getNetworkStatus$Action.bind(controller), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
IsOnline: OS.DataConversion.JSNodeParamConverter.to(actionResults.isOnlineOut, OS.Types.Boolean)
};
});
};
});

define("OutSystemsUI.controller$GetNetworkType", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.controller", "OutSystemsUI.controller$GetNetworkType.CheckNetworkTypeJS"], function (exports, OutSystems, OutSystemsUIModel, OutSystemsUIController, OutSystemsUI_controller_GetNetworkType_CheckNetworkTypeJS) {
var OS = OutSystems.Internal;
OutSystemsUIController.default.getNetworkType$Action = function (callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var checkNetworkTypeJSResult = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsUI.GetNetworkType$outVars"))());
varBag.callContext = callContext;
varBag.checkNetworkTypeJSResult = checkNetworkTypeJSResult;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:+ZNpq6EuMUqlKdDF3430RQ:/ClientActionFlows.+ZNpq6EuMUqlKdDF3430RQ:Ah5PtM6SUF7JQJER6Ea_Mw", "OutSystemsUI", "GetNetworkType", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:cJs2O+6qmEa1MRh3D3tRSg", callContext.id);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:DdnOaND2fkCpllA7GTAiCg", callContext.id);
checkNetworkTypeJSResult.value = controller.safeExecuteJSNode(OutSystemsUI_controller_GetNetworkType_CheckNetworkTypeJS, "CheckNetworkType", "GetNetworkType", {
NetworkType: OS.DataConversion.JSNodeParamConverter.to("", OS.Types.Text)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("OutSystemsUI.GetNetworkType$checkNetworkTypeJSResult"))();
jsNodeResult.networkTypeOut = OS.DataConversion.JSNodeParamConverter.from($parameters.NetworkType, OS.Types.Text);
return jsNodeResult;
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:5ClbImcBE0CofTng9C3dZg", callContext.id);
// NetworkType = CheckNetworkType.NetworkType
outVars.value.networkTypeOut = checkNetworkTypeJSResult.value.networkTypeOut;
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:1d7KSzcSFUmHBadz77dl9Q", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:+ZNpq6EuMUqlKdDF3430RQ", callContext.id);
}

};
var controller = OutSystemsUIController.default;
OutSystemsUIController.default.constructor.registerVariableGroupType("OutSystemsUI.GetNetworkType$checkNetworkTypeJSResult", [{
name: "NetworkType",
attrName: "networkTypeOut",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
OutSystemsUIController.default.constructor.registerVariableGroupType("OutSystemsUI.GetNetworkType$outVars", [{
name: "NetworkType",
attrName: "networkTypeOut",
mandatory: false,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
OutSystemsUIController.default.clientActionProxies.getNetworkType$Action = function () {
return controller.executeActionInsideJSNode(OutSystemsUIController.default.getNetworkType$Action.bind(controller), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
NetworkType: OS.DataConversion.JSNodeParamConverter.to(actionResults.networkTypeOut, OS.Types.Text)
};
});
};
});
define("OutSystemsUI.controller$GetNetworkType.CheckNetworkTypeJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
if (typeof navigator.connection !== "undefined") {
    //In a mobile device
    if(typeof navigator.connection.type !== "undefined"){
        $parameters.NetworkType = navigator.connection.type;
    } else {
        //In a web browser
        $parameters.NetworkType = "webbrowser"; //TO-DO: Improve this!!!
    }
} else {
    //In a web browser
    $parameters.NetworkType = "webbrowser"; //TO-DO: Improve this!!!
}
};
});

define("OutSystemsUI.controller$GetOS", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.controller", "OutSystemsUI.controller$GetOS.DetectIphoneXJS"], function (exports, OutSystems, OutSystemsUIModel, OutSystemsUIController, OutSystemsUI_controller_GetOS_DetectIphoneXJS) {
var OS = OutSystems.Internal;
OutSystemsUIController.default.getOS$Action = function (userAgentIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsUI.GetOS$vars"))());
vars.value.userAgentInLocal = userAgentIn;
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsUI.GetOS$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:xv7Qrjz7QUGtBmrY543I6A:/ClientActionFlows.xv7Qrjz7QUGtBmrY543I6A:azV0bbLRjZF5GBV5TltVXQ", "OutSystemsUI", "GetOS", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:qCrxHG1sYkiv4suX4MWRJQ", callContext.id);
// Detect Device
if((OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:kq5UEbH41kSUDgj9ytpzpA", callContext.id) && ((OS.BuiltinFunctions.index(vars.value.userAgentInLocal, "ipad", 0, false, false) > -1) || (OS.BuiltinFunctions.index(vars.value.userAgentInLocal, "iphone", 0, false, false) > -1)))) {
// Ios
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:qxbU+4BD2kqtbcKBet0mmg", callContext.id);
// OS = "ios"
outVars.value.oSOut = "ios";
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:UTNgkVilxEuT_Cr3S2KMTA", callContext.id);
controller.safeExecuteJSNode(OutSystemsUI_controller_GetOS_DetectIphoneXJS, "DetectIphoneX", "GetOS", null, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:WWtYynhaykGMr7fxAZWZEQ", callContext.id);
} else {
if((OS.BuiltinFunctions.index(vars.value.userAgentInLocal, "android", 0, false, false) > -1)) {
// Android
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:g5GMKvCPfUSIkYWgdSmmOg", callContext.id);
// OS = "android"
outVars.value.oSOut = "android";
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:WWtYynhaykGMr7fxAZWZEQ", callContext.id);
} else {
if((OS.BuiltinFunctions.index(vars.value.userAgentInLocal, "windows", 0, false, false) > -1)) {
// Windows
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:Gw8OZz1r0E2KMJp2nMTTag", callContext.id);
// OS = "windows"
outVars.value.oSOut = "windows";
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:WWtYynhaykGMr7fxAZWZEQ", callContext.id);
} else {
if((OS.BuiltinFunctions.index(vars.value.userAgentInLocal, "mac", 0, false, false) > -1)) {
// OSX
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:bshK_kErOEq3Y_BrL+gZ+g", callContext.id);
// OS = "osx"
outVars.value.oSOut = "osx";
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:WWtYynhaykGMr7fxAZWZEQ", callContext.id);
} else {
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:WWtYynhaykGMr7fxAZWZEQ", callContext.id);
}

}

}

}

return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:xv7Qrjz7QUGtBmrY543I6A", callContext.id);
}

};
var controller = OutSystemsUIController.default;
OutSystemsUIController.default.constructor.registerVariableGroupType("OutSystemsUI.GetOS$vars", [{
name: "UserAgent",
attrName: "userAgentInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
OutSystemsUIController.default.constructor.registerVariableGroupType("OutSystemsUI.GetOS$outVars", [{
name: "OS",
attrName: "oSOut",
mandatory: false,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
OutSystemsUIController.default.clientActionProxies.getOS$Action = function (userAgentIn) {
userAgentIn = (userAgentIn === undefined) ? "" : userAgentIn;
return controller.executeActionInsideJSNode(OutSystemsUIController.default.getOS$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(userAgentIn, OS.Types.Text)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
OS: OS.DataConversion.JSNodeParamConverter.to(actionResults.oSOut, OS.Types.Text)
};
});
};
});
define("OutSystemsUI.controller$GetOS.DetectIphoneXJS", [], function () {
return function ($actions, $roles, $public) {
var body = document.querySelector("body");

// detect iPhoneX
function detectIphoneX() {
    // devices list and their screen sizes
    var devices = [
        {width: 1125, height: 2436, description: "iphone x/xs"},
        {width: 828, height: 1792, description: "iphone xr"},
        {width: 750, height: 1624, description: "iphone xr scaled"},
        {width: 1242, height: 2688, description: "iphone xs max"}
    ];
    
    // get the device pixel ratio
    var ratio = window.devicePixelRatio || 1;

    // get the device screen dimensions
    var screen = {
        width : window.screen.width * ratio,
        height : window.screen.height * ratio
    };

    // check if the screen size matches any of the devices in the list
    for(var i = 0; i < devices.length; i++) {
	    if(devices[i].width === screen.width && devices[i].height === screen.height) {
            window.iphoneX = true;
	    }
    }
    
    if(window.iphoneX) {
        // get orientation and register an event to update it
        detectOrientation();
        window.addEventListener("orientationchange", function() {
            setTimeout(detectOrientation, 500);
        });
    }
}

// update orientation
function detectOrientation() {
    // store the notch position value
    var notchPosition;
    
    if("orientation" in window) {
        // mobile browers
        if (window.orientation == 90) {
            notchPosition = "left";
        } else if (window.orientation == -90) {
            notchPosition = "right";
        } else {
            notchPosition = "up";
        }
    } else if ("orientation" in window.screen) {
        // webkit browsers
        if( window.screen.orientation.type === "landscape-primary") {
            notchPosition = "left";
        } else if( window.screen.orientation.type === "landscape-secondary") {
            notchPosition = "right";
        } else {
            notchPosition = "up";
        }
    } else if("mozOrientation" in window.screen) {
        // firefox browsers
        if( window.screen.mozOrientation === "landscape-primary") {
            notchPosition = "left";
        } else if( window.screen.mozOrientation === "landscape-secondary") {
            notchPosition = "right";
        } else {
            notchPosition = "up";
        }
    }
    
    window.notch = notchPosition;
    updateClasses();
}

function updateClasses() {
    // set the iphonex class on the body
    body.classList.add("iphonex");
    
    // override tablet detection on landscape mode
    if (window.notch == "left" || window.notch == "right") {
        body.classList.remove("tablet");
        body.classList.add("phone");
    }
}

// detect iPhoneX
detectIphoneX();
};
});

define("OutSystemsUI.controller$HideHeader", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.controller", "OutSystemsUI.controller$HideHeader.HideOnScrollJS"], function (exports, OutSystems, OutSystemsUIModel, OutSystemsUIController, OutSystemsUI_controller_HideHeader_HideOnScrollJS) {
var OS = OutSystems.Internal;
OutSystemsUIController.default.hideHeader$Action = function (hideHeaderIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsUI.HideHeader$vars"))());
vars.value.hideHeaderInLocal = hideHeaderIn;
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:yWN3I3mUa0+a7mgU7VdRyw:/ClientActionFlows.yWN3I3mUa0+a7mgU7VdRyw:vNzz0RmiEKZWbO63qloD+w", "OutSystemsUI", "HideHeader", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:RcQh4R4oTkimx1nMetHWXw", callContext.id);
if((OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:3JmP0Rp+3Uuc_SKPk_Ui0Q", callContext.id) && vars.value.hideHeaderInLocal)) {
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:YIoLAMN9y0C6r84F2nZDLg", callContext.id);
controller.safeExecuteJSNode(OutSystemsUI_controller_HideHeader_HideOnScrollJS, "HideOnScroll", "HideHeader", null, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:kUv59cqJ6Uyzd_kOmdu1RA", callContext.id);
} else {
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:sjl7Mgg+Ck2k3OuMhnkwFQ", callContext.id);
}

return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:yWN3I3mUa0+a7mgU7VdRyw", callContext.id);
}

};
var controller = OutSystemsUIController.default;
OutSystemsUIController.default.constructor.registerVariableGroupType("OutSystemsUI.HideHeader$vars", [{
name: "HideHeader",
attrName: "hideHeaderInLocal",
mandatory: true,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
OutSystemsUIController.default.clientActionProxies.hideHeader$Action = function (hideHeaderIn) {
hideHeaderIn = (hideHeaderIn === undefined) ? false : hideHeaderIn;
return controller.executeActionInsideJSNode(OutSystemsUIController.default.hideHeader$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(hideHeaderIn, OS.Types.Boolean)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("OutSystemsUI.controller$HideHeader.HideOnScrollJS", [], function () {
return function ($actions, $roles, $public) {
// window.performance.timing is deprecated but the technology that MDN suggest to use is stil experimental and does not work on IE and Safari. Please visit the following link for context: 
// https://developer.mozilla.org/en-US/docs/Web/API/Performance/timing
var loadTime = window.performance.timing.domContentLoadedEventEnd- window.performance.timing.navigationStart;

setTimeout(function(){
    var hideOnScroll = new osui.HideOnScroll();
    hideOnScroll.init();
}, loadTime);
};
});

define("OutSystemsUI.controller$iPhoneXPreview", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.controller", "OutSystemsUI.controller$iPhoneXPreview.DetectPreviewInDevicesJS"], function (exports, OutSystems, OutSystemsUIModel, OutSystemsUIController, OutSystemsUI_controller_iPhoneXPreview_DetectPreviewInDevicesJS) {
var OS = OutSystems.Internal;
OutSystemsUIController.default.iPhoneXPreview$Action = function (callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsUI.iPhoneXPreview$vars"))());
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:NbOckAGFXESom8tE91RycA:/ClientActionFlows.NbOckAGFXESom8tE91RycA:bawPlB6F+9dZCpNZORL9eg", "OutSystemsUI", "iPhoneXPreview", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:sUoEZhrvbEuF6HCvCEDvVQ", callContext.id);
// iPhoneX Preview CSS
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:pXgbImTph0amgXBBKeCMoA", callContext.id);
// PreviewCSS = "/* iPhoneX Preview in Devices */
//
//.iphonex .bottom-bar-wrapper {    
//    padding-bottom: 5px;    
//}
//
//.iphonex .action-sheet {
//    padding-bottom: 5px; 
//}
//
//.iphonex .screen > .floating-actions .floating-actions-icon {    
//    margin-bottom: 35px; 
//}
//
///* portrait only */
//.iphonex.portrait .header,
//.iphonex.portrait .notification {
//    padding-top: 35px;
//}
//
//.iphonex.portrait .app-menu,
//.iphonex.portrait .sidebar {
//    padding-top: 35px;
//    padding-bottom: 5px;
//}
//
//.iphonex.portrait .split-right-close {
//    top: 41px;
//}
//
//.iphonex.portrait .header-right .search-input {
//    padding-top: 40px;
//}
//
//.iphonex.portrait .header-right .search-input:after {
//    top: 50px; 
//}
//
//.iphonex.portrait .feedback-message {
//    padding-top: 45px;
//}
//
///* landscape */
//.iphonex.landscape .app-menu,
//.iphonex.landscape .sidebar {
//    padding-bottom: 5px;
//}
//
//.iphonex.landscape .app-menu-links {
//    padding-left: 35px; 
//}
//
//.iphonex.landscape .header,
//.iphonex.landscape .main-content,
//.iphonex.landscape .bottom-bar-wrapper {
//    padding-left: 35px;
//    padding-right: 35px;
//}"
vars.value.previewCSSVar = "/* iPhoneX Preview in Devices */\r\n\r\n.iphonex .bottom-bar-wrapper {    \r\n    padding-bottom: 5px;    \r\n}\r\n\r\n.iphonex .action-sheet {\r\n    padding-bottom: 5px; \r\n}\r\n\r\n.iphonex .screen > .floating-actions .floating-actions-icon {    \r\n    margin-bottom: 35px; \r\n}\r\n\r\n/* portrait only */\r\n.iphonex.portrait .header,\r\n.iphonex.portrait .notification {\r\n    padding-top: 35px;\r\n}\r\n\r\n.iphonex.portrait .app-menu,\r\n.iphonex.portrait .sidebar {\r\n    padding-top: 35px;\r\n    padding-bottom: 5px;\r\n}\r\n\r\n.iphonex.portrait .split-right-close {\r\n    top: 41px;\r\n}\r\n\r\n.iphonex.portrait .header-right .search-input {\r\n    padding-top: 40px;\r\n}\r\n\r\n.iphonex.portrait .header-right .search-input:after {\r\n    top: 50px; \r\n}\r\n\r\n.iphonex.portrait .feedback-message {\r\n    padding-top: 45px;\r\n}\r\n\r\n/* landscape */\r\n.iphonex.landscape .app-menu,\r\n.iphonex.landscape .sidebar {\r\n    padding-bottom: 5px;\r\n}\r\n\r\n.iphonex.landscape .app-menu-links {\r\n    padding-left: 35px; \r\n}\r\n\r\n.iphonex.landscape .header,\r\n.iphonex.landscape .main-content,\r\n.iphonex.landscape .bottom-bar-wrapper {\r\n    padding-left: 35px;\r\n    padding-right: 35px;\r\n}";
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:NuLUeUgpEUCTkx4KpN0klA", callContext.id);
// Detects the Preview In Devices and adds support for the iPhoneX if needed
controller.safeExecuteJSNode(OutSystemsUI_controller_iPhoneXPreview_DetectPreviewInDevicesJS, "DetectPreviewInDevices", "iPhoneXPreview", {
PreviewCSS: OS.DataConversion.JSNodeParamConverter.to(vars.value.previewCSSVar, OS.Types.Text)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:lbIIpqHAUECLHUDQU3_2eA", callContext.id);
return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:NbOckAGFXESom8tE91RycA", callContext.id);
}

};
var controller = OutSystemsUIController.default;
OutSystemsUIController.default.constructor.registerVariableGroupType("OutSystemsUI.iPhoneXPreview$vars", [{
name: "PreviewCSS",
attrName: "previewCSSVar",
mandatory: false,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
OutSystemsUIController.default.clientActionProxies.iPhoneXPreview$Action = function () {
return controller.executeActionInsideJSNode(OutSystemsUIController.default.iPhoneXPreview$Action.bind(controller), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("OutSystemsUI.controller$iPhoneXPreview.DetectPreviewInDevicesJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
var body = document.querySelector('body');
var isIframe;
var isPreviewInDevices;

// detect Preview in Devices
function detectPreviewInDevices() {
    isIframe = window.self !== window.top;
    
    if(isIframe) {
       isPreviewInDevices = window.top.document.querySelector(".marvel-device") !== null;
    }
    
    if(isPreviewInDevices) {
        if(window.top.document.querySelector(".marvel-device").classList.contains("iphone-x")) {
            body.classList.add('ios');
            body.classList.add('iphonex');
            addIphoneXPreview();
        }
    }
}

function addIphoneXPreview() {
  
  var stylesEl = document.getElementById("preview-css");

  if (stylesEl === null) {
      var css = $parameters.PreviewCSS;
      var style = document.createElement('style');
      style.type = 'text/css';
      style.id = "preview-css";
      
      if (style.styleSheet){
        style.styleSheet.cssText = css;
      } else {
        style.appendChild(document.createTextNode(css));
      }
      
      document.body.appendChild(style);
  }
}

detectPreviewInDevices();
};
});

define("OutSystemsUI.controller$IsDesktop", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.controller", "OutSystemsUI.controller$GetDeviceType"], function (exports, OutSystems, OutSystemsUIModel, OutSystemsUIController) {
var OS = OutSystems.Internal;
OutSystemsUIController.default.isDesktop$Action = function (callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var getDeviceTypeVar = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsUI.IsDesktop$outVars"))());
varBag.callContext = callContext;
varBag.getDeviceTypeVar = getDeviceTypeVar;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:A+Ouy1m8hEqkJ1_FDu4WGw:/ClientActionFlows.A+Ouy1m8hEqkJ1_FDu4WGw:2JSmzaCbnrOt2UaI+88+PQ", "OutSystemsUI", "IsDesktop", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:NTLxb6dpl0GnKezFuLXCrg", callContext.id);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:LyPCmHPMOUiz05omO6N5Kg", callContext.id);
// Execute Action: GetDeviceType
getDeviceTypeVar.value = OutSystemsUIController.default.getDeviceType$Action(callContext);

OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:cxAlCplvwEOSSdLslc2ylQ", callContext.id);
// IsDesktop = GetDeviceType.Device = "desktop"
outVars.value.isDesktopOut = (getDeviceTypeVar.value.deviceOut === "desktop");
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:shg_i4TieE2fMp_GRRTp+w", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:A+Ouy1m8hEqkJ1_FDu4WGw", callContext.id);
}

};
var controller = OutSystemsUIController.default;
OutSystemsUIController.default.constructor.registerVariableGroupType("OutSystemsUI.IsDesktop$outVars", [{
name: "IsDesktop",
attrName: "isDesktopOut",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
OutSystemsUIController.default.clientActionProxies.isDesktop$Action = function () {
return controller.executeActionInsideJSNode(OutSystemsUIController.default.isDesktop$Action.bind(controller), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
IsDesktop: OS.DataConversion.JSNodeParamConverter.to(actionResults.isDesktopOut, OS.Types.Boolean)
};
});
};
});

define("OutSystemsUI.controller$IsPhone", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.controller", "OutSystemsUI.controller$GetDeviceType"], function (exports, OutSystems, OutSystemsUIModel, OutSystemsUIController) {
var OS = OutSystems.Internal;
OutSystemsUIController.default.isPhone$Action = function (callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var getDeviceTypeVar = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsUI.IsPhone$outVars"))());
varBag.callContext = callContext;
varBag.getDeviceTypeVar = getDeviceTypeVar;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:yHQFd4E_hEmOMh7uK+5Fyg:/ClientActionFlows.yHQFd4E_hEmOMh7uK+5Fyg:xfFqbkN_n3UqzrPwA4f5sg", "OutSystemsUI", "IsPhone", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:sqTjqT20_kKX0XFd6smU8g", callContext.id);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:BX3uLVf1k0Wr5zgao8m4ow", callContext.id);
// Execute Action: GetDeviceType
getDeviceTypeVar.value = OutSystemsUIController.default.getDeviceType$Action(callContext);

OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:sI5YvXpAx0yzCJClQinRcA", callContext.id);
// IsPhone = GetDeviceType.Device = "phone"
outVars.value.isPhoneOut = (getDeviceTypeVar.value.deviceOut === "phone");
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:HiJh7DVYkUquZoFhy0NigQ", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:yHQFd4E_hEmOMh7uK+5Fyg", callContext.id);
}

};
var controller = OutSystemsUIController.default;
OutSystemsUIController.default.constructor.registerVariableGroupType("OutSystemsUI.IsPhone$outVars", [{
name: "IsPhone",
attrName: "isPhoneOut",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
OutSystemsUIController.default.clientActionProxies.isPhone$Action = function () {
return controller.executeActionInsideJSNode(OutSystemsUIController.default.isPhone$Action.bind(controller), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
IsPhone: OS.DataConversion.JSNodeParamConverter.to(actionResults.isPhoneOut, OS.Types.Boolean)
};
});
};
});

define("OutSystemsUI.controller$IsTablet", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.controller", "OutSystemsUI.controller$GetDeviceType"], function (exports, OutSystems, OutSystemsUIModel, OutSystemsUIController) {
var OS = OutSystems.Internal;
OutSystemsUIController.default.isTablet$Action = function (callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var getDeviceTypeVar = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsUI.IsTablet$outVars"))());
varBag.callContext = callContext;
varBag.getDeviceTypeVar = getDeviceTypeVar;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:eSfw9qKoGkSe9uxu_d4bSg:/ClientActionFlows.eSfw9qKoGkSe9uxu_d4bSg:gs_ne3uu_eYws7jPLab4gw", "OutSystemsUI", "IsTablet", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:AoelbxLQKUqZjyK10lGysw", callContext.id);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:ioZf772KpUSfGBw8JlIMDw", callContext.id);
// Execute Action: GetDeviceType
getDeviceTypeVar.value = OutSystemsUIController.default.getDeviceType$Action(callContext);

OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:PbdePxtRWE68PTVq_rpzaw", callContext.id);
// IsTablet = GetDeviceType.Device = "tablet"
outVars.value.isTabletOut = (getDeviceTypeVar.value.deviceOut === "tablet");
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:JWCYa7HVNEGLLv_HARuYcQ", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:eSfw9qKoGkSe9uxu_d4bSg", callContext.id);
}

};
var controller = OutSystemsUIController.default;
OutSystemsUIController.default.constructor.registerVariableGroupType("OutSystemsUI.IsTablet$outVars", [{
name: "IsTablet",
attrName: "isTabletOut",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
OutSystemsUIController.default.clientActionProxies.isTablet$Action = function () {
return controller.executeActionInsideJSNode(OutSystemsUIController.default.isTablet$Action.bind(controller), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
IsTablet: OS.DataConversion.JSNodeParamConverter.to(actionResults.isTabletOut, OS.Types.Boolean)
};
});
};
});

define("OutSystemsUI.controller$IsWebApp", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.controller", "OutSystemsUI.controller$IsWebApp.CheckOSUIJS"], function (exports, OutSystems, OutSystemsUIModel, OutSystemsUIController, OutSystemsUI_controller_IsWebApp_CheckOSUIJS) {
var OS = OutSystems.Internal;
OutSystemsUIController.default.isWebApp$Action = function (callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var checkOSUIJSResult = new OS.DataTypes.VariableHolder();
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsUI.IsWebApp$outVars"))());
varBag.callContext = callContext;
varBag.checkOSUIJSResult = checkOSUIJSResult;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:02qGF+VI30iww9i_k+iKfA:/ClientActionFlows.02qGF+VI30iww9i_k+iKfA:vTebM3SRUKaE7a2k+a4fTg", "OutSystemsUI", "IsWebApp", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:GielZ0yGqkW7VIAg9TrmJQ", callContext.id);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:A8C7OkSCkkqYxzxiYRUweA", callContext.id);
checkOSUIJSResult.value = controller.safeExecuteJSNode(OutSystemsUI_controller_IsWebApp_CheckOSUIJS, "CheckOSUI", "IsWebApp", {
IsWebApp: OS.DataConversion.JSNodeParamConverter.to(false, OS.Types.Boolean)
}, function ($parameters) {
var jsNodeResult = new (controller.constructor.getVariableGroupType("OutSystemsUI.IsWebApp$checkOSUIJSResult"))();
jsNodeResult.isWebAppOut = OS.DataConversion.JSNodeParamConverter.from($parameters.IsWebApp, OS.Types.Boolean);
return jsNodeResult;
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:e0xiL7IHIkuRGzAdAPR3hw", callContext.id);
// IsWebApp = CheckOSUI.IsWebApp
outVars.value.isWebAppOut = checkOSUIJSResult.value.isWebAppOut;
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:++p8oBPhkEiRVivVDh0l0A", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:02qGF+VI30iww9i_k+iKfA", callContext.id);
}

};
var controller = OutSystemsUIController.default;
OutSystemsUIController.default.constructor.registerVariableGroupType("OutSystemsUI.IsWebApp$checkOSUIJSResult", [{
name: "IsWebApp",
attrName: "isWebAppOut",
mandatory: true,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
OutSystemsUIController.default.constructor.registerVariableGroupType("OutSystemsUI.IsWebApp$outVars", [{
name: "IsWebApp",
attrName: "isWebAppOut",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
OutSystemsUIController.default.clientActionProxies.isWebApp$Action = function () {
return controller.executeActionInsideJSNode(OutSystemsUIController.default.isWebApp$Action.bind(controller), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
IsWebApp: OS.DataConversion.JSNodeParamConverter.to(actionResults.isWebAppOut, OS.Types.Boolean)
};
});
};
});
define("OutSystemsUI.controller$IsWebApp.CheckOSUIJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
var isWebApp = document.querySelector('.active-screen .layout.layout-top') || document.querySelector('.active-screen .layout.layout-side') || document.querySelector('.active-screen .layout-blank');

if(isWebApp) {
    $parameters.IsWebApp = true;
}

};
});

define("OutSystemsUI.controller$LayoutReadyMobile", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.controller", "OutSystemsUI.controller$iPhoneXPreview", "OutSystemsUI.controller$FixInputs", "OutSystemsUI.controller$DeviceDetection", "OutSystemsUI.controller$HideHeader"], function (exports, OutSystems, OutSystemsUIModel, OutSystemsUIController) {
var OS = OutSystems.Internal;
OutSystemsUIController.default.layoutReadyMobile$Action = function (hideHeaderOnScrollIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsUI.LayoutReadyMobile$vars"))());
vars.value.hideHeaderOnScrollInLocal = hideHeaderOnScrollIn;
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:gMQKaTC8KUWmUEZZexJTUA:/ClientActionFlows.gMQKaTC8KUWmUEZZexJTUA:6BYTsrX3jp8xrk5RKrR6MA", "OutSystemsUI", "LayoutReadyMobile", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:nv6CGv91ZEC553LJXqmGZg", callContext.id);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:vBVwkeGXhUWn8nVijd41Fg", callContext.id);
// Execute Action: DeviceDetection
OutSystemsUIController.default.deviceDetection$Action(callContext);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:e3SDeDlqWUuEd2GHxB8F_w", callContext.id);
// Execute Action: iPhoneXPreview
OutSystemsUIController.default.iPhoneXPreview$Action(callContext);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:E7sEqVzT0ECAYxEv56NPlw", callContext.id);
// Execute Action: HideHeader
OutSystemsUIController.default.hideHeader$Action(vars.value.hideHeaderOnScrollInLocal, callContext);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:Ly3djGDLQ0eI92tAbDMTAw", callContext.id);
// Execute Action: FixInputs
OutSystemsUIController.default.fixInputs$Action(callContext);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:xz_lS09TxkawPtD9+erq_A", callContext.id);
return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:gMQKaTC8KUWmUEZZexJTUA", callContext.id);
}

};
var controller = OutSystemsUIController.default;
OutSystemsUIController.default.constructor.registerVariableGroupType("OutSystemsUI.LayoutReadyMobile$vars", [{
name: "HideHeaderOnScroll",
attrName: "hideHeaderOnScrollInLocal",
mandatory: true,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
OutSystemsUIController.default.clientActionProxies.layoutReadyMobile$Action = function (hideHeaderOnScrollIn) {
hideHeaderOnScrollIn = (hideHeaderOnScrollIn === undefined) ? false : hideHeaderOnScrollIn;
return controller.executeActionInsideJSNode(OutSystemsUIController.default.layoutReadyMobile$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(hideHeaderOnScrollIn, OS.Types.Boolean)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});

define("OutSystemsUI.controller$LayoutReadyWeb", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.controller", "OutSystemsUI.controller$LayoutReadyWeb.RunOnStartJS", "OutSystemsUI.controller$FixInputs", "OutSystemsUI.controller$ApplicationStartWeb"], function (exports, OutSystems, OutSystemsUIModel, OutSystemsUIController, OutSystemsUI_controller_LayoutReadyWeb_RunOnStartJS) {
var OS = OutSystems.Internal;
OutSystemsUIController.default.layoutReadyWeb$Action = function (callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:3YPe0a8dvEOq0s0BQKEmYA:/ClientActionFlows.3YPe0a8dvEOq0s0BQKEmYA:zGHuHuRicXpwcESup4CaHw", "OutSystemsUI", "LayoutReadyWeb", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:gGkKczYuTUWJTqZtPQ8ZWw", callContext.id);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:fd7I_BtwWkecM47jRYQwFQ", callContext.id);
controller.safeExecuteJSNode(OutSystemsUI_controller_LayoutReadyWeb_RunOnStartJS, "RunOnStart", "LayoutReadyWeb", null, function ($parameters) {
}, {
ApplicationStartWeb: OutSystemsUIController.default.clientActionProxies.applicationStartWeb$Action
}, {});
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:9bcwgxs8tka6zDwDgHPlfg", callContext.id);
// Execute Action: FixInputs
OutSystemsUIController.default.fixInputs$Action(callContext);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:gSzoQbcWEEqViZ16wV_Brg", callContext.id);
return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:3YPe0a8dvEOq0s0BQKEmYA", callContext.id);
}

};
var controller = OutSystemsUIController.default;
OutSystemsUIController.default.clientActionProxies.layoutReadyWeb$Action = function () {
return controller.executeActionInsideJSNode(OutSystemsUIController.default.layoutReadyWeb$Action.bind(controller), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("OutSystemsUI.controller$LayoutReadyWeb.RunOnStartJS", [], function () {
return function ($actions, $roles, $public) {
// Runs the ApplicationStart action once and flags on a window variable

if(window.applicationStarted === undefined) {
    $actions.ApplicationStartWeb();
    window.applicationStarted = true;
}
};
});

define("OutSystemsUI.controller$ListItemHint", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.controller", "OutSystemsUI.controller$ListItemHint.ListItemAnimateJS"], function (exports, OutSystems, OutSystemsUIModel, OutSystemsUIController, OutSystemsUI_controller_ListItemHint_ListItemAnimateJS) {
var OS = OutSystems.Internal;
OutSystemsUIController.default.listItemHint$Action = function (listIdIn, hasLeftActionIn, hasRightActionIn, animationTimeIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsUI.ListItemHint$vars"))());
vars.value.listIdInLocal = listIdIn;
vars.value.hasLeftActionInLocal = hasLeftActionIn;
vars.value.hasRightActionInLocal = hasRightActionIn;
vars.value.animationTimeInLocal = animationTimeIn;
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:zInTb5waXk6r33Wt42NZGg:/ClientActionFlows.zInTb5waXk6r33Wt42NZGg:oKWrFhIOfyKB70gbfq33+Q", "OutSystemsUI", "ListItemHint", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:TqkjCJNYoUiv3yTkFD6Q_g", callContext.id);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:HI7FczBGrEKwVfINKPZ6vA", callContext.id);
controller.safeExecuteJSNode(OutSystemsUI_controller_ListItemHint_ListItemAnimateJS, "ListItemAnimate", "ListItemHint", {
AnimationTime: OS.DataConversion.JSNodeParamConverter.to(vars.value.animationTimeInLocal, OS.Types.Decimal),
ListId: OS.DataConversion.JSNodeParamConverter.to(vars.value.listIdInLocal, OS.Types.Text),
HasRightAction: OS.DataConversion.JSNodeParamConverter.to(vars.value.hasRightActionInLocal, OS.Types.Boolean),
HasLeftAction: OS.DataConversion.JSNodeParamConverter.to(vars.value.hasLeftActionInLocal, OS.Types.Boolean)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:R5jQfKdCSkuzzP2KGVEAiA", callContext.id);
return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:zInTb5waXk6r33Wt42NZGg", callContext.id);
}

};
var controller = OutSystemsUIController.default;
OutSystemsUIController.default.constructor.registerVariableGroupType("OutSystemsUI.ListItemHint$vars", [{
name: "ListId",
attrName: "listIdInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}, {
name: "HasLeftAction",
attrName: "hasLeftActionInLocal",
mandatory: true,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}, {
name: "HasRightAction",
attrName: "hasRightActionInLocal",
mandatory: true,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}, {
name: "AnimationTime",
attrName: "animationTimeInLocal",
mandatory: true,
dataType: OS.Types.Decimal,
defaultValue: function () {
return OS.DataTypes.Decimal.defaultValue;
}
}]);
OutSystemsUIController.default.clientActionProxies.listItemHint$Action = function (listIdIn, hasLeftActionIn, hasRightActionIn, animationTimeIn) {
listIdIn = (listIdIn === undefined) ? "" : listIdIn;
hasLeftActionIn = (hasLeftActionIn === undefined) ? false : hasLeftActionIn;
hasRightActionIn = (hasRightActionIn === undefined) ? false : hasRightActionIn;
animationTimeIn = (animationTimeIn === undefined) ? OS.DataTypes.Decimal.defaultValue : animationTimeIn;
return controller.executeActionInsideJSNode(OutSystemsUIController.default.listItemHint$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(listIdIn, OS.Types.Text), OS.DataConversion.JSNodeParamConverter.from(hasLeftActionIn, OS.Types.Boolean), OS.DataConversion.JSNodeParamConverter.from(hasRightActionIn, OS.Types.Boolean), OS.DataConversion.JSNodeParamConverter.from(animationTimeIn, OS.Types.Decimal)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("OutSystemsUI.controller$ListItemHint.ListItemAnimateJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
var timeoutVar;
var timeAnimation = $parameters.AnimationTime / 6;

var waitListRender = function() {
    listEl = document.querySelector('#' + $parameters.ListId);

    if(!listEl.classList.contains('list-loading')) { 
        listAnimateItems();
        clearTimeout(timeoutVar);
    } else {
        timeoutVar = setTimeout(waitListRender, 50);
    }
};

var listAnimateItems = function() {
    setTimeout(function(){
        listElement = document.getElementById($parameters.ListId).childNodes[1];
        listItemContentLeft = listElement.querySelector('.active-screen .list-item-left-actions');
        listItemContentRight = listElement.querySelector('.active-screen .list-item-right-actions');
        
        listElement.style.pointerEvents = 'none';
        
        if($parameters.HasLeftAction && $parameters.HasRightAction || $parameters.HasLeftAction) {
            listItemContentLeft.classList.add('has-content-animation');
            listItemContentLeft.setAttribute('style', 'width:75px; transition: all ' + timeAnimation + 'ms !important;');
            
            setTimeout(function(){
                listItemContentLeft.style.width = '';
                
                listItemContentLeft.addEventListener("transitionend", function(event) {
                    listItemContentLeft.classList.remove('has-content-animation');
                    listItemContentLeft.removeAttribute('style');
                    listElement.style.pointerEvents = '';
                }, false);
                
            },timeAnimation * 3);
            
        } else if($parameters.HasRightAction) {
            listItemContentRight.classList.add('has-content-animation-right');
            listItemContentRight.setAttribute('style', 'width:75px; transition: all ' + timeAnimation + 'ms !important; height: ' + listElement.offsetHeight + 'px;');
            
            setTimeout(function(){
                listItemContentRight.style.width = '';
                
                listItemContentRight.addEventListener("transitionend", function(event) {
                    listItemContentRight.classList.remove('has-content-animation-right');
                    listItemContentRight.removeAttribute('style');
                    listElement.style.pointerEvents = '';
                }, false);

            }, timeAnimation * 3);
        }    
    },timeAnimation); // waiting for screen transition ends
};

waitListRender();

};
});

define("OutSystemsUI.controller$MenuHide", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.controller", "OutSystemsUI.controller$MenuHide.ToggleLayoutClassJS"], function (exports, OutSystems, OutSystemsUIModel, OutSystemsUIController, OutSystemsUI_controller_MenuHide_ToggleLayoutClassJS) {
var OS = OutSystems.Internal;
OutSystemsUIController.default.menuHide$Action = function (callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:rTUt1ZeC60SXXTbA17bXvg:/ClientActionFlows.rTUt1ZeC60SXXTbA17bXvg:V2X19oDw+g9iVdeOC14Rdw", "OutSystemsUI", "MenuHide", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:GDX+rV1O5kq12XItQlSn0Q", callContext.id);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:9md9YTHjZkiZZN3suuWnkg", callContext.id);
controller.safeExecuteJSNode(OutSystemsUI_controller_MenuHide_ToggleLayoutClassJS, "ToggleLayoutClass", "MenuHide", null, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:MHbbMoVcvUqcZ22JkcaTVA", callContext.id);
return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:rTUt1ZeC60SXXTbA17bXvg", callContext.id);
}

};
var controller = OutSystemsUIController.default;
OutSystemsUIController.default.clientActionProxies.menuHide$Action = function () {
return controller.executeActionInsideJSNode(OutSystemsUIController.default.menuHide$Action.bind(controller), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("OutSystemsUI.controller$MenuHide.ToggleLayoutClassJS", [], function () {
return function ($actions, $roles, $public) {
var menu = document.querySelector('.menu');
var appMenu = document.querySelector('.app-menu-container');
var menuOverlay = document.querySelector('.menu-background');

menu.classList.remove('menu--visible');

 if(menuOverlay) {
        menuOverlay.style.opacity = "";
}

appMenu.style.transform =  "";
appMenu.style.webkitTransform =  "";

function OnTransitionEnd() {
    menu.classList.remove('menu--animatable');
    
    menu.removeEventListener("transitionend", OnTransitionEnd);
}

menu.addEventListener("transitionend", OnTransitionEnd, false);
};
});

define("OutSystemsUI.controller$MenuShow", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.controller", "OutSystemsUI.controller$MenuShow.ToggleLayoutClassJS"], function (exports, OutSystems, OutSystemsUIModel, OutSystemsUIController, OutSystemsUI_controller_MenuShow_ToggleLayoutClassJS) {
var OS = OutSystems.Internal;
OutSystemsUIController.default.menuShow$Action = function (callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:kaZY_xZ0Q0WkzEXP5e61QQ:/ClientActionFlows.kaZY_xZ0Q0WkzEXP5e61QQ:LR3SNhMyehAJYCB9Qmn4eA", "OutSystemsUI", "MenuShow", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:1F_gKW0w3kiU1fVedwTQPA", callContext.id);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:+p4JrADMgEuyMGCRVuSHCA", callContext.id);
controller.safeExecuteJSNode(OutSystemsUI_controller_MenuShow_ToggleLayoutClassJS, "ToggleLayoutClass", "MenuShow", null, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:tLfQai9OfkS9OKvWPJfK5w", callContext.id);
return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:kaZY_xZ0Q0WkzEXP5e61QQ", callContext.id);
}

};
var controller = OutSystemsUIController.default;
OutSystemsUIController.default.clientActionProxies.menuShow$Action = function () {
return controller.executeActionInsideJSNode(OutSystemsUIController.default.menuShow$Action.bind(controller), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("OutSystemsUI.controller$MenuShow.ToggleLayoutClassJS", [], function () {
return function ($actions, $roles, $public) {
var myMenu = document.querySelector(".menu");

myMenu.classList.add('menu--visible');
myMenu.classList.add('menu--animatable');
};
});

define("OutSystemsUI.controller$MoveElement", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.controller", "OutSystemsUI.controller$MoveElement.MoveElementJS"], function (exports, OutSystems, OutSystemsUIModel, OutSystemsUIController, OutSystemsUI_controller_MoveElement_MoveElementJS) {
var OS = OutSystems.Internal;
OutSystemsUIController.default.moveElement$Action = function (widgetIDIn, targetIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsUI.MoveElement$vars"))());
vars.value.widgetIDInLocal = widgetIDIn;
vars.value.targetInLocal = targetIn;
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:fKauCzBE8E+Jnb0QL5gRGQ:/ClientActionFlows.fKauCzBE8E+Jnb0QL5gRGQ:8WpESp+7t2849CNeYVszpg", "OutSystemsUI", "MoveElement", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:X4j8W89180G23LxsRYkLpA", callContext.id);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:ys785lY_qE6ziCYEBGOpgw", callContext.id);
controller.safeExecuteJSNode(OutSystemsUI_controller_MoveElement_MoveElementJS, "MoveElement", "MoveElement", {
Target: OS.DataConversion.JSNodeParamConverter.to(vars.value.targetInLocal, OS.Types.Object),
Element: OS.DataConversion.JSNodeParamConverter.to(vars.value.widgetIDInLocal, OS.Types.Object)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:oolQX8C0XUGcbQqdZ6H8Hg", callContext.id);
return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:fKauCzBE8E+Jnb0QL5gRGQ", callContext.id);
}

};
var controller = OutSystemsUIController.default;
OutSystemsUIController.default.constructor.registerVariableGroupType("OutSystemsUI.MoveElement$vars", [{
name: "WidgetID",
attrName: "widgetIDInLocal",
mandatory: true,
dataType: OS.Types.Object,
defaultValue: function () {
return null;
}
}, {
name: "Target",
attrName: "targetInLocal",
mandatory: true,
dataType: OS.Types.Object,
defaultValue: function () {
return null;
}
}]);
OutSystemsUIController.default.clientActionProxies.moveElement$Action = function (widgetIDIn, targetIn) {
widgetIDIn = (widgetIDIn === undefined) ? null : widgetIDIn;
targetIn = (targetIn === undefined) ? null : targetIn;
return controller.executeActionInsideJSNode(OutSystemsUIController.default.moveElement$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(widgetIDIn, OS.Types.Object), OS.DataConversion.JSNodeParamConverter.from(targetIn, OS.Types.Object)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("OutSystemsUI.controller$MoveElement.MoveElementJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
if($parameters.Target && $parameters.Element) {
    var screenEl = document.getElementById($parameters.Element);
    var element = document.querySelector($parameters.Target);
    
    if(screenEl && element) {
        element.appendChild(screenEl);
    }
}
};
});

define("OutSystemsUI.controller$SetActiveElement", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.controller", "OutSystemsUI.controller$SetActiveElement.SetActiveElementJS"], function (exports, OutSystems, OutSystemsUIModel, OutSystemsUIController, OutSystemsUI_controller_SetActiveElement_SetActiveElementJS) {
var OS = OutSystems.Internal;
OutSystemsUIController.default.setActiveElement$Action = function (widgetIdIn, isActiveIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsUI.SetActiveElement$vars"))());
vars.value.widgetIdInLocal = widgetIdIn;
vars.value.isActiveInLocal = isActiveIn;
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:WkrqyYiP70KuHnjgeUkWGg:/ClientActionFlows.WkrqyYiP70KuHnjgeUkWGg:FTJ_0dnokC_tAWfj9Mh+jA", "OutSystemsUI", "SetActiveElement", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:njUly_cwd0Khl3g1Ftrcng", callContext.id);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:IO79uJFMWEeJUfqEirGmkg", callContext.id);
controller.safeExecuteJSNode(OutSystemsUI_controller_SetActiveElement_SetActiveElementJS, "SetActiveElement", "SetActiveElement", {
IsActive: OS.DataConversion.JSNodeParamConverter.to(vars.value.isActiveInLocal, OS.Types.Boolean),
ID: OS.DataConversion.JSNodeParamConverter.to(vars.value.widgetIdInLocal, OS.Types.Text)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:GWR2eHd5v0GLCZnFxKd8bQ", callContext.id);
return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:WkrqyYiP70KuHnjgeUkWGg", callContext.id);
}

};
var controller = OutSystemsUIController.default;
OutSystemsUIController.default.constructor.registerVariableGroupType("OutSystemsUI.SetActiveElement$vars", [{
name: "WidgetId",
attrName: "widgetIdInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}, {
name: "IsActive",
attrName: "isActiveInLocal",
mandatory: true,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
OutSystemsUIController.default.clientActionProxies.setActiveElement$Action = function (widgetIdIn, isActiveIn) {
widgetIdIn = (widgetIdIn === undefined) ? "" : widgetIdIn;
isActiveIn = (isActiveIn === undefined) ? false : isActiveIn;
return controller.executeActionInsideJSNode(OutSystemsUIController.default.setActiveElement$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(widgetIdIn, OS.Types.Text), OS.DataConversion.JSNodeParamConverter.from(isActiveIn, OS.Types.Boolean)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("OutSystemsUI.controller$SetActiveElement.SetActiveElementJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
var elem = document.getElementById($parameters.ID);

if($parameters.IsActive) {
    elem.classList.add('active-element');    
} else {
    elem.classList.remove('active-element');
}
};
});

define("OutSystemsUI.controller$SetActiveMenuItems", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.controller", "OutSystemsUI.controller$SetActiveMenuItems.SetActiveJS"], function (exports, OutSystems, OutSystemsUIModel, OutSystemsUIController, OutSystemsUI_controller_SetActiveMenuItems_SetActiveJS) {
var OS = OutSystems.Internal;
OutSystemsUIController.default.setActiveMenuItems$Action = function (activeItemIn, activeSubItemIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsUI.SetActiveMenuItems$vars"))());
vars.value.activeItemInLocal = activeItemIn;
vars.value.activeSubItemInLocal = activeSubItemIn;
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:uHyStiD+ZkKHYmlhJmLnAQ:/ClientActionFlows.uHyStiD+ZkKHYmlhJmLnAQ:pi2vR2frXLwTZF1n1m2uLw", "OutSystemsUI", "SetActiveMenuItems", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:vYg7WslDaUaY2sGvqQla_w", callContext.id);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:uauiLqkNdU2Vr4TlJvBStA", callContext.id);
controller.safeExecuteJSNode(OutSystemsUI_controller_SetActiveMenuItems_SetActiveJS, "SetActive", "SetActiveMenuItems", {
ActiveItem: OS.DataConversion.JSNodeParamConverter.to(vars.value.activeItemInLocal, OS.Types.Integer),
ActiveSubItem: OS.DataConversion.JSNodeParamConverter.to(vars.value.activeSubItemInLocal, OS.Types.Integer)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:xlMASpfuCES1HtjwT6+7QQ", callContext.id);
return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:uHyStiD+ZkKHYmlhJmLnAQ", callContext.id);
}

};
var controller = OutSystemsUIController.default;
OutSystemsUIController.default.constructor.registerVariableGroupType("OutSystemsUI.SetActiveMenuItems$vars", [{
name: "ActiveItem",
attrName: "activeItemInLocal",
mandatory: false,
dataType: OS.Types.Integer,
defaultValue: function () {
return -1;
}
}, {
name: "ActiveSubItem",
attrName: "activeSubItemInLocal",
mandatory: false,
dataType: OS.Types.Integer,
defaultValue: function () {
return -1;
}
}]);
OutSystemsUIController.default.clientActionProxies.setActiveMenuItems$Action = function (activeItemIn, activeSubItemIn) {
activeItemIn = (activeItemIn === undefined) ? -1 : activeItemIn;
activeSubItemIn = (activeSubItemIn === undefined) ? -1 : activeSubItemIn;
return controller.executeActionInsideJSNode(OutSystemsUIController.default.setActiveMenuItems$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(activeItemIn, OS.Types.Integer), OS.DataConversion.JSNodeParamConverter.from(activeSubItemIn, OS.Types.Integer)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("OutSystemsUI.controller$SetActiveMenuItems.SetActiveJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
var appMenuLinks = document.querySelector('.app-menu-links');

if(appMenuLinks) {
    var activeLinkBlock = appMenuLinks.children[$parameters.ActiveItem];
    
    if(activeLinkBlock) {
        activeLinkBlock.classList.add("active");
        var activeSubMenu = activeLinkBlock.querySelector('.submenu');
        
        if(activeSubMenu) {
            activeSubMenu.classList.add("active");
            var activeSubMenuItem = activeSubMenu.querySelector('.submenu-items').children[$parameters.ActiveSubItem];
            
            if(activeSubMenuItem) {
                activeSubMenuItem.classList.add("active");
            }
        }
    }
}
};
});

define("OutSystemsUI.controller$SetDeviceBreakpoints", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.controller", "OutSystemsUI.controller$SetDeviceBreakpoints.SetDeviceOnResizeJS", "OutSystemsUI.model$DeviceConfigurationRec"], function (exports, OutSystems, OutSystemsUIModel, OutSystemsUIController, OutSystemsUI_controller_SetDeviceBreakpoints_SetDeviceOnResizeJS) {
var OS = OutSystems.Internal;
OutSystemsUIController.default.setDeviceBreakpoints$Action = function (deviceConfigurationIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsUI.SetDeviceBreakpoints$vars"))());
vars.value.deviceConfigurationInLocal = deviceConfigurationIn.clone();
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:kzLCurPnyEiZZBS7mNwWSA:/ClientActionFlows.kzLCurPnyEiZZBS7mNwWSA:ZepTTbMx_Px8ivPLrK9DJg", "OutSystemsUI", "SetDeviceBreakpoints", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:ZFkpLrDlmEeaDRVWUDxnXA", callContext.id);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:VoR2nu8KDUyBS7WGi_Ed1w", callContext.id);
controller.safeExecuteJSNode(OutSystemsUI_controller_SetDeviceBreakpoints_SetDeviceOnResizeJS, "SetDeviceOnResize", "SetDeviceBreakpoints", {
Phone: OS.DataConversion.JSNodeParamConverter.to(vars.value.deviceConfigurationInLocal.phoneWidthAttr, OS.Types.Integer),
Tablet: OS.DataConversion.JSNodeParamConverter.to(vars.value.deviceConfigurationInLocal.tabletWidthAttr, OS.Types.Integer)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:3F+2DIwLeUW4IU_xmn+BDg", callContext.id);
return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:kzLCurPnyEiZZBS7mNwWSA", callContext.id);
}

};
var controller = OutSystemsUIController.default;
OutSystemsUIController.default.constructor.registerVariableGroupType("OutSystemsUI.SetDeviceBreakpoints$vars", [{
name: "DeviceConfiguration",
attrName: "deviceConfigurationInLocal",
mandatory: true,
dataType: OS.Types.Record,
defaultValue: function () {
return new OutSystemsUIModel.DeviceConfigurationRec();
},
complexType: OutSystemsUIModel.DeviceConfigurationRec
}]);
OutSystemsUIController.default.clientActionProxies.setDeviceBreakpoints$Action = function (deviceConfigurationIn) {
deviceConfigurationIn = (deviceConfigurationIn === undefined) ? new OutSystemsUIModel.DeviceConfigurationRec() : deviceConfigurationIn;
return controller.executeActionInsideJSNode(OutSystemsUIController.default.setDeviceBreakpoints$Action.bind(controller, deviceConfigurationIn), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("OutSystemsUI.controller$SetDeviceBreakpoints.SetDeviceOnResizeJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
$public.View.registerDeviceClassGetter(function() {
    
    var deviceList;
    var userValues;
    var device;
    var body = document.body;
    var isLandscape = body.classList.contains("landscape");
    var windowWidth = window.innerWidth || document.documentElement.clientWidth;
    var windowHeight = window.innerHeight || document.documentElement.clientHeight;
    
    userValues = {
        phone: $parameters.Phone,
        tablet: $parameters.Tablet,
    };
    
    var phoneMax = userValues.phone ? userValues.phone : 700;
    var tabletMax = userValues.tablet ? userValues.tablet : 1024;
    var desktopMax =  1366;
   
    deviceList = ["phone", "tablet","desktop"];
    
    switch(true) {
        case (windowWidth < phoneMax || (!isLandscape && windowHeight < phoneMax)):
            device = 0;
            break;
        case ((windowWidth >= phoneMax && windowWidth <= tabletMax) || (windowHeight >= phoneMax && windowHeight <= tabletMax && isLandscape)):
            device = 1;
            break;
        case (windowWidth > tabletMax ||(windowHeight > tabletMax && windowHeight < desktopMax && isLandscape)):  
            device = 2;
            break;
    }
    
   
   var orient = windowWidth > windowHeight ? "landscape" : "portrait";
   
   return [orient, deviceList[device]];
   
});

};
});

define("OutSystemsUI.controller$SetMenuIcon", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.controller", "OutSystemsUI.controller$SetMenuIcon.FindMenuLinksJS"], function (exports, OutSystems, OutSystemsUIModel, OutSystemsUIController, OutSystemsUI_controller_SetMenuIcon_FindMenuLinksJS) {
var OS = OutSystems.Internal;
OutSystemsUIController.default.setMenuIcon$Action = function (menuActionIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsUI.SetMenuIcon$vars"))());
vars.value.menuActionInLocal = menuActionIn;
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:ZETeHV+it0+N0my823scLA:/ClientActionFlows.ZETeHV+it0+N0my823scLA:j2Fucvjjc3lgi6OmrT3VxQ", "OutSystemsUI", "SetMenuIcon", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:NmF_8AW1KkGeiFIvO9blhA", callContext.id);
// Auto?
if((OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:ZKUCOQN2MU6NhBsUtij4aw", callContext.id) && (vars.value.menuActionInLocal === OutSystemsUIModel.staticEntities.menuAction.auto))) {
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:u1xwWmjOrUmCUq_MktIlVg", callContext.id);
controller.safeExecuteJSNode(OutSystemsUI_controller_SetMenuIcon_FindMenuLinksJS, "FindMenuLinks", "SetMenuIcon", null, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:pJbaDv6PLE2VHW9iYjYl2Q", callContext.id);
} else {
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:rXkEjvPVHkmK4GMFMM9AuQ", callContext.id);
}

return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:ZETeHV+it0+N0my823scLA", callContext.id);
}

};
var controller = OutSystemsUIController.default;
OutSystemsUIController.default.constructor.registerVariableGroupType("OutSystemsUI.SetMenuIcon$vars", [{
name: "MenuAction",
attrName: "menuActionInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
OutSystemsUIController.default.clientActionProxies.setMenuIcon$Action = function (menuActionIn) {
menuActionIn = (menuActionIn === undefined) ? "" : menuActionIn;
return controller.executeActionInsideJSNode(OutSystemsUIController.default.setMenuIcon$Action.bind(controller, menuActionIn), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("OutSystemsUI.controller$SetMenuIcon.FindMenuLinksJS", [], function () {
return function ($actions, $roles, $public) {
var appMenu = Array.prototype.slice.call(document.querySelectorAll(".bottom-bar a")),
    bottomBar = Array.prototype.slice.call(document.querySelectorAll(".app-menu a"))

var links = appMenu.concat(bottomBar);

var showMenu = false;

for (var i = 0; i < links.length; i++) {
    /* removing platform timestamps */
    var timestampIndex = window.location.href.indexOf("_ts")-1;
    var currentPage = timestampIndex > 0 ? window.location.href.substring(0, timestampIndex) : window.location.href;
    if(links[i].attributes["href"]) {
        if (currentPage.indexOf(links[i].attributes["href"].value) >= 0 || 
            currentPage[currentPage.length-1] === "/") {
            showMenu = (window.history ? window.history.length > 0 : true);        
        }
    }
}

if(showMenu) {
    document.querySelector(".app-menu-icon").classList.remove('back');
} else {
    document.querySelector(".app-menu-icon").classList.add('back');
}
};
});

define("OutSystemsUI.controller$SetSelectedTableRow", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.controller", "OutSystemsUI.controller$SetSelectedTableRow.SetSelectedRowJS"], function (exports, OutSystems, OutSystemsUIModel, OutSystemsUIController, OutSystemsUI_controller_SetSelectedTableRow_SetSelectedRowJS) {
var OS = OutSystems.Internal;
OutSystemsUIController.default.setSelectedTableRow$Action = function (tableIdIn, rowNumberIn, isSelectedIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsUI.SetSelectedTableRow$vars"))());
vars.value.tableIdInLocal = tableIdIn;
vars.value.rowNumberInLocal = rowNumberIn;
vars.value.isSelectedInLocal = isSelectedIn;
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:6iLdt8t_ZUOkaPCUy9o4OQ:/ClientActionFlows.6iLdt8t_ZUOkaPCUy9o4OQ:i+CdwWWonTfjUWNctMrD5g", "OutSystemsUI", "SetSelectedTableRow", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:Xy8qMy44yUij3dTCSoXTbw", callContext.id);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:ATatOzJqo0u2ApIml90UFg", callContext.id);
controller.safeExecuteJSNode(OutSystemsUI_controller_SetSelectedTableRow_SetSelectedRowJS, "SetSelectedRow", "SetSelectedTableRow", {
Value: OS.DataConversion.JSNodeParamConverter.to(vars.value.isSelectedInLocal, OS.Types.Boolean),
RowNumber: OS.DataConversion.JSNodeParamConverter.to(vars.value.rowNumberInLocal, OS.Types.Integer),
WidgetId: OS.DataConversion.JSNodeParamConverter.to(vars.value.tableIdInLocal, OS.Types.Text)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:wvnnWu9em0iOBY6Et5Hw+w", callContext.id);
return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:6iLdt8t_ZUOkaPCUy9o4OQ", callContext.id);
}

};
var controller = OutSystemsUIController.default;
OutSystemsUIController.default.constructor.registerVariableGroupType("OutSystemsUI.SetSelectedTableRow$vars", [{
name: "TableId",
attrName: "tableIdInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}, {
name: "RowNumber",
attrName: "rowNumberInLocal",
mandatory: true,
dataType: OS.Types.Integer,
defaultValue: function () {
return 0;
}
}, {
name: "IsSelected",
attrName: "isSelectedInLocal",
mandatory: true,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
OutSystemsUIController.default.clientActionProxies.setSelectedTableRow$Action = function (tableIdIn, rowNumberIn, isSelectedIn) {
tableIdIn = (tableIdIn === undefined) ? "" : tableIdIn;
rowNumberIn = (rowNumberIn === undefined) ? 0 : rowNumberIn;
isSelectedIn = (isSelectedIn === undefined) ? false : isSelectedIn;
return controller.executeActionInsideJSNode(OutSystemsUIController.default.setSelectedTableRow$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(tableIdIn, OS.Types.Text), OS.DataConversion.JSNodeParamConverter.from(rowNumberIn, OS.Types.Integer), OS.DataConversion.JSNodeParamConverter.from(isSelectedIn, OS.Types.Boolean)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("OutSystemsUI.controller$SetSelectedTableRow.SetSelectedRowJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
var table = document.getElementById($parameters.WidgetId);

var tableRow = table.querySelectorAll('.table-row');

if(tableRow[$parameters.RowNumber]) {
    if($parameters.Value) {
        tableRow[$parameters.RowNumber].classList.add('table-row-selected');    
    } else {
        tableRow[$parameters.RowNumber].classList.remove('table-row-selected');    
    }
}



};
});

define("OutSystemsUI.controller$ShowPassword", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.controller", "OutSystemsUI.controller$ShowPassword.ShowPasswordJS"], function (exports, OutSystems, OutSystemsUIModel, OutSystemsUIController, OutSystemsUI_controller_ShowPassword_ShowPasswordJS) {
var OS = OutSystems.Internal;
OutSystemsUIController.default.showPassword$Action = function (callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:IPzU9ikG0ESQIuRuOj5wDw:/ClientActionFlows.IPzU9ikG0ESQIuRuOj5wDw:HqmytqiblSO_B0NvBWwjUw", "OutSystemsUI", "ShowPassword", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:PKLSaVAA3Ueb1liPdD5UMg", callContext.id);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:bxp8S_H10kKMTwwJmoLfTQ", callContext.id);
controller.safeExecuteJSNode(OutSystemsUI_controller_ShowPassword_ShowPasswordJS, "ShowPassword", "ShowPassword", null, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:TOjICRQzdEKCDowrukraiQ", callContext.id);
return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:IPzU9ikG0ESQIuRuOj5wDw", callContext.id);
}

};
var controller = OutSystemsUIController.default;
OutSystemsUIController.default.clientActionProxies.showPassword$Action = function () {
return controller.executeActionInsideJSNode(OutSystemsUIController.default.showPassword$Action.bind(controller), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("OutSystemsUI.controller$ShowPassword.ShowPasswordJS", [], function () {
return function ($actions, $roles, $public) {
var inputPassword = document.querySelector('.login-password');

var typeInputPassword = inputPassword.type;

if(typeInputPassword === 'password') {
    inputPassword.setAttribute('type', 'text');
} else {
    inputPassword.setAttribute('type', 'password');   
}
};
});

define("OutSystemsUI.controller$SidebarToggle", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.controller", "OutSystemsUI.controller$SidebarToggle.ToggleSidebarJS"], function (exports, OutSystems, OutSystemsUIModel, OutSystemsUIController, OutSystemsUI_controller_SidebarToggle_ToggleSidebarJS) {
var OS = OutSystems.Internal;
OutSystemsUIController.default.sidebarToggle$Action = function (widgetIdIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsUI.SidebarToggle$vars"))());
vars.value.widgetIdInLocal = widgetIdIn;
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:qit9KmBqB0mQXaPFQSKnRg:/ClientActionFlows.qit9KmBqB0mQXaPFQSKnRg:ynHUceMpS3DBbzA3jG7B0w", "OutSystemsUI", "SidebarToggle", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:8esdRllSMUqw9Hqhwp+AdQ", callContext.id);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:jaHB+obidUu+wcGD9DdGOw", callContext.id);
controller.safeExecuteJSNode(OutSystemsUI_controller_SidebarToggle_ToggleSidebarJS, "ToggleSidebar", "SidebarToggle", {
WidgetId: OS.DataConversion.JSNodeParamConverter.to(vars.value.widgetIdInLocal, OS.Types.Text)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:JRPe6doJ_kS6syI0E_xQkA", callContext.id);
return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:qit9KmBqB0mQXaPFQSKnRg", callContext.id);
}

};
var controller = OutSystemsUIController.default;
OutSystemsUIController.default.constructor.registerVariableGroupType("OutSystemsUI.SidebarToggle$vars", [{
name: "WidgetId",
attrName: "widgetIdInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
OutSystemsUIController.default.clientActionProxies.sidebarToggle$Action = function (widgetIdIn) {
widgetIdIn = (widgetIdIn === undefined) ? "" : widgetIdIn;
return controller.executeActionInsideJSNode(OutSystemsUIController.default.sidebarToggle$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(widgetIdIn, OS.Types.Text)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("OutSystemsUI.controller$SidebarToggle.ToggleSidebarJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
// toggle Sidebar

var el;
var isOpen;

if($parameters.WidgetId !== "") {
    el = document.querySelector("#" + $parameters.WidgetId + " .sidebar");
}

if(el !== null) {
    isOpen = el.classList.contains("sidebar-open");
    
    if(isOpen) {
        el.classList.remove("sidebar-open");
    } else {
        el.classList.add("sidebar-open");
    }
}
};
});

define("OutSystemsUI.controller$StackedCardsSwipeLeft", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.controller", "OutSystemsUI.controller$StackedCardsSwipeLeft.SwipeLeftJS"], function (exports, OutSystems, OutSystemsUIModel, OutSystemsUIController, OutSystemsUI_controller_StackedCardsSwipeLeft_SwipeLeftJS) {
var OS = OutSystems.Internal;
OutSystemsUIController.default.stackedCardsSwipeLeft$Action = function (widgetIdIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsUI.StackedCardsSwipeLeft$vars"))());
vars.value.widgetIdInLocal = widgetIdIn;
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:fk74nHYtG0aQv3rJupL3Yg:/ClientActionFlows.fk74nHYtG0aQv3rJupL3Yg:9PmvKzTtJczMu5bSZKBJHA", "OutSystemsUI", "StackedCardsSwipeLeft", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:s+iPGCWs_k+MMYfN3ziU3Q", callContext.id);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:bYAjhTuI_UCBz++CrCJsBg", callContext.id);
controller.safeExecuteJSNode(OutSystemsUI_controller_StackedCardsSwipeLeft_SwipeLeftJS, "SwipeLeft", "StackedCardsSwipeLeft", {
WidgetId: OS.DataConversion.JSNodeParamConverter.to(vars.value.widgetIdInLocal, OS.Types.Text)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:1c7eHc5sLkWMsIBVVyheOw", callContext.id);
return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:fk74nHYtG0aQv3rJupL3Yg", callContext.id);
}

};
var controller = OutSystemsUIController.default;
OutSystemsUIController.default.constructor.registerVariableGroupType("OutSystemsUI.StackedCardsSwipeLeft$vars", [{
name: "WidgetId",
attrName: "widgetIdInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
OutSystemsUIController.default.clientActionProxies.stackedCardsSwipeLeft$Action = function (widgetIdIn) {
widgetIdIn = (widgetIdIn === undefined) ? "" : widgetIdIn;
return controller.executeActionInsideJSNode(OutSystemsUIController.default.stackedCardsSwipeLeft$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(widgetIdIn, OS.Types.Text)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("OutSystemsUI.controller$StackedCardsSwipeLeft.SwipeLeftJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
var element;

var swipeActionInterval = setInterval(function(){
    
    element = document.getElementById($parameters.WidgetId);

    if( element !== null) {
        element.querySelector('.stackedcards-container').leftAction();
        clearInterval(swipeActionInterval);
    }
    
}, 100)
};
});

define("OutSystemsUI.controller$StackedCardsSwipeRight", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.controller", "OutSystemsUI.controller$StackedCardsSwipeRight.SwipeRightJS"], function (exports, OutSystems, OutSystemsUIModel, OutSystemsUIController, OutSystemsUI_controller_StackedCardsSwipeRight_SwipeRightJS) {
var OS = OutSystems.Internal;
OutSystemsUIController.default.stackedCardsSwipeRight$Action = function (widgetIdIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsUI.StackedCardsSwipeRight$vars"))());
vars.value.widgetIdInLocal = widgetIdIn;
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:6tQbuDWdOEWMYpjaBjycWw:/ClientActionFlows.6tQbuDWdOEWMYpjaBjycWw:bVlhJ11T7x_3hNPHRpOCdA", "OutSystemsUI", "StackedCardsSwipeRight", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:VuD5cPGfhkeiduZM4nLpWQ", callContext.id);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:NdVbtmiNvESSTFMxbhkzFA", callContext.id);
controller.safeExecuteJSNode(OutSystemsUI_controller_StackedCardsSwipeRight_SwipeRightJS, "SwipeRight", "StackedCardsSwipeRight", {
WidgetId: OS.DataConversion.JSNodeParamConverter.to(vars.value.widgetIdInLocal, OS.Types.Text)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:WNVQ6nuIvkGGt1RcEa_mpg", callContext.id);
return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:6tQbuDWdOEWMYpjaBjycWw", callContext.id);
}

};
var controller = OutSystemsUIController.default;
OutSystemsUIController.default.constructor.registerVariableGroupType("OutSystemsUI.StackedCardsSwipeRight$vars", [{
name: "WidgetId",
attrName: "widgetIdInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
OutSystemsUIController.default.clientActionProxies.stackedCardsSwipeRight$Action = function (widgetIdIn) {
widgetIdIn = (widgetIdIn === undefined) ? "" : widgetIdIn;
return controller.executeActionInsideJSNode(OutSystemsUIController.default.stackedCardsSwipeRight$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(widgetIdIn, OS.Types.Text)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("OutSystemsUI.controller$StackedCardsSwipeRight.SwipeRightJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
var element;

var swipeActionInterval = setInterval(function(){
    
    element = document.getElementById($parameters.WidgetId);

    if( element !== null) {
        element.querySelector('.stackedcards-container').rightAction();
        clearInterval(swipeActionInterval);
    }
    
}, 100)
};
});

define("OutSystemsUI.controller$StackedCardsSwipeTop", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.controller", "OutSystemsUI.controller$StackedCardsSwipeTop.SwipeTopJS"], function (exports, OutSystems, OutSystemsUIModel, OutSystemsUIController, OutSystemsUI_controller_StackedCardsSwipeTop_SwipeTopJS) {
var OS = OutSystems.Internal;
OutSystemsUIController.default.stackedCardsSwipeTop$Action = function (widgetIdIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsUI.StackedCardsSwipeTop$vars"))());
vars.value.widgetIdInLocal = widgetIdIn;
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:8YOsHAWvHESA5NDmbFugGA:/ClientActionFlows.8YOsHAWvHESA5NDmbFugGA:NB+6PhpJrH3mOakIV4Ugug", "OutSystemsUI", "StackedCardsSwipeTop", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:QM9QmX8J80OsfJOs1nLE0w", callContext.id);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:VGBdXlToIUWYcJSWS4uVRg", callContext.id);
controller.safeExecuteJSNode(OutSystemsUI_controller_StackedCardsSwipeTop_SwipeTopJS, "SwipeTop", "StackedCardsSwipeTop", {
WidgetId: OS.DataConversion.JSNodeParamConverter.to(vars.value.widgetIdInLocal, OS.Types.Text)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:_UhNcUdIkEWxi1lLtcZXcA", callContext.id);
return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:8YOsHAWvHESA5NDmbFugGA", callContext.id);
}

};
var controller = OutSystemsUIController.default;
OutSystemsUIController.default.constructor.registerVariableGroupType("OutSystemsUI.StackedCardsSwipeTop$vars", [{
name: "WidgetId",
attrName: "widgetIdInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
OutSystemsUIController.default.clientActionProxies.stackedCardsSwipeTop$Action = function (widgetIdIn) {
widgetIdIn = (widgetIdIn === undefined) ? "" : widgetIdIn;
return controller.executeActionInsideJSNode(OutSystemsUIController.default.stackedCardsSwipeTop$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(widgetIdIn, OS.Types.Text)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("OutSystemsUI.controller$StackedCardsSwipeTop.SwipeTopJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
var element;

var swipeActionInterval = setInterval(function(){
    
    element = document.getElementById($parameters.WidgetId);

    if( element !== null) {
        element.querySelector('.stackedcards-container').topAction();
        clearInterval(swipeActionInterval);
    }
    
}, 100)
};
});

define("OutSystemsUI.controller$StackedCardsUpdate", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.controller", "OutSystemsUI.controller$StackedCardsUpdate.UpdateUiJS"], function (exports, OutSystems, OutSystemsUIModel, OutSystemsUIController, OutSystemsUI_controller_StackedCardsUpdate_UpdateUiJS) {
var OS = OutSystems.Internal;
OutSystemsUIController.default.stackedCardsUpdate$Action = function (widgetIdIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsUI.StackedCardsUpdate$vars"))());
vars.value.widgetIdInLocal = widgetIdIn;
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:qVJTiEelwUyyAIZ8YvF0kA:/ClientActionFlows.qVJTiEelwUyyAIZ8YvF0kA:icyWBqa6Z07UEiWpatgjaQ", "OutSystemsUI", "StackedCardsUpdate", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:3o5Fg1Sy30SjMSRtsAXFvQ", callContext.id);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:xMKXLKzze0S3+ZodJF1oqw", callContext.id);
controller.safeExecuteJSNode(OutSystemsUI_controller_StackedCardsUpdate_UpdateUiJS, "UpdateUi", "StackedCardsUpdate", {
WidgetId: OS.DataConversion.JSNodeParamConverter.to(vars.value.widgetIdInLocal, OS.Types.Text)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:2ps+Ax4uM0++BiukTNgv2g", callContext.id);
return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:qVJTiEelwUyyAIZ8YvF0kA", callContext.id);
}

};
var controller = OutSystemsUIController.default;
OutSystemsUIController.default.constructor.registerVariableGroupType("OutSystemsUI.StackedCardsUpdate$vars", [{
name: "WidgetId",
attrName: "widgetIdInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
OutSystemsUIController.default.clientActionProxies.stackedCardsUpdate$Action = function (widgetIdIn) {
widgetIdIn = (widgetIdIn === undefined) ? "" : widgetIdIn;
return controller.executeActionInsideJSNode(OutSystemsUIController.default.stackedCardsUpdate$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(widgetIdIn, OS.Types.Text)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("OutSystemsUI.controller$StackedCardsUpdate.UpdateUiJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
var element = document.getElementById($parameters.WidgetId).querySelector('.stackedcards-container').updateUi();
};
});

define("OutSystemsUI.controller$StartOfflineDataSync", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.controller", "OutSystemsUI.controller$StartOfflineDataSync.CallBlockHandlerJS"], function (exports, OutSystems, OutSystemsUIModel, OutSystemsUIController, OutSystemsUI_controller_StartOfflineDataSync_CallBlockHandlerJS) {
var OS = OutSystems.Internal;
OutSystemsUIController.default.startOfflineDataSync$Action = function (syncUnitIn, discardPendingSyncUnitsIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsUI.StartOfflineDataSync$vars"))());
vars.value.syncUnitInLocal = syncUnitIn;
vars.value.discardPendingSyncUnitsInLocal = discardPendingSyncUnitsIn;
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:6wYKHDHaTk24G0Nx4wSdrQ:/ClientActionFlows.6wYKHDHaTk24G0Nx4wSdrQ:6c+o6y23CS0r6_w8YmX+nA", "OutSystemsUI", "StartOfflineDataSync", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:eCwp1y5OvEmtYkivpmfoog", callContext.id);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:0Tc16cg8iEuflVtN94J9Dg", callContext.id);
controller.safeExecuteJSNode(OutSystemsUI_controller_StartOfflineDataSync_CallBlockHandlerJS, "CallBlockHandler", "StartOfflineDataSync", {
SyncUnit: OS.DataConversion.JSNodeParamConverter.to(vars.value.syncUnitInLocal, OS.Types.Text),
DiscardPendingUnits: OS.DataConversion.JSNodeParamConverter.to(vars.value.discardPendingSyncUnitsInLocal, OS.Types.Boolean)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:9YoiDsnfdEadz05S8x5_ZA", callContext.id);
return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:6wYKHDHaTk24G0Nx4wSdrQ", callContext.id);
}

};
var controller = OutSystemsUIController.default;
OutSystemsUIController.default.constructor.registerVariableGroupType("OutSystemsUI.StartOfflineDataSync$vars", [{
name: "SyncUnit",
attrName: "syncUnitInLocal",
mandatory: false,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}, {
name: "DiscardPendingSyncUnits",
attrName: "discardPendingSyncUnitsInLocal",
mandatory: false,
dataType: OS.Types.Boolean,
defaultValue: function () {
return false;
}
}]);
OutSystemsUIController.default.clientActionProxies.startOfflineDataSync$Action = function (syncUnitIn, discardPendingSyncUnitsIn) {
syncUnitIn = (syncUnitIn === undefined) ? "" : syncUnitIn;
discardPendingSyncUnitsIn = (discardPendingSyncUnitsIn === undefined) ? false : discardPendingSyncUnitsIn;
return controller.executeActionInsideJSNode(OutSystemsUIController.default.startOfflineDataSync$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(syncUnitIn, OS.Types.Text), OS.DataConversion.JSNodeParamConverter.from(discardPendingSyncUnitsIn, OS.Types.Boolean)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("OutSystemsUI.controller$StartOfflineDataSync.CallBlockHandlerJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
if (window.offlineDataSync) {
    window.offlineDataSync.sync($parameters.SyncUnit, $parameters.DiscardPendingUnits);
}
};
});

define("OutSystemsUI.controller$TabsDisableSwipe", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.controller", "OutSystemsUI.controller$TabsDisableSwipe.AddClassNoSwipeJS"], function (exports, OutSystems, OutSystemsUIModel, OutSystemsUIController, OutSystemsUI_controller_TabsDisableSwipe_AddClassNoSwipeJS) {
var OS = OutSystems.Internal;
OutSystemsUIController.default.tabsDisableSwipe$Action = function (tabIDIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsUI.TabsDisableSwipe$vars"))());
vars.value.tabIDInLocal = tabIDIn;
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:8A4PWWqEo0eHrnR0AR3i9Q:/ClientActionFlows.8A4PWWqEo0eHrnR0AR3i9Q:mt1har0OcRexVb1lI1e0UQ", "OutSystemsUI", "TabsDisableSwipe", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:GtM0GXiS1UG1DaAH_MoTaQ", callContext.id);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:B3wXWZq7aUWYEIVdFUX_KA", callContext.id);
controller.safeExecuteJSNode(OutSystemsUI_controller_TabsDisableSwipe_AddClassNoSwipeJS, "AddClassNoSwipe", "TabsDisableSwipe", {
TabID: OS.DataConversion.JSNodeParamConverter.to(vars.value.tabIDInLocal, OS.Types.Text)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:2SYl0nbsbUifUcGePGHZQQ", callContext.id);
return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:8A4PWWqEo0eHrnR0AR3i9Q", callContext.id);
}

};
var controller = OutSystemsUIController.default;
OutSystemsUIController.default.constructor.registerVariableGroupType("OutSystemsUI.TabsDisableSwipe$vars", [{
name: "TabID",
attrName: "tabIDInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
OutSystemsUIController.default.clientActionProxies.tabsDisableSwipe$Action = function (tabIDIn) {
tabIDIn = (tabIDIn === undefined) ? "" : tabIDIn;
return controller.executeActionInsideJSNode(OutSystemsUIController.default.tabsDisableSwipe$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(tabIDIn, OS.Types.Text)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("OutSystemsUI.controller$TabsDisableSwipe.AddClassNoSwipeJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
var elem = document.getElementById($parameters.TabID).querySelector('.tabs');

if(elem) {
    elem.classList.add('no-swipe');
}
};
});

define("OutSystemsUI.controller$TabsGoTo", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.controller", "OutSystemsUI.controller$TabsGoTo.ChangeTabJS"], function (exports, OutSystems, OutSystemsUIModel, OutSystemsUIController, OutSystemsUI_controller_TabsGoTo_ChangeTabJS) {
var OS = OutSystems.Internal;
OutSystemsUIController.default.tabsGoTo$Action = function (widgetIdIn, tabNumberIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsUI.TabsGoTo$vars"))());
vars.value.widgetIdInLocal = widgetIdIn;
vars.value.tabNumberInLocal = tabNumberIn;
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:uBmPnAyh10iXcs4yts2GGw:/ClientActionFlows.uBmPnAyh10iXcs4yts2GGw:eo99ECJp+14VDlc_DzQxbw", "OutSystemsUI", "TabsGoTo", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:PZmGGuUzaEmvKzzO7xFVXg", callContext.id);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:DkGb6z63NUeOAN_exev1sA", callContext.id);
controller.safeExecuteJSNode(OutSystemsUI_controller_TabsGoTo_ChangeTabJS, "ChangeTab", "TabsGoTo", {
WidgetId: OS.DataConversion.JSNodeParamConverter.to(vars.value.widgetIdInLocal, OS.Types.Text),
TabNumber: OS.DataConversion.JSNodeParamConverter.to(vars.value.tabNumberInLocal, OS.Types.Integer)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:L5BRA4V2M0CBIiYdrVYnsw", callContext.id);
return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:uBmPnAyh10iXcs4yts2GGw", callContext.id);
}

};
var controller = OutSystemsUIController.default;
OutSystemsUIController.default.constructor.registerVariableGroupType("OutSystemsUI.TabsGoTo$vars", [{
name: "WidgetId",
attrName: "widgetIdInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}, {
name: "TabNumber",
attrName: "tabNumberInLocal",
mandatory: true,
dataType: OS.Types.Integer,
defaultValue: function () {
return 0;
}
}]);
OutSystemsUIController.default.clientActionProxies.tabsGoTo$Action = function (widgetIdIn, tabNumberIn) {
widgetIdIn = (widgetIdIn === undefined) ? "" : widgetIdIn;
tabNumberIn = (tabNumberIn === undefined) ? 0 : tabNumberIn;
return controller.executeActionInsideJSNode(OutSystemsUIController.default.tabsGoTo$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(widgetIdIn, OS.Types.Text), OS.DataConversion.JSNodeParamConverter.from(tabNumberIn, OS.Types.Integer)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("OutSystemsUI.controller$TabsGoTo.ChangeTabJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
var element = document.getElementById($parameters.WidgetId);
var countTabs = element.querySelectorAll(".tabs-header-tab").length -1;
var tabsElement = element.querySelectorAll(".tabs-header-tab");
var countEmptyTabs = element.querySelectorAll(".tabs-header-tab.ph");
var isEmpty = 0;

for(i = 0; i < tabsElement.length; i++) {
    
    if(countEmptyTabs[i].childNodes.length === 0) {
       isEmpty = isEmpty + 1;
    }
}


if(($parameters.TabNumber + 1) <= countTabs) {
    element.changeTab($parameters.TabNumber);
} else {
    element.changeTab(countTabs - isEmpty);
}









};
});

define("OutSystemsUI.controller$TextEllipsis", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.controller"], function (exports, OutSystems, OutSystemsUIModel, OutSystemsUIController) {
var OS = OutSystems.Internal;
OutSystemsUIController.default.textEllipsis$Action = function (textIn, numberOfCharsIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsUI.TextEllipsis$vars"))());
vars.value.textInLocal = textIn;
vars.value.numberOfCharsInLocal = numberOfCharsIn;
var outVars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsUI.TextEllipsis$outVars"))());
varBag.callContext = callContext;
varBag.vars = vars;
varBag.outVars = outVars;
try {OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:vcPCjzmwt06eSWGQwvznuA:/ClientActionFlows.vcPCjzmwt06eSWGQwvznuA:LVSGFDl_rtj5L9TOtWoTXA", "OutSystemsUI", "TextEllipsis", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:p1XmnacGaEOcwbrR8D7Z0g", callContext.id);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:1sSXt7IPA06J2_AMOnpLfQ", callContext.id);
// Out = If + If
outVars.value.outOut = ((((OS.BuiltinFunctions.length(vars.value.textInLocal) > vars.value.numberOfCharsInLocal)) ? (OS.BuiltinFunctions.substr(vars.value.textInLocal, 0, vars.value.numberOfCharsInLocal)) : (vars.value.textInLocal)) + (((OS.BuiltinFunctions.length(vars.value.textInLocal) > vars.value.numberOfCharsInLocal)) ? ("...") : ("")));
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:Gri2DOKqCE6VH4hPqVv76w", callContext.id);
return outVars.value;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:vcPCjzmwt06eSWGQwvznuA", callContext.id);
}

};
var controller = OutSystemsUIController.default;
OutSystemsUIController.default.constructor.registerVariableGroupType("OutSystemsUI.TextEllipsis$vars", [{
name: "Text",
attrName: "textInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}, {
name: "NumberOfChars",
attrName: "numberOfCharsInLocal",
mandatory: true,
dataType: OS.Types.Integer,
defaultValue: function () {
return 0;
}
}]);
OutSystemsUIController.default.constructor.registerVariableGroupType("OutSystemsUI.TextEllipsis$outVars", [{
name: "Out",
attrName: "outOut",
mandatory: false,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
OutSystemsUIController.default.clientActionProxies.textEllipsis$Action = function (textIn, numberOfCharsIn) {
textIn = (textIn === undefined) ? "" : textIn;
numberOfCharsIn = (numberOfCharsIn === undefined) ? 0 : numberOfCharsIn;
return controller.executeActionInsideJSNode(OutSystemsUIController.default.textEllipsis$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(textIn, OS.Types.Text), OS.DataConversion.JSNodeParamConverter.from(numberOfCharsIn, OS.Types.Integer)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {
Out: OS.DataConversion.JSNodeParamConverter.to(actionResults.outOut, OS.Types.Text)
};
});
};
});

define("OutSystemsUI.controller$ToggleSideMenu", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.controller", "OutSystemsUI.controller$ToggleSideMenu.ToggleSideMenuJS"], function (exports, OutSystems, OutSystemsUIModel, OutSystemsUIController, OutSystemsUI_controller_ToggleSideMenu_ToggleSideMenuJS) {
var OS = OutSystems.Internal;
OutSystemsUIController.default.toggleSideMenu$Action = function (callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
varBag.callContext = callContext;
try {OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:DCQtVNJTOkqa1AaUsdSc5w:/ClientActionFlows.DCQtVNJTOkqa1AaUsdSc5w:+6fdP0XIvBL03o2WWq7EEA", "OutSystemsUI", "ToggleSideMenu", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:XtNByosVU0a72x8r54raqQ", callContext.id);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:msY6GlPMyEGBMU5uDhV31w", callContext.id);
controller.safeExecuteJSNode(OutSystemsUI_controller_ToggleSideMenu_ToggleSideMenuJS, "ToggleSideMenu", "ToggleSideMenu", null, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:tR4CDYbfKUCj9S2MJHARQg", callContext.id);
return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:DCQtVNJTOkqa1AaUsdSc5w", callContext.id);
}

};
var controller = OutSystemsUIController.default;
OutSystemsUIController.default.clientActionProxies.toggleSideMenu$Action = function () {
return controller.executeActionInsideJSNode(OutSystemsUIController.default.toggleSideMenu$Action.bind(controller), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("OutSystemsUI.controller$ToggleSideMenu.ToggleSideMenuJS", [], function () {
return function ($actions, $roles, $public) {
var layout = document.querySelector('.layout');

if(layout.classList.contains('menu-visible')) {
    layout.classList.remove('menu-visible');
} else {
    layout.classList.add('menu-visible');    
}
};
});

define("OutSystemsUI.controller$VideoPause", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.controller", "OutSystemsUI.controller$VideoPause.PauseVideoJS"], function (exports, OutSystems, OutSystemsUIModel, OutSystemsUIController, OutSystemsUI_controller_VideoPause_PauseVideoJS) {
var OS = OutSystems.Internal;
OutSystemsUIController.default.videoPause$Action = function (widgetIdIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsUI.VideoPause$vars"))());
vars.value.widgetIdInLocal = widgetIdIn;
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:XZhXecZh6EaW7R2FSGgeWQ:/ClientActionFlows.XZhXecZh6EaW7R2FSGgeWQ:r6avvjsRES7CnZm0JOwyjw", "OutSystemsUI", "VideoPause", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:60SFJR8Xgkq5rnzg0D37Ww", callContext.id);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:hRGnfc_5jkadLvrVm24NQQ", callContext.id);
controller.safeExecuteJSNode(OutSystemsUI_controller_VideoPause_PauseVideoJS, "PauseVideo", "VideoPause", {
WidgetId: OS.DataConversion.JSNodeParamConverter.to(vars.value.widgetIdInLocal, OS.Types.Text)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:67D1E4xrs0mRjYUAnWo08A", callContext.id);
return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:XZhXecZh6EaW7R2FSGgeWQ", callContext.id);
}

};
var controller = OutSystemsUIController.default;
OutSystemsUIController.default.constructor.registerVariableGroupType("OutSystemsUI.VideoPause$vars", [{
name: "WidgetId",
attrName: "widgetIdInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
OutSystemsUIController.default.clientActionProxies.videoPause$Action = function (widgetIdIn) {
widgetIdIn = (widgetIdIn === undefined) ? "" : widgetIdIn;
return controller.executeActionInsideJSNode(OutSystemsUIController.default.videoPause$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(widgetIdIn, OS.Types.Text)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("OutSystemsUI.controller$VideoPause.PauseVideoJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
var videoWidget = document.getElementById($parameters.WidgetId);
var videoTag = videoWidget.querySelector('video');
videoTag.pause();
};
});

define("OutSystemsUI.controller$VideoPlay", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.controller", "OutSystemsUI.controller$VideoPlay.PlayVideoJS"], function (exports, OutSystems, OutSystemsUIModel, OutSystemsUIController, OutSystemsUI_controller_VideoPlay_PlayVideoJS) {
var OS = OutSystems.Internal;
OutSystemsUIController.default.videoPlay$Action = function (widgetIdIn, callContext) {
var varBag = {};
callContext = controller.callContext(callContext);
var vars = new OS.DataTypes.VariableHolder(new (controller.constructor.getVariableGroupType("OutSystemsUI.VideoPlay$vars"))());
vars.value.widgetIdInLocal = widgetIdIn;
varBag.callContext = callContext;
varBag.vars = vars;
try {OutSystemsDebugger.push("Kn_hixxDWEm4lMd7mIpycQ:9RaZU8285Uq8mBSLGd60mQ:/ClientActionFlows.9RaZU8285Uq8mBSLGd60mQ:I_f0FgC0cHzQxV_qWIYCqQ", "OutSystemsUI", "VideoPlay", "NRFlows.ClientActionFlow", callContext.id, varBag);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:R_v+DsUpIEWquaClGVVciw", callContext.id);
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:Sw71dFhVZU+bIcw4SpveXA", callContext.id);
controller.safeExecuteJSNode(OutSystemsUI_controller_VideoPlay_PlayVideoJS, "PlayVideo", "VideoPlay", {
WidgetId: OS.DataConversion.JSNodeParamConverter.to(vars.value.widgetIdInLocal, OS.Types.Text)
}, function ($parameters) {
}, {}, {});
OutSystemsDebugger.handleBreakpoint("Kn_hixxDWEm4lMd7mIpycQ:1eMKnrmGL0K5+GjQaYVz5w", callContext.id);
return ;
} catch (ex) {
OutSystemsDebugger.handleException(ex, callContext.id);
throw ex;
} finally {
OutSystemsDebugger.pop("Kn_hixxDWEm4lMd7mIpycQ:9RaZU8285Uq8mBSLGd60mQ", callContext.id);
}

};
var controller = OutSystemsUIController.default;
OutSystemsUIController.default.constructor.registerVariableGroupType("OutSystemsUI.VideoPlay$vars", [{
name: "WidgetId",
attrName: "widgetIdInLocal",
mandatory: true,
dataType: OS.Types.Text,
defaultValue: function () {
return "";
}
}]);
OutSystemsUIController.default.clientActionProxies.videoPlay$Action = function (widgetIdIn) {
widgetIdIn = (widgetIdIn === undefined) ? "" : widgetIdIn;
return controller.executeActionInsideJSNode(OutSystemsUIController.default.videoPlay$Action.bind(controller, OS.DataConversion.JSNodeParamConverter.from(widgetIdIn, OS.Types.Text)), OS.Controller.BaseViewController.activeScreen ? OS.Controller.BaseViewController.activeScreen.callContext() : undefined, function (actionResults) {
return {};
});
};
});
define("OutSystemsUI.controller$VideoPlay.PlayVideoJS", [], function () {
return function ($parameters, $actions, $roles, $public) {
var videoWidget = document.getElementById($parameters.WidgetId);
var videoTag = videoWidget.querySelector('video');
videoTag.play();
};
});

define("OutSystemsUI.controller", ["exports", "OutSystems/ClientRuntime/Main", "OutSystemsUI.model", "OutSystemsUI.controller$debugger"], function (exports, OutSystems, OutSystemsUIModel, OutSystemsUI_Controller_debugger) {
var OS = OutSystems.Internal;
var OutSystemsUIController = exports;
var Controller = (function (_super) {
__extends(Controller, _super);
function Controller() {
_super.apply(this, arguments);
}
Controller.prototype.clientActionProxies = {};
Controller.prototype.roles = {};
Controller.prototype.defaultTimeout = 10;
Controller.prototype.getDefaultTimeout = function () {
return OutSystemsUIController.default.defaultTimeout;
};
return Controller;
})(OS.Controller.BaseModuleController);
OutSystemsUIController.default = new Controller();
});
define("OutSystemsUI.controller$debugger", ["exports", "OutSystems/ClientRuntime/Debugger", "OutSystems/ClientRuntime/Main"], function (exports, Debugger, OutSystems) {
var OS = OutSystems.Internal;
var metaInfo = {
"Iv4qqL2CAUyTooBa4SSJpg": {
getter: function (varBag, idService) {
return varBag.vars.value.widgetIDInLocal;
},
dataType: OS.Types.Object
},
"Tn+H6xGcAUWzRA9GgwDPeA": {
getter: function (varBag, idService) {
return varBag.vars.value.targetInLocal;
},
dataType: OS.Types.Object
},
"ys785lY_qE6ziCYEBGOpgw": {
getter: function (varBag, idService) {
return varBag.moveElementJSResult.value;
}
},
"iR_mzVvx4EWGZU1VRw3FkQ": {
getter: function (varBag, idService) {
return varBag.vars.value.syncOnOnlineInLocal;
},
dataType: OS.Types.Boolean
},
"7JGqGYj7tE+x8vgdNQiHAA": {
getter: function (varBag, idService) {
return varBag.vars.value.syncOnResumeInLocal;
},
dataType: OS.Types.Boolean
},
"3veDb5FLK0GnedPWNQeZTw": {
getter: function (varBag, idService) {
return varBag.vars.value.retryOnErrorInLocal;
},
dataType: OS.Types.Boolean
},
"aWKSMdKBYUipICKoqyHvUA": {
getter: function (varBag, idService) {
return varBag.vars.value.retryIntervalInSecondsInLocal;
},
dataType: OS.Types.Integer
},
"Q3ziLgpmwEiLfbtrD1nU_A": {
getter: function (varBag, idService) {
return varBag.configureOfflineDataSyncJSResult.value;
}
},
"nquViCwYO0O1G+h5jsG5SA": {
getter: function (varBag, idService) {
return varBag.outVars.value.isWebAppOut;
},
dataType: OS.Types.Boolean
},
"A8C7OkSCkkqYxzxiYRUweA": {
getter: function (varBag, idService) {
return varBag.checkOSUIJSResult.value;
}
},
"tZjZovcHS0yJd7OvtytkJQ": {
getter: function (varBag, idService) {
return varBag.vars.value.syncUnitInLocal;
},
dataType: OS.Types.Text
},
"yFRpWSObyUqhUpN24G94fA": {
getter: function (varBag, idService) {
return varBag.vars.value.discardPendingSyncUnitsInLocal;
},
dataType: OS.Types.Boolean
},
"0Tc16cg8iEuflVtN94J9Dg": {
getter: function (varBag, idService) {
return varBag.callBlockHandlerJSResult.value;
}
},
"dsUlges1bEaJZgxAH5ixpQ": {
getter: function (varBag, idService) {
return varBag.vars.value.widgetIdInLocal;
},
dataType: OS.Types.Text
},
"VGBdXlToIUWYcJSWS4uVRg": {
getter: function (varBag, idService) {
return varBag.swipeTopJSResult.value;
}
},
"lox_6jGjDkaqtFjZZDxrRA": {
getter: function (varBag, idService) {
return varBag.vars.value.menuActionInLocal;
},
dataType: OS.Types.Text
},
"u1xwWmjOrUmCUq_MktIlVg": {
getter: function (varBag, idService) {
return varBag.findMenuLinksJSResult.value;
}
},
"ObH9X2EVfE2QMmbmUEtQ2g": {
getter: function (varBag, idService) {
return varBag.vars.value.hideHeaderInLocal;
},
dataType: OS.Types.Boolean
},
"YIoLAMN9y0C6r84F2nZDLg": {
getter: function (varBag, idService) {
return varBag.hideOnScrollJSResult.value;
}
},
"bQKATDoEQ0W7bsABQuI4fA": {
getter: function (varBag, idService) {
return varBag.vars.value.widgetIdInLocal;
},
dataType: OS.Types.Text
},
"jaHB+obidUu+wcGD9DdGOw": {
getter: function (varBag, idService) {
return varBag.toggleSidebarJSResult.value;
}
},
"5Xc9s8o640OnMfDi59LYUg": {
getter: function (varBag, idService) {
return varBag.vars.value.widgetIdInLocal;
},
dataType: OS.Types.Text
},
"Q46YfT8QYEW25B5LNZozRg": {
getter: function (varBag, idService) {
return varBag.vars.value.targetInLocal;
},
dataType: OS.Types.Integer
},
"dBRtEJ1oXUeFmuSC_CWu9Q": {
getter: function (varBag, idService) {
return varBag.callGoToActionJSResult.value;
}
},
"PQa9fzVt50+PvtBRPKnhgQ": {
getter: function (varBag, idService) {
return varBag.fixInputsJSResult.value;
}
},
"N7UpWG6xpkmSVFWk5O6iLQ": {
getter: function (varBag, idService) {
return varBag.vars.value.widgetIdInLocal;
},
dataType: OS.Types.Text
},
"Sw71dFhVZU+bIcw4SpveXA": {
getter: function (varBag, idService) {
return varBag.playVideoJSResult.value;
}
},
"msY6GlPMyEGBMU5uDhV31w": {
getter: function (varBag, idService) {
return varBag.toggleSideMenuJSResult.value;
}
},
"2T8OZEsJu0ySMPfim+kqxQ": {
getter: function (varBag, idService) {
return varBag.vars.value.tabIDInLocal;
},
dataType: OS.Types.Text
},
"B3wXWZq7aUWYEIVdFUX_KA": {
getter: function (varBag, idService) {
return varBag.addClassNoSwipeJSResult.value;
}
},
"AZ_lAiT4PkqroKU27DpP1Q": {
getter: function (varBag, idService) {
return varBag.initECTJSResult.value;
}
},
"umH3O5XZ906q3gkjTHHoNA": {
getter: function (varBag, idService) {
return varBag.vars.value.userAgentInLocal;
},
dataType: OS.Types.Text
},
"1B54odsIhUeCcVl+yrlE1A": {
getter: function (varBag, idService) {
return varBag.outVars.value.browserOut;
},
dataType: OS.Types.Text
},
"LFGiQlQsl0S6Vbs+hRPR+w": {
getter: function (varBag, idService) {
return varBag.vars.value.hideHeaderOnScrollInLocal;
},
dataType: OS.Types.Boolean
},
"bfGKJ1B_sk65pnXBgj4EhA": {
getter: function (varBag, idService) {
return varBag.vars.value.listIdInLocal;
},
dataType: OS.Types.Text
},
"xb07J7dEDEm05wY1sZpuZg": {
getter: function (varBag, idService) {
return varBag.vars.value.hasLeftActionInLocal;
},
dataType: OS.Types.Boolean
},
"lhbvA9M+YUGFlaR8fZIBVQ": {
getter: function (varBag, idService) {
return varBag.vars.value.hasRightActionInLocal;
},
dataType: OS.Types.Boolean
},
"SG5ALp9a6UqadpEzOTCXsw": {
getter: function (varBag, idService) {
return varBag.vars.value.animationTimeInLocal;
},
dataType: OS.Types.Decimal
},
"HI7FczBGrEKwVfINKPZ6vA": {
getter: function (varBag, idService) {
return varBag.listItemAnimateJSResult.value;
}
},
"P9DByrkeYEWaLabmT75fAw": {
getter: function (varBag, idService) {
return varBag.outVars.value.isPhoneOut;
},
dataType: OS.Types.Boolean
},
"BX3uLVf1k0Wr5zgao8m4ow": {
getter: function (varBag, idService) {
return varBag.getDeviceTypeVar.value;
}
},
"vy3Gn11jQU669hZMoQ11rw": {
getter: function (varBag, idService) {
return varBag.vars.value.widgetIdInLocal;
},
dataType: OS.Types.Text
},
"hRGnfc_5jkadLvrVm24NQQ": {
getter: function (varBag, idService) {
return varBag.pauseVideoJSResult.value;
}
},
"ItfV8gXRx0ihT6BbYk+NBw": {
getter: function (varBag, idService) {
return varBag.vars.value.carouselIDInLocal;
},
dataType: OS.Types.Text
},
"EA76gLu_y0WEapiQoFodxg": {
getter: function (varBag, idService) {
return varBag.addClassNoSwipeJSResult.value;
}
},
"2v19Xbd0EEeAUeDvE9Jb9g": {
getter: function (varBag, idService) {
return varBag.vars.value.widgetIdInLocal;
},
dataType: OS.Types.Text
},
"xMKXLKzze0S3+ZodJF1oqw": {
getter: function (varBag, idService) {
return varBag.updateUiJSResult.value;
}
},
"odudn8epsEOTFn+_2qQH1w": {
getter: function (varBag, idService) {
return varBag.vars.value.textInLocal;
},
dataType: OS.Types.Text
},
"mxxRiYR+zEaWQ2SeYGzMvQ": {
getter: function (varBag, idService) {
return varBag.vars.value.numberOfCharsInLocal;
},
dataType: OS.Types.Integer
},
"dtolCG+1Gkqewx1BgEUySg": {
getter: function (varBag, idService) {
return varBag.outVars.value.outOut;
},
dataType: OS.Types.Text
},
"E7XleKb+UkCOQdHGwDB4ZA": {
getter: function (varBag, idService) {
return varBag.vars.value.previewCSSVar;
},
dataType: OS.Types.Text
},
"NuLUeUgpEUCTkx4KpN0klA": {
getter: function (varBag, idService) {
return varBag.detectPreviewInDevicesJSResult.value;
}
},
"nnXQzS8kxU+Julm22dIqIw": {
getter: function (varBag, idService) {
return varBag.vars.value.userAgentVar;
},
dataType: OS.Types.Text
},
"802dRsv2ZkmMTp_gvSZjQg": {
getter: function (varBag, idService) {
return varBag.getBrowserVar.value;
}
},
"SO6yYH8njUOWeZhQo6DNmQ": {
getter: function (varBag, idService) {
return varBag.getOSVar.value;
}
},
"5WQ6+EOI20qlKf+sVTvE1A": {
getter: function (varBag, idService) {
return varBag.getIsTouchVar.value;
}
},
"RWt+kXHuzUSxVy0cZJHDGw": {
getter: function (varBag, idService) {
return varBag.statusBarOverlayJSResult.value;
}
},
"FDjUnNglU0GGZuMXhNjSKQ": {
getter: function (varBag, idService) {
return varBag.addClassesJSResult.value;
}
},
"kRwKX9EUQUGxLfu93+aKEg": {
getter: function (varBag, idService) {
return varBag.closeMenuOnBodyClickJSResult.value;
}
},
"RcUKCznBskGsiPDjBehj5g": {
getter: function (varBag, idService) {
return varBag.vars.value.widgetIdInLocal;
},
dataType: OS.Types.Text
},
"RAfjTcfSlU6imxmQMnCpsw": {
getter: function (varBag, idService) {
return varBag.vars.value.tabNumberInLocal;
},
dataType: OS.Types.Integer
},
"DkGb6z63NUeOAN_exev1sA": {
getter: function (varBag, idService) {
return varBag.changeTabJSResult.value;
}
},
"z3SR6adZJUWjR4CsYqcFRQ": {
getter: function (varBag, idService) {
return varBag.vars.value.widgetIdInLocal;
},
dataType: OS.Types.Text
},
"bYAjhTuI_UCBz++CrCJsBg": {
getter: function (varBag, idService) {
return varBag.swipeLeftJSResult.value;
}
},
"n8TPmPwhBU2KRXr3lW5hzQ": {
getter: function (varBag, idService) {
return varBag.outVars.value.networkTypeOut;
},
dataType: OS.Types.Text
},
"DdnOaND2fkCpllA7GTAiCg": {
getter: function (varBag, idService) {
return varBag.checkNetworkTypeJSResult.value;
}
},
"0kG81uY5e0GVOSc67jGqBw": {
getter: function (varBag, idService) {
return varBag.vars.value.userAgentInLocal;
},
dataType: OS.Types.Text
},
"EIlIMad4pk+liSQRvrUwQQ": {
getter: function (varBag, idService) {
return varBag.outVars.value.oSOut;
},
dataType: OS.Types.Text
},
"UTNgkVilxEuT_Cr3S2KMTA": {
getter: function (varBag, idService) {
return varBag.detectIphoneXJSResult.value;
}
},
"UoTroLkEs0ipEBTZAHXTzw": {
getter: function (varBag, idService) {
return varBag.vars.value.activeItemInLocal;
},
dataType: OS.Types.Integer
},
"GBAp_B5zEEafCOEqAM20CQ": {
getter: function (varBag, idService) {
return varBag.vars.value.activeSubItemInLocal;
},
dataType: OS.Types.Integer
},
"uauiLqkNdU2Vr4TlJvBStA": {
getter: function (varBag, idService) {
return varBag.setActiveJSResult.value;
}
},
"sD28oLAE8kOYUOCl9kDTHw": {
getter: function (varBag, idService) {
return varBag.vars.value.tableIdInLocal;
},
dataType: OS.Types.Text
},
"aoNsjtr39EmXIYAk_8UCtQ": {
getter: function (varBag, idService) {
return varBag.vars.value.rowNumberInLocal;
},
dataType: OS.Types.Integer
},
"Kgq7hn4x70m93JvEJ1zJ1A": {
getter: function (varBag, idService) {
return varBag.vars.value.isSelectedInLocal;
},
dataType: OS.Types.Boolean
},
"ATatOzJqo0u2ApIml90UFg": {
getter: function (varBag, idService) {
return varBag.setSelectedRowJSResult.value;
}
},
"qLA8zbYCJ0GeeKTA6l0_Dg": {
getter: function (varBag, idService) {
return varBag.vars.value.widgetIdInLocal;
},
dataType: OS.Types.Text
},
"NdVbtmiNvESSTFMxbhkzFA": {
getter: function (varBag, idService) {
return varBag.swipeRightJSResult.value;
}
},
"jK0u8VLe6E+1I1BAkhjrbA": {
getter: function (varBag, idService) {
return varBag.vars.value.deviceConfigurationInLocal;
}
},
"VoR2nu8KDUyBS7WGi_Ed1w": {
getter: function (varBag, idService) {
return varBag.setDeviceOnResizeJSResult.value;
}
},
"sSpuHDYDoE2Ew8OgBXKTvw": {
getter: function (varBag, idService) {
return varBag.outVars.value.isOnlineOut;
},
dataType: OS.Types.Boolean
},
"TzWCSMV5Y0mqa6xVBaVkbw": {
getter: function (varBag, idService) {
return varBag.getNetworkTypeVar.value;
}
},
"Vb34NY3zYEGX4ikxHnvp0A": {
getter: function (varBag, idService) {
return varBag.vars.value.widgetIdInLocal;
},
dataType: OS.Types.Text
},
"53BVu_67OUOpcv5eedIWzw": {
getter: function (varBag, idService) {
return varBag.callNextActionJSResult.value;
}
},
"4CpUHNaQRUume7E1q0Su+g": {
getter: function (varBag, idService) {
return varBag.vars.value.widgetIdInLocal;
},
dataType: OS.Types.Text
},
"X_gFhwE7Lkiq7jKcqYRqDA": {
getter: function (varBag, idService) {
return varBag.vars.value.isActiveInLocal;
},
dataType: OS.Types.Boolean
},
"IO79uJFMWEeJUfqEirGmkg": {
getter: function (varBag, idService) {
return varBag.setActiveElementJSResult.value;
}
},
"d1di0ONiQ0aOcg3byZYc0Q": {
getter: function (varBag, idService) {
return varBag.outVars.value.isDesktopOut;
},
dataType: OS.Types.Boolean
},
"LyPCmHPMOUiz05omO6N5Kg": {
getter: function (varBag, idService) {
return varBag.getDeviceTypeVar.value;
}
},
"A2ILCIEO7EGW0QZ6CB6LJg": {
getter: function (varBag, idService) {
return varBag.vars.value.widgetIdInLocal;
},
dataType: OS.Types.Text
},
"mfJ8xdFCcEm0t1Gi9snU+Q": {
getter: function (varBag, idService) {
return varBag.callPreviousActionJSResult.value;
}
},
"fd7I_BtwWkecM47jRYQwFQ": {
getter: function (varBag, idService) {
return varBag.runOnStartJSResult.value;
}
},
"P_GwkYB2Qky8mj5wnK0Usg": {
getter: function (varBag, idService) {
return varBag.vars.value.widgetIdInLocal;
},
dataType: OS.Types.Text
},
"LrnR4YHuPEaFFAmbmSTz1Q": {
getter: function (varBag, idService) {
return varBag.callUpdateActionJSResult.value;
}
},
"9md9YTHjZkiZZN3suuWnkg": {
getter: function (varBag, idService) {
return varBag.toggleLayoutClassJSResult.value;
}
},
"+saQ0fhpUUq89_xpICnSAg": {
getter: function (varBag, idService) {
return varBag.outVars.value.uRLOut;
},
dataType: OS.Types.Text
},
"+I9JkjJjakK280+6IfwP8w": {
getter: function (varBag, idService) {
return varBag.vars.value.hasErrorInLocal;
},
dataType: OS.Types.Boolean
},
"DCs_wh+rgEKLx0aKR_Y_vA": {
getter: function (varBag, idService) {
return varBag.vars.value.errorMessageInLocal;
},
dataType: OS.Types.Text
},
"cgGNyx+ntUSOxm5inqsadA": {
getter: function (varBag, idService) {
return varBag.vars.value.allowRetryInLocal;
},
dataType: OS.Types.Boolean
},
"v03QPIY87ECIHTsz5R0JNA": {
getter: function (varBag, idService) {
return varBag.triggerSyncCompleteEventJSResult.value;
}
},
"iIqr4yohpki+TJEMODfuzQ": {
getter: function (varBag, idService) {
return varBag.triggerSyncErrorEventJSResult.value;
}
},
"QphTtzz8LUSMkYDEPg6ugQ": {
getter: function (varBag, idService) {
return varBag.outVars.value.deviceOut;
},
dataType: OS.Types.Text
},
"N9WTj9dLUkuBdvhGabzneA": {
getter: function (varBag, idService) {
return varBag.checkDeviceJSResult.value;
}
},
"zC671vjgxUCxvuKBets7Cg": {
getter: function (varBag, idService) {
return varBag.outVars.value.isTouchOut;
},
dataType: OS.Types.Boolean
},
"UzL18+5tCEyY2xczP1HzpQ": {
getter: function (varBag, idService) {
return varBag.setIsTouchJSResult.value;
}
},
"eyb8jAm6+kSOcY1dlExx2g": {
getter: function (varBag, idService) {
return varBag.outVars.value.orientationOut;
},
dataType: OS.Types.Text
},
"gbjVoiko4UGtMqk2GHLr1g": {
getter: function (varBag, idService) {
return varBag.checkDeviceJSResult.value;
}
},
"bxp8S_H10kKMTwwJmoLfTQ": {
getter: function (varBag, idService) {
return varBag.showPasswordJSResult.value;
}
},
"lGYz479sKE2RJjD9e6HHYg": {
getter: function (varBag, idService) {
return varBag.outVars.value.isTabletOut;
},
dataType: OS.Types.Boolean
},
"ioZf772KpUSfGBw8JlIMDw": {
getter: function (varBag, idService) {
return varBag.getDeviceTypeVar.value;
}
},
"+p4JrADMgEuyMGCRVuSHCA": {
getter: function (varBag, idService) {
return varBag.toggleLayoutClassJSResult.value;
}
}
};
OutSystemsDebugger.registerMetaInfo(metaInfo);
});
