﻿try {require(["es6-promise", "tslib"], function (es6promise, tslib) {
require(["OutSystems/ClientRuntime/Main", "InAppBrowserSampleApp.appDefinition"], function (OutSystems, InAppBrowserSampleAppAppDefinition) {
var OS = OutSystems.Internal;
OS.ErrorScreen.initializeErrorPage(InAppBrowserSampleAppAppDefinition, OS.Application);
});
});
} catch (ex) {
console.error(e);
}

