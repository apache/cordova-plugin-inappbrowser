cordova.define("com.outsystems.plugins.http.request-manager", function(require, exports, module) {
module.exports = function init(util, HttpRequest, cordovaExec) {
    function RequestManager() {
        this._requests = {};
    }

    /**
     *
     * @param {("get" | "post")} method HTTP Request method
     * @param {string} url a string representing the URL to send the request to
     * @returns An instance of HttpRequest
     */
    RequestManager.prototype.createRequest = function(method, url) {
        var request = new HttpRequest(url, method, this);
        return request;
    };

    RequestManager.prototype.sendRequest = function(request) {
        if (util.isNullOrUndefined(request)) {
            throw new TypeError(
                "Unable to send because an `undefined` request was provided."
            );
        }

        if (request.readyState !== util.READYSTATE.CREATED) {
            throw new Error("The request's state must be CREATED.");
        }

        request._readyState = util.READYSTATE.SENT;

        this._requests[request.id] = request;
        cordovaExec(
            this._handleSend.bind(this),
            this._handleCordovaFailure.bind(this),
            "OSHttp",
            "sendRequest",
            [
                request.id,
                request.url,
                request.method,
                request.headers,
                request.timeout,
                request.body
            ]
        );
    };

    RequestManager.prototype.abortRequest = function(request) {
        if (util.isNullOrUndefined(request)) {
            throw new TypeError(
                "Unable to abort because an `undefined` request was provided."
            );
        }

        if (isFinishedOrAborting(request)) {
            return;
        }

        if (util.isNullOrUndefined(this._requests[request.id])) {
            // temporarily save the request to be able to abort it
            this._requests[request.id] = request;
        }

        request._readyState = util.READYSTATE.ABORTING;
        cordovaExec(
            this._handleAbort.bind(this),
            undefined,
            "OSHttp",
            "abortRequest",
            [request.id]
        );
    };

    RequestManager.prototype._handleSend = function(result) {
        if (result.error) {
            return this._handleFailure(result);
        }

        this._handleSuccess(result);
    };

    RequestManager.prototype._handleCordovaFailure = function(result) {
        // TODO: What to do when something really bad happened on the native side?
    };

    RequestManager.prototype._handleSuccess = function(result) {
        if (!!result && !!result.requestId) {
            var request = this._requests[result.requestId];
            if (!request) {
                return;
            }

            if (isFinishedOrAborting(request)) {
                return;
            }

            Object.defineProperties(request, {
                responseHeaders: {
                    writable: false,
                    configurable: false,
                    enumerable: true,
                    value: result.data.responseHeaders
                },
                response: {
                    writable: false,
                    configurable: false,
                    enumerable: true,
                    value: result.data.response
                },
                responseText: {
                    writable: false,
                    configurable: false,
                    enumerable: true,
                    value: result.data.responseText
                },
                responseUrl: {
                    writable: false,
                    configurable: false,
                    enumerable: true,
                    value: result.data.responseUrl
                },
                status: {
                    writable: false,
                    configurable: false,
                    enumerable: true,
                    value: result.data.status
                },
                statusText: {
                    writable: false,
                    configurable: false,
                    enumerable: true,
                    value: result.data.statusText
                }
            });

            request._readyState = util.READYSTATE.FINISHED;

            delete this._requests[request.id];
            this.invokeCallbacks(request, [
                util.REQUEST_CALLBACK_NAMES.ON_SUCCESS,
                util.REQUEST_CALLBACK_NAMES.ON_FINISH
            ]);
        }
    };

    RequestManager.prototype._handleFailure = function(result) {
        if (!!result && !!result.requestId && !util.isNullOrUndefined(result.error)) {
            var error = result.error;
            var request = this._requests[result.requestId];

            if (!request) {
                return;
            }

            if (isFinishedOrAborting(request)) {
                return;
            }

            request._readyState = util.READYSTATE.FINISHED;
            delete this._requests[request.id];

            var callbacks = [];
            if (error.errorCode === util.ERROR_CODES.TIMEOUT_ERROR) {
                callbacks.push(util.REQUEST_CALLBACK_NAMES.ON_TIMEOUT);
            } else {
                callbacks.push(util.REQUEST_CALLBACK_NAMES.ON_ERROR);
            }
            callbacks.push("onFinish");
            this.invokeCallbacks(request, callbacks);
        }
    };

    RequestManager.prototype._handleAbort = function(result) {
        if (!!result && !!result.requestId && util.isNullOrUndefined(result.error)) {
            var request = this._requests[result.requestId];

            if (!request) {
                return;
            }

            if (request.readyState === util.READYSTATE.FINISHED) {
                return;
            }

            request._readyState = util.READYSTATE.FINISHED;
            delete this._requests[request.id];
            this.invokeCallbacks(request, [
                util.REQUEST_CALLBACK_NAMES.ON_ABORT,
                util.REQUEST_CALLBACK_NAMES.ON_FINISH
            ]);
        }
    };

    RequestManager.prototype.invokeCallbacks = function(
        request,
        callbackNames
    ) {
        if (!callbackNames) {
            throw new TypeError(
                "The provided callbacks array can't be undefined/null."
            );
        }

        callbackNames.forEach(function(name) {
            var callback = request[name];
            if (!util.isValidRequestCallbackName(name)) {
                return;
            }

            if (!util.isFunction(callback)) {
                return;
            }

            callback.call(request, request);
        });
    };

    function isFinishedOrAborting(request) {
        return !!request && request.readyState >= util.READYSTATE.ABORTING;
    }

    return new RequestManager();
};

});
