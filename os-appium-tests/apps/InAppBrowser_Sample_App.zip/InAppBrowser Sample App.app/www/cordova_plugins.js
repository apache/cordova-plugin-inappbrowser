cordova.define('cordova/plugin_list', function(require, exports, module) {
  module.exports = [
    {
      "id": "cordova-plugin-network-information.network",
      "file": "plugins/cordova-plugin-network-information/www/network.js",
      "pluginId": "cordova-plugin-network-information",
      "clobbers": [
        "navigator.connection",
        "navigator.network.connection"
      ]
    },
    {
      "id": "cordova-plugin-network-information.Connection",
      "file": "plugins/cordova-plugin-network-information/www/Connection.js",
      "pluginId": "cordova-plugin-network-information",
      "clobbers": [
        "Connection"
      ]
    },
    {
      "id": "com.outsystems.plugins.applicationinfo.OSApplicationInfo",
      "file": "plugins/com.outsystems.plugins.applicationinfo/www/OSApplicationInfo.js",
      "pluginId": "com.outsystems.plugins.applicationinfo",
      "clobbers": [
        "OutSystemsNative.ApplicationInfo"
      ]
    },
    {
      "id": "com.outsystems.plugins.logger.OSLogger",
      "file": "plugins/com.outsystems.plugins.logger/www/OSLogger.js",
      "pluginId": "com.outsystems.plugins.logger",
      "clobbers": [
        "OutSystemsNative.Logger"
      ]
    },
    {
      "id": "com.outsystems.plugins.http.uuid-v1",
      "file": "plugins/com.outsystems.plugins.http/www/uuid_v1@3.3.2.js",
      "pluginId": "com.outsystems.plugins.http"
    },
    {
      "id": "com.outsystems.plugins.http.util",
      "file": "plugins/com.outsystems.plugins.http/www/util.js",
      "pluginId": "com.outsystems.plugins.http"
    },
    {
      "id": "com.outsystems.plugins.http.public-interface",
      "file": "plugins/com.outsystems.plugins.http/www/public-interface.js",
      "pluginId": "com.outsystems.plugins.http"
    },
    {
      "id": "com.outsystems.plugins.http.request-manager",
      "file": "plugins/com.outsystems.plugins.http/www/request-manager.js",
      "pluginId": "com.outsystems.plugins.http"
    },
    {
      "id": "com.outsystems.plugins.http.request",
      "file": "plugins/com.outsystems.plugins.http/www/request.js",
      "pluginId": "com.outsystems.plugins.http"
    },
    {
      "id": "com.outsystems.plugins.http.cordova-outsystems-http",
      "file": "plugins/com.outsystems.plugins.http/www/cordova-outsystems-http.js",
      "pluginId": "com.outsystems.plugins.http",
      "clobbers": [
        "OutSystemsNative.Http"
      ]
    },
    {
      "id": "cordova-plugin-wkwebview-engine.ios-wkwebview-exec",
      "file": "plugins/cordova-plugin-wkwebview-engine/src/www/ios/ios-wkwebview-exec.js",
      "pluginId": "cordova-plugin-wkwebview-engine",
      "clobbers": [
        "cordova.exec"
      ]
    },
    {
      "id": "cordova-plugin-wkwebview-engine.ios-wkwebview",
      "file": "plugins/cordova-plugin-wkwebview-engine/src/www/ios/ios-wkwebview.js",
      "pluginId": "cordova-plugin-wkwebview-engine",
      "clobbers": [
        "window.WkWebView"
      ]
    },
    {
      "id": "com.outsystems.plugins.deeplinks.OSDeepLinks",
      "file": "plugins/com.outsystems.plugins.deeplinks/www/OSDeepLinks.js",
      "pluginId": "com.outsystems.plugins.deeplinks",
      "clobbers": [
        "OSDeepLinks"
      ]
    },
    {
      "id": "cordova-plugin-device.device",
      "file": "plugins/cordova-plugin-device/www/device.js",
      "pluginId": "cordova-plugin-device",
      "clobbers": [
        "device"
      ]
    },
    {
      "id": "cordova-plugin-splashscreen.SplashScreen",
      "file": "plugins/cordova-plugin-splashscreen/www/splashscreen.js",
      "pluginId": "cordova-plugin-splashscreen",
      "clobbers": [
        "navigator.splashscreen"
      ]
    },
    {
      "id": "com.outsystems.plugins.filechooser.FileChooser",
      "file": "plugins/com.outsystems.plugins.filechooser/www/FileChooser.js",
      "pluginId": "com.outsystems.plugins.filechooser",
      "clobbers": [
        "FileChooser"
      ]
    },
    {
      "id": "cordova-plugin-statusbar.statusbar",
      "file": "plugins/cordova-plugin-statusbar/www/statusbar.js",
      "pluginId": "cordova-plugin-statusbar",
      "clobbers": [
        "window.StatusBar"
      ]
    },
    {
      "id": "cordova-sqlite-storage.SQLitePlugin",
      "file": "plugins/cordova-sqlite-storage/www/SQLitePlugin.js",
      "pluginId": "cordova-sqlite-storage",
      "clobbers": [
        "SQLitePlugin"
      ]
    },
    {
      "id": "com.outsystems.plugins.oscache.OSCache",
      "file": "plugins/com.outsystems.plugins.oscache/www/OSCache.js",
      "pluginId": "com.outsystems.plugins.oscache",
      "clobbers": [
        "OSCache"
      ]
    },
    {
      "id": "cordova-plugin-inappbrowser.inappbrowser",
      "file": "plugins/cordova-plugin-inappbrowser/www/inappbrowser.js",
      "pluginId": "cordova-plugin-inappbrowser",
      "clobbers": [
        "cordova.InAppBrowser.open",
        "window.open"
      ]
    }
  ];
  module.exports.metadata = {
    "cordova-plugin-network-information": "2.0.1",
    "com.chuckytuh.cordova.rsswizzle": "1.0.1",
    "com.outsystems.plugins.broadcaster": "2.0.0",
    "com.outsystems.plugins.ossecurity": "2.0.0",
    "com.outsystems.plugins.applicationinfo": "1.0.2",
    "com.outsystems.plugins.logger": "3.0.0",
    "com.outsystems.plugins.http": "1.0.0",
    "cordova-plugin-wkwebview-engine": "1.2.0",
    "com.outsystems.plugins.wkwebview": "1.0.0",
    "com.outsystems.plugins.crashhandler": "3.0.0",
    "com.outsystems.plugins.deeplinks": "3.0.0",
    "cordova-plugin-whitelist": "1.3.4",
    "cordova-plugin-device": "1.1.3",
    "cordova-plugin-splashscreen": "5.0.2",
    "com.outsystems.plugins.filechooser": "1.0.3",
    "cordova-plugin-statusbar": "2.4.3-OS",
    "cordova-sqlite-storage": "3.2.0-OS",
    "com.outsystems.plugins.manifest": "1.1.2",
    "com.outsystems.plugins.oscache": "5.0.0",
    "com.outsystems.plugins.prebundle": "3.0.0",
    "com.outsystems.plugins.loader": "4.0.0",
    "cordova-plugin-inappbrowser": "3.1.0-OS2"
  };
});